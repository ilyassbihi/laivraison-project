<?php

namespace Database\Factories;

use App\Models\Product;
use App\Models\User;
use App\Models\Ville;
use App\Models\VilleRamassage;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Commend>
 */
class CommendFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {

      return [
        'QRcodeCommand' => $this->faker->unique()->uuid,
        'Destinataire' => $this->faker->name,
        'TéléphoneD' => $this->faker->phoneNumber,
        'Ville' => Ville::inRandomOrder()->first()->id,
        'villerammasage' => VilleRamassage::inRandomOrder()->first()->id,
        'Adresse' => $this->faker->address,
        'Namepr' => $this->faker->word,
        'Quantite' => $this->faker->randomNumber(2),
        'Prix' => $this->faker->randomFloat(2, 10, 1000), // Adjust range as needed
        'Commentaire' => $this->faker->text,
        'package_opened' => $this->faker->boolean,
        'exchange_requested' => $this->faker->boolean,
        'product' => Product::inRandomOrder()->first()->id,
        'status_commends' => \App\Models\statusCommend::where('statusC', 'Nouveau')->first()->id, // Fetch id of the default status
        'idclient' => User::inRandomOrder()->first()->id,
        'created_at' => $this->faker->dateTimeBetween('-1 year', 'now'),
        'updated_at' => $this->faker->dateTimeBetween('-1 year', 'now'),
    ];
    }
}
