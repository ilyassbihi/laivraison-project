<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\StatusRamassage>
 */
class StatusRamassageFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
  public function definition(): array
  {
    static $index = 0;

    $statuses = ['Nouvelle demande', 'Demande recue', 'Demande traitee'];
    $nameR = $statuses[$index % count($statuses)];
    $index++;

    return [
      'nameR' => $nameR,
    ];
  }
}
