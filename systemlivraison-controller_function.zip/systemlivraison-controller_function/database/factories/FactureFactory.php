<?php

namespace Database\Factories;

use App\Models\Ramassage;
use App\Models\StatusFacture;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Facture>
 */
class FactureFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
      return [
      'Ref' => mt_rand(1000000, 9999999),
        'idclient' => User::inRandomOrder()->first()->id,
        'ramassage_id' => Ramassage::inRandomOrder()->first()->id,
        'total' => $this->faker->randomFloat(2, 0, 1000),
        'statusfacturs' => StatusFacture::inRandomOrder()->first()->id,
    ];
    }
}
