<?php

namespace Database\Factories;

use App\Models\VilleRamassage;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\VilleRamassage>
 */
class VilleRamassageFactory extends Factory
{
  protected $model = VilleRamassage::class;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
      static $villes = ['Ben Slimane', 'Bouznika', 'Mohammedia'];

        return [
            'villeR' => array_shift($villes),
        ];
    }
}
