<?php

namespace Database\Factories;

use App\Models\Tariff;
use App\Models\Ville;
use App\Models\VilleRamassage;
use Illuminate\Database\Eloquent\Factories\Factory;

class TariffFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Tariff::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {


        return [
            'origin_city_id' => VilleRamassage::inRandomOrder()->first()->id,
            'destination_city_id' => Ville::inRandomOrder()->first()->id,
            'tariff' => $this->faker->randomFloat(2, 0, 10),
        ];
    }
}
