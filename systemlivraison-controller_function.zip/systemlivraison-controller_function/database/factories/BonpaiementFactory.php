<?php

namespace Database\Factories;

use App\Models\StatusFacture;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Bonpaiement>
 */
class BonpaiementFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
      return [
        'Ref' => $this->faker->unique()->numerify('BP#######'),
        'idclient' => User::inRandomOrder()->first() ? User::inRandomOrder()->first()->id : null,
        'commend_ids' => json_encode($this->faker->randomElements(range(1, 100), mt_rand(1, 5))), // Assuming commend IDs range from 1 to 100
        'recu_pye' => $this->faker->word,
        'statusfacturs' => 1,
        'total' => $this->faker->randomFloat(2, 50, 5000), // Between 50 and 5000
        'date_paiement' => $this->faker->optional()->dateTime,
    ];
    }
}
