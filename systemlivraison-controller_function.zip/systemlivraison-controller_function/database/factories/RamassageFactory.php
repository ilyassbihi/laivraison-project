<?php

namespace Database\Factories;

use App\Models\commend;
use App\Models\StatusRamassage;
use App\Models\User;
use App\Models\ville;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Ramassage>
 */
class RamassageFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
      $selected_commends = commend::inRandomOrder()->limit(10)->pluck('id')->toArray();

      $default_status_id = StatusRamassage::where('nameR', 'Nouvelle demande')->value('id');

      return [
        'Nom' => $this->faker->name,
        'Ref' => $this->faker->unique()->uuid,
        'Téléphone' => $this->faker->phoneNumber,
        'ville' => Ville::inRandomOrder()->first()->id,
        'Adresse' => $this->faker->address,
        'ramassage_colis' => $this->faker->boolean,
        'ramassage_stock' => $this->faker->boolean,
        'selected_commends' => json_encode($selected_commends), // Encode array to JSON string
        'livreur' => User::inRandomOrder()->first() ? User::inRandomOrder()->first()->id : null,
        'remarque' => $this->faker->sentence,
        'status_ramassages' => $default_status_id, // Set the default status ID
        'idclient' => User::inRandomOrder()->first()->id, // Set the default status ID
    ];
    }
}
