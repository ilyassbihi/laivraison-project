<?php

// database/factories/StatusCommendFactory.php

namespace Database\Factories;

use App\Models\StatusCommend;
use Illuminate\Database\Eloquent\Factories\Factory;

class StatusCommendFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
      $status = $this->faker->randomElement(['En attente de Ramassage', 'Annulée', 'Livré', 'plusieurs tentatives', 'En préparation', 'Nouveau', 'Retourné','Ramassé']);

      return [
          'statusC' => $status,
      ];
  }
}

