<?php

// UserFactory.php

namespace Database\Factories;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class UserFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = User::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->name,
            'telephone' => $this->faker->phoneNumber,
            'address' => $this->faker->address,
            'RIB' => $this->faker->randomNumber(),
            'CIN' => $this->faker->randomNumber(),
            'email' => $this->faker->unique()->safeEmail,
            'email_verified_at' => now(),
            'password' => bcrypt('password'), // Default password
            'rectoCNI' => null, // You can add logic to generate these if needed
            'versoCNI' => null,
            'role' => Role::inRandomOrder()->first()->id, // You may need to adjust this depending on your roles setup
            'ville' => null, // Same as above
            'status' => null, // Same as above
            'terms' => $this->faker->sentence,
            'profile_photo_path' => null,
            'remember_token' => Str::random(10),
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     *
     * @return \Illuminate\Database\Eloquent\Factories\Factory
     */
    public function unverified()
    {
        return $this->state(fn (array $attributes) => [
            'email_verified_at' => null,
        ]);
    }
}

