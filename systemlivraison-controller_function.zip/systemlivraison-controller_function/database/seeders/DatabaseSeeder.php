<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\commend;
use App\Models\Product;
use App\Models\Ramassage;
use App\Models\Role;
use App\Models\Status;
use App\Models\statusCommend;
use App\Models\StatusRamassage;
use App\Models\User;
use App\Models\ville;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
      Status::factory()->count(3)->create();
      Product::factory()->count(10)->create();
      $statuses = ['En attente de Ramassage', 'Annulée', 'Livré', 'plusieurs tentatives', 'En préparation', 'Nouveau', 'Retourné','Ramassé'];

        // Create statuses
        foreach ($statuses as $status) {
            statusCommend::factory()->create([
                'statusC' => $status,
            ]);
        }

      $roles = ['super admin', 'admin', 'livreur', 'commercial'];

        // Create each role
        foreach ($roles as $roleName) {
            Role::create([
                'nameRole' => $roleName,
            ]);
        }
      // $jsonData = file_get_contents('ville.json');
      // $villes = json_decode($jsonData, true);

      // foreach ($villes as $villeData) {
      //     ville::factory()->create([
      //         'ville' => $villeData['ville'],
      //     ]);
      // }
      User::factory()->count(10)->create();
      $this->call([
        VillesTableSeeder::class,
        VilleRamassageSeeder::class
      ]);

      commend::factory()->count(10)->create();
      StatusRamassage::factory()->count(3)->create();
      Ramassage::factory()->count(1)->create();
      $this->call([
        // TariffsTableSeeder::class,
        StatusFactureSeeder::class,
        BonpaiementSeeder::class,
        // FacturesTableSeeder::class
      ]);
    }
}
