<?php

namespace Database\Seeders;

use App\Models\VilleRamassage;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class VilleRamassageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
      VilleRamassage::factory()->count(3)->create();
    }
}
