<?php

namespace Database\Seeders;

use App\Models\StatusFacture;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class StatusFactureSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        StatusFacture::factory()->count(3)->create();
    }
}
