<?php

namespace Database\Seeders;

use App\Models\Product;
use App\Models\produit;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $numberOfProducts = 50; // You can adjust this as per your requirement

        // Generate and insert dummy products into the database
        Product::factory()->count($numberOfProducts)->create();
    }
}
