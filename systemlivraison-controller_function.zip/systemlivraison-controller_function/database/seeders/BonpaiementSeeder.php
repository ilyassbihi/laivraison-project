<?php

namespace Database\Seeders;

use App\Models\Bonpaiement;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BonpaiementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
      Bonpaiement::factory()->count(5)->create();
    }
}
