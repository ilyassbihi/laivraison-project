<?php

namespace Database\Seeders;

use App\Models\statusCommend;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class StatusCommendSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
      statusCommend::factory()->count(8)->create();

    }
}
