<?php

namespace Database\Seeders;

use App\Models\Commend;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class CommendSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
      Commend::factory()->count(10)->create();

    }
}
