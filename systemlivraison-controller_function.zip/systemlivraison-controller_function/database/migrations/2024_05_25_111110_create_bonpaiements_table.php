<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bonpaiements', function (Blueprint $table) {
            $table->id();
            $table->string('Ref');
            $table->foreignId('idclient')->constrained('users');
            $table->json('commend_ids');
            $table->string('recu_pye')->nullable();
            $table->foreignId('statusfacturs')->constrained('status_factures');
            $table->decimal('total', 8, 2);
            $table->datetime('date_paiement')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bonpaiements');
    }
};
