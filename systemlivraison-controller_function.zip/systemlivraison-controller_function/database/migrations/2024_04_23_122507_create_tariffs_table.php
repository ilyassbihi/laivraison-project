<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tariffs', function (Blueprint $table) {
          $table->id();
          $table->foreignId('origin_city_id')->constrained('ville_ramassages');
          $table->foreignId('destination_city_id')->constrained('villes');
          $table->decimal('tariff', 8, 2); // Change the precision according to your tariff calculation
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tariffs');
    }
};
