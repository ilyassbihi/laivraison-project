<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('commends', function (Blueprint $table) {
            $table->id();
            $table->string('QRcodeCommand');
            $table->string('Destinataire');
            $table->string('TéléphoneD');
            $table->string('Adresse');
            $table->string('Namepr');
            $table->string('Quantite');
            $table->string('Prix');
            $table->longText('Commentaire');
            $table->boolean('package_opened')->default(false);
            $table->boolean('exchange_requested')->default(false);
            $table->foreignId('ville')->nullable()->references('id')->on('villes');
            $table->foreignId('villerammasage')->nullable()->references('id')->on('ville_ramassages');
            $table->foreignId('product')->nullable()->references('id')->on('products');
            $table->foreignId('idclient')->nullable()->references('id')->on('users');
            $table->foreignId('livreur')->nullable()->references('id')->on('users');
            $table->boolean('bone_paiment')->default(false);
            $table->foreignId('status_commends')->nullable()->references('id')->on('status_commends');
            $table->decimal('tariff', 8, 2)->nullable(); // Add tariff field
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('commends');
    }
};
