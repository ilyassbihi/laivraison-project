<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
      Schema::create('users', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->string('telephone')->nullable();
        $table->string('Address')->nullable();
        $table->string('RIB')->nullable();
        $table->string('CIN')->nullable();
        $table->string('email', 191)->unique();
        $table->timestamp('email_verified_at')->nullable();
        $table->string('password');
        $table->string('rectoCNI')->nullable();
        $table->string('versoCNI')->nullable();
        $table->foreignId('role')->nullable()->constrained('roles');
        $table->foreignId('ville')->nullable()->references('id')->on('villes');
        $table->foreignId('status')->nullable()->references('id')->on('statuses');
        $table->string('terms')->nullable();
        // $table->integer('commistion')->nullable();
        $table->string('profile_photo_path', 2048)->nullable();
        $table->rememberToken()->nullable();
        $table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
