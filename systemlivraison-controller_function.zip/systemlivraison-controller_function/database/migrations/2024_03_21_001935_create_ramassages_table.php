<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
      Schema::create('ramassages', function (Blueprint $table) {
        $table->id();
        $table->string('Nom');
        $table->string('Ref');
        $table->string('Téléphone');
        $table->foreignId('ville')->references('id')->on('villes');
        $table->string('Adresse');
        $table->boolean('ramassage_colis')->nullable()->default(false);
        $table->boolean('ramassage_stock')->nullable()->default(false);
        $table->integer('total_colis')->nullable();
        $table->integer('total_product')->nullable();
        $table->longText('remarque')->nullable();
        $table->json('selected_commends')->nullable();
        $table->json('selected_products')->nullable();
        $table->foreignId('livreur')->nullable()->constrained('users');
        $table->foreignId('idclient')->nullable()->references('id')->on('users');
        $table->foreignId('status_ramassages')->references('id')->on('status_ramassages');
        $table->decimal('tariff', 8, 2)->nullable();
        $table->timestamps();
    });


    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
      Schema::dropIfExists('ramassage_commend');
      Schema::dropIfExists('ramassages');
    }
};
