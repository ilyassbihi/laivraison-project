<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PdfController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\userController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\SignupController;
use App\Http\Controllers\TariffController;
use App\Http\Controllers\commendController;
use App\Http\Controllers\FactureController;
use App\Http\Controllers\livreurController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\RamassageController;
use App\Http\Controllers\BonDeRouteurController;
use App\Http\Controllers\BonpaiementController;
use App\Http\Middleware\allmiddleware;
use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/all-in-one', function () {
    Artisan::call('config:clear');
     Artisan::call('config:cache');
     Artisan::call('cache:clear');
     Artisan::call('view:clear');
     Artisan::call('route:clear');
     Artisan::call('route:cache');
     Artisan::call('optimize');
    // Do whatever you want either a print a message or exit
});
Route::get('/config-clear', function () {
    Artisan::call('config:clear');
    // Do whatever you want either a print a message or exit
});

Route::get('/config-cache', function () {
    Artisan::call('config:cache');
    // Do whatever you want either a print a message or exit
});

Route::get('/cache-clear', function () {
    Artisan::call('cache:clear');
    // Do whatever you want either print a message or exit
});

Route::get('/view-clear', function () {
    Artisan::call('view:clear');
    // Do whatever you want either print a message or exit
});

Route::get('/route-clear', function () {
    Artisan::call('route:clear');
    // Do whatever you want either print a message or exit
});
Route::get('/route-cache', function () {
    Artisan::call('route:cache');
    // Do whatever you want either print a message or exit
});
Route::get('/optimize', function () {
    Artisan::call('optimize');
    // Do whatever you want either print a message or exit
});
$controller_path = 'App\Http\Controllers';
Route::get('/',[HomeController::class,'index'])->name('home.index');
Route::get('/tarifs',[HomeController::class, 'tarifs'])->name('home.tarifs');
Route::get('/be-client',[SignupController::class,'index'])->name('signup.index');
Route::get('/space',[SignupController::class,'space'])->name('signin.index');


Route::view('/delivery-demo', 'delivery.index')->name('delivery.index');

Route::view('/manager-demo', 'manager.index')->name('manager.index');
Route::view('/informations-demo', 'client.informations')->name('client.informations');

// // Main Page Route
// Route::get('/', $controller_path . '\pages\HomePage@index')->name('pages-home');
// Route::get('/page-2', $controller_path . '\pages\Page2@index')->name('pages-page-2');

// // pages
// Route::get('/pages/misc-error', $controller_path . '\pages\MiscError@index')->name('pages-misc-error');

// // authentication
// Route::get('/auth/login-basic', $controller_path . '\authentications\LoginBasic@index')->name('auth-login-basic');
// Route::get('/auth/register-basic', $controller_path . '\authentications\RegisterBasic@index')->name('auth-register-basic');


Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/run-scheduler', [FactureController::class, 'runScheduler'])->name('scheduler');

//client
Route::middleware('commercial')->group(function () {
Route::get('/myProduct',[ProductController::class,'myProduct'])->name('myProduct');
Route::post('/client/myproduct',[ProductController::class,'store'])->name('product.store');
Route::get('/your-commends',[commendController::class,'commendClient'])->name('commendClient');
Route::get('my-bons-de-routeur', [BonDeRouteurController::class, 'bonclient'])->name('bons-de-routeur.client');
Route::get('/my-factures', [FactureController::class, 'factureclient'])->name('factures.client');
Route::get('/ramassage', [RamassageController::class, 'ramassageClient'])->name('ramassages.client');
Route::get('/ramassages/create', [RamassageController::class, 'create'])->name('ramassages.create');
Route::get('my-bons-de-routeur', [BonDeRouteurController::class, 'bonclient'])->name('bons-de-routeur.client');
Route::post('/factures', [FactureController::class, 'store'])->name('factures.store');
// Route::view('/client-demo', 'client.index')->name('client.index');
Route::get('/clientt-demo', [AdminController::class, 'clientStatistic'])->name('client.index');


// Route::view('/client-demo', 'client.index')->name('client.index');
// Route::get('/clientt-demo', [AdminController::class, 'clientStatistic'])->name('client.index');


});
// Route::get('/ramassages/create', [RamassageController::class, 'create'])->name('ramassages.create');
Route::middleware('allmiddleware')->group(function () {
    Route::view('/admin-demo', 'admin.index')->name('admin.index');
    Route::get('/your-profile', [userController::class, 'profile'])->name('user.profile');
    Route::put('/update-profile/{id}', [userController::class, 'update_self'])->name('user.profile.update');
    Route::put('/update-mdp/{id}', [userController::class, 'mdpChange'])->name('mdpChange');
    Route::get('bons-de-routeur', [BonDeRouteurController::class, 'index'])->name('bons-de-routeur.index');
    Route::post('bons-de-routeur', [BonDeRouteurController::class, 'store'])->name('bons-de-routeur.store');
    Route::post('/bons-de-routeur/update-status', [BonDeRouteurController::class, 'updateStatus']);
    Route::get('/users/{user}/commands', [BonDeRouteurController::class, 'getCommands']);
    Route::get('/addCommand',[commendController::class,'addCommand'])->name('commend.add');
    Route::post('/commend/add',[commendController::class,'store'])->name('command.store');
    Route::post('/ramassages', [RamassageController::class, 'store'])->name('ramassages.store');
    Route::delete('/ramassage/{id}', [RamassageController::class, 'destroy'])->name('ramassage.destroy');
    Route::get('/command/edit/{id}', [commendController::class, 'edit'])->name('command.edit');
Route::post('/command/update/{id}', [commendController::class, 'update'])->name('command.update');
Route::delete('/commend/{id}', [CommendController::class, 'destroy'])->name('commend.destroy');
});




// Route::middleware('AdminLivreurMiddlware')->group(function () {

// });

Route::middleware('admin')->group(function () {
    Route::put('/upddateStatus/{id}', [RamassageController::class, 'upddateStatus'])->name('upddateStatus');
    Route::put('/upddateStatus/{id}', [RamassageController::class, 'upddateStatus'])->name('upddateStatus');
Route::get('/getRamassageCount/{livreurId}',  [RamassageController::class, 'getRamassageCount']);
Route::put('/updateLivreur/{id}', [RamassageController::class, 'updateLivreur'])->name('updateLivreur');
Route::get('/ramassages', [RamassageController::class, 'index'])->name('ramassages.index');
Route::get('/adduser', [userController::class, 'create'])->name('user.create');
Route::post('/adduser', [userController::class, 'store'])->name('user.store');
Route::get('/admin-demo', [AdminController::class, 'statistic'])->name('admin.index');
Route::get('/admin-demo', [AdminController::class, 'statistic'])->name('admin.index');

Route::get('/commend',[commendController::class,'index'])->name('commend');
Route::get('/affecter-commends',[commendController::class,'affectation'])->name('affecterCommends');
Route::put('/set-livreur-commend/{id}', [commendController::class, 'updateLivreurC'])->name('updateLivreurC');
Route::post('/change-status',[commendController::class,'changeStatus'])->name('change.status');
Route::get('/client/myproduct',[ProductController::class,'index'])->name('product.all');
Route::get('/getRamassageCount/{livreurId}',  [RamassageController::class, 'getRamassageCount']);


Route::get('/add-ville', [TariffController::class, 'allville'])->name('ville.allville');
Route::get('/add-ramassage-ville', [TariffController::class, 'allvilleramassage'])->name('ville.allRamville');
Route::post('/ville/update/{id}', [TariffController::class, 'updateVille'])->name('ville.update');
Route::post('/add-ville', [TariffController::class, 'store'])->name('ville.store');
Route::post('/add-ramassage-ville', [TariffController::class, 'storevilleramassage'])->name('villeRamassage.store');
Route::get('/tariff/all', [TariffController::class, 'allTariffs'])->name('tariff.all');
Route::get('/tariff/create', [TariffController::class, 'create'])->name('tariff.create');
Route::post('/tariff/store', [TariffController::class, 'storetariff'])->name('tariff.store');
Route::get('/tariff/check',  [TariffController::class, 'getExistingDestinations'])->name('get_available_destinations');
Route::post('/submit-form',  [TariffController::class, 'submitForm'])->name('submit.form');
Route::get('/users/{user}/commands', [BonDeRouteurController::class, 'getCommands']);

Route::post('/factures', [FactureController::class, 'store'])->name('factures.store');
Route::post('/factures/sai', [FactureController::class, 'jdida'])->name('factures.jdida');
Route::post('/Bonpaiement/sai', [BonpaiementController::class, 'jdida'])->name('Bonpaiement.jdida');
Route::get('/factures', [FactureController::class, 'index'])->name('factures.index');
Route::get('/factures/create', [FactureController::class, 'create'])->name('factures.create');
Route::post('/factures/update-status', [FactureController::class, 'updateStatus']);
Route::post('/factures/update-payment-date', [FactureController::class, 'updatePaymentDate']);
Route::get('/all-users',[AdminController::class,'allUsers'])->name('allUsers.index');
Route::get('/activerCompte/{id}',[AdminController::class,'activerCompte'])->name('activerCompte');
Route::get('/user/{id}',[AdminController::class,'userDetails'])->name('user.details');
Route::post('/user/update/{id}',[AdminController::class, 'updateDetails'])->name('user.update');
Route::get('/desactiverCompte/{id}',[AdminController::class,'desactiverCompte'])->name('desactiverCompte');
Route::get('/new-users',[AdminController::class,'newUsers'])->name('newUsers.index');
Route::get('/Bonpaiement', [BonpaiementController::class, 'index'])->name('Bonpaiement.index');
Route::post('/Bonpaiement/store', [BonpaiementController::class, 'store'])->name('Bonpaiement.store');
Route::get('/Bonpaiement/download/{Bonpaiement}', [BonpaiementController::class, 'download'])->name('Bonpaiement.download');
});


Route::get('generate-pdf/commends/{ref}',[PdfController::class,'index'])->name('pdf.commend');
Route::get('new/commends/{ref}',[PdfController::class,'commends'])->name('pdf.commends');
Route::get('/factures/{facture}/download', [PdfController::class, 'download'])->name('factures.download');
Route::get('/factures/{facture}/preview', [FactureController::class, 'downloadF'])->name('factures.preview');
Route::get('/Commend/{ref}/preview', [FactureController::class, 'downloadC'])->name('commend.preview');
Route::get('/bon-de-routeurs/{bonDeRouteur}/download', [PdfController::class, 'downloadbon'])->name('bonDeRouteurs.download');
Route::view('pdfs', 'pdf.test');







//livreur
Route::middleware('livreurmiddleware')->group(function () {
    Route::put('/updateStatuslivreur/{id}', [livreurController::class, 'updateStatuslivreur'])->name('updateStatuslivreur');
    Route::put('/updateStatuslivreur/{id}', [livreurController::class, 'updateStatuslivreur'])->name('updateStatuslivreur');
Route::get('/livreur',  [livreurController::class, 'index'])->name('livreur');
Route::get('/livreur/commend',  [livreurController::class, 'listcommends'])->name('livreur.commend');
Route::post('/update-status', [livreurController::class, 'updateStatus'])->name('update.status');
Route::get('/livreurr-demo', [AdminController::class, 'livreurStatistic'])->name('livreur.index');
Route::get('/livreurr-demo', [AdminController::class, 'livreurStatistic'])->name('livreur.index');
Route::get('/my-Bonpaiement', [BonpaiementController::class, 'mybonpaiement'])->name('myBonpaiement.index');
Route::put('/bonpaiement/{id}/update-recu', [BonpaiementController::class, 'updateRecu'])->name('Bonpaiement.updateRecu');

});


