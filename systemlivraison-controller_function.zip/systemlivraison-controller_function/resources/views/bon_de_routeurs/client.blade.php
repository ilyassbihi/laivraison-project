<!-- resources/views/bon_de_routeurs/client.blade.php -->
@extends('layouts.clientDashboard')

@section('content')
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4">
                <span class="text-muted fw-light">Dashboard /</span>
                Bons de Routeur
            </h4>
        </div>

        <!-- Table to display Bon de Routeurs -->
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre de Commandes</th>
                    <th>Frise</th>
                    <th>Date de création</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($bonDeRouteurs as $bonDeRouteur)
                    <tr>
                        <td>{{ $bonDeRouteur->id }}</td>
                        @php
                            $commands = json_decode($bonDeRouteur->commend_id) ?: [];
                            $numberOfCommands = count($commands);
                            $frise = $numberOfCommands * (-10);
                        @endphp
                        <td>{{ $numberOfCommands }}</td>
                        <td>{{ $frise }}</td>
                        <td>{{ $bonDeRouteur->created_at }}</td>
                        <td>{{ $bonDeRouteur->statusBonDeRouteur->statusfac }}</td>
                        <td>
                            <div class="action-icons">
 <a class="dropdown-item" href="{{ route('bonDeRouteurs.download', $bonDeRouteur->id) }}"><i class="ti ti-file me-1"></i>Download PDF</a>
    </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
