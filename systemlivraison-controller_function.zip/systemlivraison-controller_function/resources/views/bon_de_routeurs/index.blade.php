<!-- resources/views/bon_de_routeurs/index.blade.php -->
@extends('layouts.clientDashboard')
@section('content')

<head>
    <title>Bons de Routeur</title>
</head>

<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span>Bons de Routeur</h4>
            <!-- Button to open the modal -->
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewBonModal">
                Create Bon de Routeur
            </button>
        </div>

        <!-- Modal to create a new Bon de Routeur -->
        <div class="modal fade" id="addNewBonModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3 class="mb-2">Add New Bon de Routeur</h3>
                            <p class="text-muted">Add new Bon de Routeur to a client</p>
                        </div>
                        <!-- Form to create a new Bon de Routeur -->
                        <form method="POST" id="addNewBonForm" class="row g-3">
                            @csrf
                            <div>
                                <label for="user_id" class="form-label w-100">Select User:</label>
                                <select name="user_id" id="user_id" class="select2 form-select form-select-lg">
                                    @foreach ($clients as $client)
                                        <option value="{{ $client->id }}">{{ $client->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div>
                              <label for="commands" class="form-label w-100">Select Command:</label>
                              <select name="commend_id[]" id="commands" class="select2 form-select form-select-lg" multiple>
                                  <!-- Commands for selected user will be populated by JavaScript -->
                              </select>
                          </div>

                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                                <button type="reset" class="btn btn-label-secondary btn-reset" data-bs-dismiss="modal" aria-label="Close">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Table to display existing Bon de Routeurs -->
        <table class="table">
          <tr>
              <th>ID</th>
              <th>Client</th>
              <th>Nombre de Commands</th>
              <th>Frise</th>
              <th>Date de création</th>
              <th>Status</th>
              <th>Action</th>
          </tr>
          @foreach ($bonDeRouteurs as $bonDeRouteur)
              <tr>
                  <td>{{ $bonDeRouteur->id }}</td>
                  <td>{{ $bonDeRouteur->user->name }}</td>
                  @php
                      $commands = json_decode($bonDeRouteur->commend_id) ?: [];
                      $numberOfCommands = count($commands);
                      $frise = $numberOfCommands * (-10);
                  @endphp
                  <td>{{ $numberOfCommands }}</td>
                  <td>{{ $frise }}</td>
                  <td>{{ $bonDeRouteur->created_at }}</td>
                  <td>
                    <select class="form-select status-select" data-bon-de-routeur-id="{{ $bonDeRouteur->id }}">
                        @foreach($status_factures as $status)
                            <option value="{{ $status->id }}" {{ $bonDeRouteur->status_bon_de_routeurs == $status->id ? 'selected' : '' }}>{{ $status->statusfac }}</option>
                        @endforeach
                    </select>
                  </td>
                  <td>
                      <a class="dropdown-item" href="{{ route('bonDeRouteurs.download', $bonDeRouteur->id) }}"><i class="ti ti-file me-1"></i></a>
                  <!--  <div class="dropdown">-->
                  <!--    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown" aria-expanded="false">-->
                  <!--        <i class="ti ti-dots-vertical"></i>-->
                  <!--    </button>-->
                  <!--    <div class="dropdown-menu" style="">-->
                  <!--        <a class="dropdown-item" href="{{ route('bonDeRouteurs.download', $bonDeRouteur->id) }}"><i class="ti ti-pencil me-1"></i>Download PDF</a>-->
                  <!--    </div>-->
                  <!--</div>-->
                  </td>
              </tr>
          @endforeach
      </table>

    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(document).ready(function () {
          // Populating commands based on the selected user
          $('#user_id').change(function () {
              var selectedUserId = $(this).val();
              $.ajax({
                  url: '/users/' + selectedUserId + '/commands',
                  type: 'GET',
                  success: function (response) {
                      $('#commands').empty();
                      $.each(response, function (key, command) {
                          $('#commands').append($('<option>', {
                              value: command.id,
                              text: command.QRcodeCommand
                          }));
                      });
                  },
                  error: function (xhr) {
                      console.log(xhr);
                  }
              });
          });

          // Update the status of Bon de Routeur
          $('.status-select').change(function () {
              var statusId = $(this).val();
              var bonDeRouteurId = $(this).data('bon-de-routeur-id');
              $.ajax({
                  url: '/bons-de-routeur/update-status',
                  type: 'POST',
                  data: {
                      bon_de_routeur_id: bonDeRouteurId,
                      status_id: statusId,
                      _token: '{{ csrf_token() }}'
                  },
                  success: function (response) {
                      console.log(response);
                  }
              });
          });

          // Submitting the form to create a new Bon de Routeur via AJAX
          $('#addNewBonForm').submit(function (event) {
              event.preventDefault();

              var formData = new FormData($(this)[0]);

              $.ajax({
                  type: 'POST',
                  url: "{{ route('bons-de-routeur.store') }}",
                  data: formData,
                  processData: false,
                  contentType: false,
                  success: function (response) {
                      if (response.success) {
                          toastr.success('Good Job.', 'Bon de Routeur has been created!', {
                              "showMethod": "slideDown",
                              "hideMethod": "slideUp",
                              timeOut: 2000
                          });
                          $('#addNewBonModal').modal('hide');
                          location.reload();
                      }
                  },
                  error: function (xhr) {
                      if (xhr.status === 422) {
                          var errors = xhr.responseJSON.errors;
                          for (var field in errors) {
                              toastr.warning('Good Job.', errors[field][0], {
                                  "showMethod": "slideDown",
                                  "hideMethod": "slideUp",
                                  timeOut: 4000
                              });
                          }
                      } else {
                          toastr.warning('Good Job.', 'Oops! Something went wrong!', {
                              "showMethod": "slideDown",
                              "hideMethod": "slideUp",
                              timeOut: 2000
                          });
                      }
                  }
              });
          });
      });
  </script>
</body>
@endsection
