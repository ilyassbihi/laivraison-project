<!-- resources/views/factures/client.blade.php -->
@extends('layouts.clientDashboard')

@section('content')
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4">
                <span class="text-muted fw-light">Dashboard /</span>
                Factures
            </h4>
        </div>

        <!-- Table to display Factures -->
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Ramassage</th>
                    <th>Total (Dhs)</th>
                    <th>Date de création</th>
                    <th>Date de paiement</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($factures as $facture)
                    <tr>
                        <td>{{ $facture->id }}</td>
                        <td>{{ $facture->client->name }}</td>
                        <td>{{ $facture->ramassage->Ref }}</td>
                        <td>{{ $facture->total }}</td>
                        <td>{{ $facture->created_at }}</td>
                        <td>
                            @if($facture->date_paiement)
                                {{ $facture->date_paiement }}
                            @else
                                - - - -
                            @endif
                        </td>
                        <td>{{ $facture->status->statusfac }}</td>
                        <td>
  <div class="action-icons">
    <a class="btn p-0" href="{{ route('factures.download', $facture->id) }}" title="Bon De Livraison">
      <i class="ti ti-printer me-2"></i>
    </a>
  </div>
</td>

                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

@endsection
