<!-- resources/views/factures/create.blade.php -->
@extends('layouts.clientDashboard')

@section('content')
    <h2>Create Invoice</h2>
    <form method="post" action="{{ route('factures.store') }}">
        @csrf
        <div>
            <label for="client_id">Select Client:</label>
            <select name="client_id" id="client_id">
                @foreach ($clients as $client)
                    <option value="{{ $client->id }}">{{ $client->name }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label for="ramassage_id">Select Ramassage:</label>
            <select name="ramassage_id" id="ramassage_id">
                <!-- Ramassage options will be populated by JavaScript based on the selected client -->
            </select>
        </div>
        <button type="submit">Create Invoice</button>
    </form>

    <script>
        const clients = @json($clients->pluck('id'));
        const ramassages = @json($ramassages);

        document.getElementById('client_id').addEventListener('change', (event) => {
            const selectedClientId = event.target.value;
            const ramassagesDropdown = document.getElementById('ramassage_id');

            // Clear existing options
            ramassagesDropdown.innerHTML = '';

            // Populate ramassage options based on selected client
            ramassages.filter(ramassage => ramassage.idclient === parseInt(selectedClientId)).forEach(ramassage => {
                const option = document.createElement('option');
                option.value = ramassage.id;
                option.textContent = ramassage.Ref;
                ramassagesDropdown.appendChild(option);
            });
        });
    </script>
@endsection
