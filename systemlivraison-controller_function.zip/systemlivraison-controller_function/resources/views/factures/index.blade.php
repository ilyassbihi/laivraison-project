<!-- resources/views/factures/index.blade.php -->
@extends('layouts.clientDashboard')
@section('content')

    <head>
        <title>factures</title>
    </head>

    <body>
        {{-- <h2><a href="{{ route('factures.create') }}">Create Invoice</a></h2> --}}
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span>factures</h4>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewCCModal">
                    Create factures
                </button>
            </div>
            <div class="modal fade" id="addNewCCModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
                    <div class="modal-content p-3 p-md-5">
                        <div class="modal-body">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            <div class="text-center mb-4">
                                <h3 class="mb-2">Add New factures</h3>
                                <p class="text-muted">Add new factures to a client</p>
                            </div>
                            <form method="POST" action="{{ route('factures.store') }}" enctype="multipart/form-data" id="addNewCCForm" class="row g-3">
                              @csrf
                              <div>
                                  <label for="client_id" class="form-label w-100">Select Client:</label>
                                  <select name="client_id" class="select2 form-select form-select-lg" id="client_id">
                                      @foreach ($clients as $client)
                                          <option value="{{ $client->id }}">{{ $client->name }} ({{$client->commends_count }})</option>
                                      @endforeach
                                  </select>
                              </div>
                              <div class="col-12 text-center">
                                  <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                                  <button type="reset" class="btn btn-label-secondary btn-reset" data-bs-dismiss="modal" aria-label="Close">
                                      Cancel
                                  </button>
                              </div>
                          </form>
                          <center class='mt-3'>
 <form action="{{route('factures.jdida')}}" method="post">
              @csrf
             
              <button type="submit" class="btn btn-success"   >tout les client </button>
            </form></center>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12  ">
                    <form action="{{ route('factures.index') }}" method="GET">
                        <div class="d-flex justify-content-md-end">
                            <div id="DataTables_Table_3_filter" class="dataTables_filter">
                                <input type="search" name="search" class="form-control" placeholder="Search By Ref"
                                    aria-controls="DataTables_Table_3">
                            </div>
                            <button type="submit" class="mx-3 btn btn-primary me-sm-3 me-1">Search</button>
                        </div>

                    </form>
                </div>
            </div>
            <table class="table">
                <tr>
                    <th>REF</th>
                    <th>Client</th>
                    <th>Date de creation</th>
                    <th>Date de paiement</th>
                    <th>Status</th>
                    <th>Total (Dhs)</th>
                    <th>Action</th>
                </tr>
                @foreach ($factures as $facture)
                    <tr>
                        <td>{{ $facture->Ref }}</td>
                        <td>{{ $facture->client->name }}</td>
                        <td>{{ $facture->created_at }}</td>
                        <td>
                            @if ($facture->date_paiement)
                                {{ $facture->date_paiement }}
                            @else
                                - - - -
                            @endif
                        </td>
                        <td>
                             @if( $facture->statusfacturs !== 1)
                             @if( $facture->statusfacturs !== 1)
                            <select class="form-select status-select" data-facture-id="{{ $facture->id }}">
                                @foreach ($status_factures as $status)
                                    <option value="{{ $status->id }}"
                                        {{ $facture->statusfacturs == $status->id ? 'selected' : '' }}>
                                        {{ $status->statusfac }}</option>
                                @endforeach
                            </select>

                             @else
                                <div class=" text-success">payé</div>
                                @endif

                             @else
                                <div class=" text-success">payé</div>
                                @endif
                        </td>

                        <td>{{ $facture->total }}</td>
                        <td>
                            <a class="dropdown-item" href="{{ route('factures.preview', $facture->id) }}" target="_blank"><i
                                            class="ti ti-printer me-1"></i></a>


                            <!--<div class="dropdown">-->
                            <!--    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"-->
                            <!--        aria-expanded="false">-->
                            <!--        <i class="ti ti-dots-vertical"></i>-->
                            <!--    </button>-->
                            <!--    <div class="dropdown-menu" style="">-->
                            <!--        <a class="dropdown-item" href="{{ route('factures.download', $facture->id) }}"><i-->
                            <!--                class="ti ti-pencil me-1"></i>Bon De Livraison</a>-->
                            <!--        <a class="dropdown-item" href="{{ route('factures.download', $facture->id) }}"><i-->
                            <!--                class="ti ti-pencil me-1"></i>Bon De Livraison</a>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </td>
                    </tr>
                @endforeach
            </table>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            $(document).ready(function() {
                const clients = @json($clients->pluck('id'));
                const ramassages = @json($ramassages);

                $('#client_id').change(function(event) {
                    const selectedClientId = parseInt($(this).val());
                    const ramassagesDropdown = $('#ramassage_id');

                    // Clear existing options
                    ramassagesDropdown.empty();

                    // Populate ramassage options based on selected client
                    ramassages.forEach(ramassage => {
                        if (ramassage.idclient === selectedClientId) {
                            ramassagesDropdown.append($('<option>', {
                                value: ramassage.id,
                                text: ramassage.Ref
                            }));
                        }
                    });
                });

                $('.status-select').change(function() {
                    var statusId = $(this).val();
                    var factureId = $(this).data('facture-id');
                    $.ajax({
                        url: '/factures/update-status',
                        type: 'POST',
                        data: {
                            facture_id: factureId,
                            status_id: statusId,
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            console.log(response);
                             location.reload();
                             location.reload();
                        }
                    });
                });

                $('.btn-date-paiement').click(function() {
                    var factureId = $(this).data('facture-id');
                    var paymentDate = prompt('Enter payment date (YYYY-MM-DD)');
                    $.ajax({
                        url: '/factures/update-payment-date',
                        type: 'POST',
                        data: {
                            facture_id: factureId,
                            payment_date: paymentDate,
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            console.log(response);
                            location.reload();
                        }
                    });
                });

                $('#addNewCCForm').submit(function(event) {
                    event.preventDefault();

                    var formData = new FormData($(this)[0]);

                    $.ajax({
                        type: 'POST',
                        url: "{{ route('factures.store') }}",
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            if (response.success) {
                                toastr.success('Good Job.', 'Product Has Been Requested!', {
                                    "showMethod": "slideDown",
                                    "hideMethod": "slideUp",
                                    timeOut: 2000
                                });
                                location.reload();
                            }
                            console.log(response);
                        },
                        error: function(xhr) {
                            if (xhr.status === 422) {
                                // Validation errors occurred
                                var errors = xhr.responseJSON.errors;

                                // Display each error
                                for (var field in errors) {
                                    toastr.warning('Good Job.', 'Opps ' + errors[field][0], {
                                        "showMethod": "slideDown",
                                        "hideMethod": "slideUp",
                                        timeOut: 4000
                                    });
                                }
                            } else {
                                // Other types of errors
                                toastr.warning('Good Job.', 'Opps Something went wrong!', {
                                    "showMethod": "slideDown",
                                    "hideMethod": "slideUp",
                                    timeOut: 2000
                                });
                            }
                            console.log(xhr);
                        }
                    });
                });
            });
        </script>

    </body>
@endsection
