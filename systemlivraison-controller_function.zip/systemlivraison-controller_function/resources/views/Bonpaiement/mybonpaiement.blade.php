@extends('layouts.clientDashboard')
@section('content')

<head>
    <title>factures</title>
</head>

<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span>Bonpaiement</h4>
        </div>

        <div class="row">
            <div class="col-12">
                <form action="{{ route('factures.index') }}" method="GET">
                    <div class="d-flex justify-content-md-end">
                        <div id="DataTables_Table_3_filter" class="dataTables_filter">
                            <input type="search" name="search" class="form-control" placeholder="Search By Ref" aria-controls="DataTables_Table_3">
                        </div>
                        <button type="submit" class="mx-3 btn btn-primary me-sm-3 me-1">Search</button>
                    </div>
                </form>
            </div>
        </div>
        <table class="table">
            <tr>
                <th>REF</th>
                <th>Date de creation</th>
                <th>Date de paiement</th>
                <th>Reçu</th>
                <th>Status</th>
                <th>Total (Dhs)</th>
                <th>Action</th>
            </tr>
            @foreach ($bones as $facture)
                <tr>
                    <td>{{ $facture->Ref }}</td>
                    <td>{{ $facture->created_at }}</td>
                    <td>
                        @if ($facture->date_paiement)
                            {{ $facture->date_paiement }}
                        @else
                            - - - -
                        @endif
                    </td>
                    <td>
                        @if ($facture->recu_pye)
                            <a href="{{ asset('storage/' . $facture->recu_pye) }}" target="_blank">View Reçu</a>
                        @else
                            No Reçu

                        <form method="POST" class="upload-recu-form" enctype="multipart/form-data">
                            @csrf
                            <input type="file" name="recu_pye" class="form-control mt-2 upload-recu" data-facture-id="{{ $facture->id }}">
                        </form>
                        @endif
                    </td>
                    <td>
                        @if ($facture->statusfacturs !== 1)
                            <select class="form-select status-select" data-facture-id="{{ $facture->id }}">
                                @foreach ($status_factures as $status)
                                    <option value="{{ $status->id }}" {{ $facture->statusfacturs == $status->id ? 'selected' : '' }}>
                                        {{ $status->statusfac }}
                                    </option>
                                @endforeach
                            </select>
                        @else
                            <div class="text-success">payé</div>
                        @endif
                    </td>
                    <td>{{ $facture->total }}</td>
                    <td>
                        <a class="dropdown-item" href="{{ route('Bonpaiement.download', $facture->id) }}"><i class="ti ti-printer"></i> </a>
                    </td>
                </tr>
            @endforeach
        </table>
    </div>
</body>
<script>
  $(document).ready(function() {
      $('.upload-recu').change(function() {
          var form = $(this).closest('form');
          var formData = new FormData(form[0]);
          var factureId = $(this).data('facture-id');

          $.ajax({
              url: '/bonpaiement/' + factureId + '/update-recu',
              method: 'POST', // Still send as POST, but we will override method to PUT
              data: formData,
              processData: false,
              contentType: false,
              headers: {
                  'X-HTTP-Method-Override': 'PUT' // Override method to PUT
              },
              success: function(response) {
                  location.reload(); // Optionally reload the page or update the UI dynamically
              },
              error: function(xhr, status, error) {
                  alert('Error updating Reçu.');
                  console.error(error);
              }
          });
      });

      $('.status-select').change(function() {
          var statusId = $(this).val();
          var factureId = $(this).data('facture-id');

          $.ajax({
              url: '/factures/update-status',
              type: 'POST',
              data: {
                  facture_id: factureId,
                  status_id: statusId,
                  _token: '{{ csrf_token() }}'
              },
              success: function(response) {
                  console.log(response);
                  location.reload();
              }
          });
      });
  });

  function runScheduler() {
      $.ajax({
          url: '/run-scheduler',
          type: 'GET',
          success: function(response) {
              console.log('Scheduler executed successfully:', response);
          },
          error: function(xhr, status, error) {
              console.error('Error executing scheduler:', status, error);
          }
      });
  }

  function refreshEveryEvenMinute() {
      var now = new Date();
      var seconds = now.getSeconds();
      var millisecondsToNextMinute = (60 - seconds) * 1000;
      var millisecondsToNextEvenMinute = millisecondsToNextMinute + (2 * 60 * 1000) - (millisecondsToNextMinute % (2 * 60 * 1000));
      setTimeout(function() {
          setInterval(runScheduler, 2 * 60 * 1000); // Run every even minute
          runScheduler(); // Initial call to run the scheduler immediately
      }, millisecondsToNextEvenMinute);
  }

  // Call the function to start refreshing every even minute
  refreshEveryEvenMinute();
</script>


@endsection
