<!-- resources/views/factures/index.blade.php -->
@extends('layouts.clientDashboard')
@section('content')

    <head>
        <title>factures</title>
    </head>

    <body>
        {{-- <h2><a href="{{ route('factures.create') }}">Create Invoice</a></h2> --}}
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span>Bonpaiement</h4>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewCCModal">
                    Créer bon de paiment
                </button>
            </div>
            <div class="modal fade" id="addNewCCModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
                    <div class="modal-content p-3 p-md-5">
                        <div class="modal-body">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            <div class="text-center mb-4">
                                <h3 class="mb-2">Add New bon de paiment</h3>
                                <p class="text-muted">Add new bon paiment</p>
                            </div>
                            <form method="POST" action="{{ route('Bonpaiement.store') }}" enctype="multipart/form-data" id="addNewCCForm" class="row g-3">
                              @csrf
                              <div>
                                  <label for="livereur" class="form-label w-100">Select Client:</label>
                                  <select name="livreur" class="select2 form-select form-select-lg" id="client_id">
                                      @foreach ($clients as $client)
                                          <option value="{{ $client->id }}">{{ $client->name }} ({{$client->commends_count }})</option>
                                      @endforeach
                                  </select>
                              </div>
                              <div class="col-12 text-center">
                                  <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                                  <button type="reset" class="btn btn-label-secondary btn-reset" data-bs-dismiss="modal" aria-label="Close">
                                      Cancel
                                  </button>
                              </div>
                          </form>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12  ">
                    <form action="{{ route('factures.index') }}" method="GET">
                        <div class="d-flex justify-content-md-end">
                            <div id="DataTables_Table_3_filter" class="dataTables_filter">
                                <input type="search" name="search" class="form-control" placeholder="Search By Ref"
                                    aria-controls="DataTables_Table_3">
                            </div>
                            <button type="submit" class="mx-3 btn btn-primary me-sm-3 me-1">Search</button>
                        </div>

                    </form>
                </div>
            </div>
            <table class="table">
                <tr>
                    <th>REF</th>
                    <th>Client</th>
                    <th>Date de creation</th>
                    <th>Date de paiement</th>
                    <th>Status</th>
                    <th>Total (Dhs)</th>
                    <th>Action</th>
                </tr>
                @foreach ($factures as $facture)
                    <tr>
                        <td>{{ $facture->Ref }}</td>
                        <td>{{ $facture->client->name }}</td>
                        <td>{{ $facture->created_at }}</td>
                        <td>
                            @if ($facture->date_paiement)
                                {{ $facture->date_paiement }}
                            @else
                                - - - -
                            @endif
                        </td>
                        <td>
                             @if( $facture->statusfacturs !== 1)
                             @if( $facture->statusfacturs !== 1)
                            <select class="form-select status-select" data-facture-id="{{ $facture->id }}">
                                @foreach ($status_factures as $status)
                                    <option value="{{ $status->id }}"
                                        {{ $facture->statusfacturs == $status->id ? 'selected' : '' }}>
                                        {{ $status->statusfac }}</option>
                                @endforeach
                            </select>

                             @else
                                <div class=" text-success">payé</div>
                                @endif

                             @else
                                <div class=" text-success">payé</div>
                                @endif
                        </td>

                        <td>{{ $facture->total }}</td>
                        <td>
                            <a class="dropdown-item" href="{{ route('Bonpaiement.download', $facture->id) }}"><i class="ti ti-printer"></i> </a>


                        </td>
                    </tr>
                @endforeach
            </table>
        </div>


    </body>
@endsection
