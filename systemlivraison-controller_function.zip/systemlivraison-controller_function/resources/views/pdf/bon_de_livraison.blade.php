@extends('layouts.pdfTemplate')
@section('content')
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row invoice-preview">
                <!-- Invoice -->
                <div class="col-xl-9 col-md-8 col-12 mb-md-0 mb-4">
                    <div class="card invoice-preview-card" id="invoice">
                        <div class="ticket">
        <div class="d-flex justify-content-between">
            <div>
                <img src="{{asset('3taqny.png')}}" width="50px" height="50px" alt="Logo">
            </div>
            <div class="text-right ">
                <h4 class="mb-0"><strong>3taqny</strong></h4>
            </div>
        </div> 
        <hr>
        <div class="ticket-body">
            <div class="row">
                <div class="col-sm-6">
                    <div class="section-title">Destinataire:</div>
                    <p class="mb-0"><strong>Nom complet:</strong> {{$commend->Destinataire}}</p>
                    <p class="mb-0"><strong>Adresse:</strong> {{$commend->Adresse}}</p>
                    <p class="mb-0"><strong>Ville:</strong> {{$commend->villee->ville}}</p>
                    <p class="mb-0"><strong>Tél:</strong> {{$commend->TéléphoneD}}</p>
                </div>
                <div class="col-sm-6 text-right">
                    <p class="mb-0"><strong>Date:</strong> {{$commend->created_at}}</p>
                    <p class="mb-0"><strong>Store:</strong> 3taqny</p>
                    <p class="mb-0"><strong>Produit:</strong>{{$commend->Namepr}}</p>
                    <div>
                        @if ($commend->package_opened)
                            <input type="checkbox" disabled checked id="openParcel">
                             <label for="openParcel">Ouvrir le colis</label>
                            @else
                             <input type="checkbox" disabled  id="openParcel">
                             <label for="openParcel">Ouvrir le colis</label>
                        @endif
                        @if ($commend->exchange_requested)
                            <input type="checkbox" checked disabled id="changeParcel">
                        <label for="changeParcel">Change</label>
                        @else
                             <input type="checkbox"  disabled  id="changeParcel">
                        <label for="changeParcel">Change</label>
                        @endif
                        
                       
                        
                    </div>
                </div>
            </div>
            <hr>
            <div class="row mt-3">
                <div class="col-sm-6">
                    <div class="total-amount">Total : {{$commend->Prix}} DH</div>
                </div>
                <div class="col-sm-6 text-right">
                    <div class="barcode">
                        <img src="https://via.placeholder.com/150x50" alt="Barcode">
                    </div>
                    <p class="mb-0">CMD-03052024-07510</p>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6">
                <p class="mb-0">3taqny Vous remercie pour votre confiance.</p>
                <p class="mb-0">Service après-vente :</p>
                <p class="mb-0"><strong>06XXXXXXXX</strong></p>
            </div>
            <div class="qr-code col-sm-6">
                <img src="https://via.placeholder.com/50x50" alt="QR Code">
            </div>
        </div>
        <hr>
    </div>
                    </div>
                </div>
                <!-- /Invoice -->

                <!-- Invoice Actions -->
                <div class="col-xl-3 col-md-4 col-12 invoice-actions">
                    <div class="card">
                        <div class="card-body">
                            <button class="btn btn-primary d-grid w-100 mb-2"
                                onclick="PrintElem('invoice')">Download</button>
                        </div>
                    </div>
                </div>
                <!-- /Invoice Actions -->
            </div>

            <!-- Offcanvas -->



            <!-- /Offcanvas -->
        </div>
        <!-- / Content -->



        <div class="content-backdrop fade"></div>
    </div>

    <script>
        function PrintElem(elem) {

            var bodyInner = document.body.innerHTML;

            document.body.innerHTML = '<div class="card-body row">' + document.getElementById(elem).innerHTML +
                '<style>*{color: #000!important;}</style> </div>';

            window.print();

            document.body.innerHTML = bodyInner;

            return true;
        }
    </script>
<style>
        .ticket {
            border: 2px solid #333;
            padding: 20px;
            max-width: 800px;
            margin: auto;
            font-size: 14px;
            font-family: Arial, sans-serif;
        }

        .ticket-header, .ticket-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .ticket-body {
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .ticket-header img {
            max-height: 50px;
        }

        .ticket-footer {
            
            
            margin-top: 20px;
        }

        .barcode img, .qr-code img {
            max-width: 100%;
            height: auto;
        }

        .total-amount {
            font-size: 1.5em;
            font-weight: bold;
        }

        .section-title {
            font-size: 1.1em;
            font-weight: bold;
            margin-bottom: 10px;
        }
    </style>
    
@endsection
