<!DOCTYPE html>
<html>

<head>
    <title>Commend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(0, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .col-6 {
            width: 50%;
            float: left;
            box-sizing: border-box;
        }

        .mb-4 {
            margin-bottom: 20px;
        }

        img {
            height: 60px;
            width: 60px;
        }

        p {
            margin-bottom: 0;
        }

        .smallerf {
            font-size: 13px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        th:first-child,
        td:first-child {
            text-align: center;
        }

        .text-right {
            text-align: right;
        }

        hr {
            margin-top: 20px;
            margin-bottom: 20px;
            border: none;
            border-top: 1px solid #000;
        }
    </style>
</head>

<body class="mx-3">
    <div class="mt-3 mb-4">
        <center>
            <div class="" style="margin-bottom: 20px">
                <img src="{{asset('images/logooo.png')}}" alt="">
            </div>
            <div class=" ">
                <p class=""><b>3taqny </b></p>
                <p class="smallerf">Adresse: Benslimane </p>
                <p class="smallerf">Telephone: + 212 673 270 114 </p>
                <p class="smallerf">Email: Contact@3taqny.com </p>
                <p class="smallerf">Web site: <a href="https://3taqny.com/">https://3taqny.com//</a></p>
            </div>
        </center>
    </div>
    <hr>
    <table class="table">
        <thead>
            <tr>
                <th>Ref</th>
                <th>Ville</th>
                <th>Client</th>
                <th>Telephone</th>
                <th>Adresse</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{{$commend->QRcodeCommand}}</td>
                <td>{{$commend->villee->ville}}</td>
                <td>{{$commend->Destinataire}}</td>
                <td>{{$commend->TéléphoneD}}</td>
                <td>{{$commend->Adresse}}</td>
                <td>{{$commend->Prix}} DH</td>
            </tr>
            <tr>
                <th colspan="5">Total</th>
                <td>{{$commend->Prix}} DH</td>
            </tr>
        </tbody>
    </table>
    <p><b>Remarque:</b> {{$commend->Commentaire}}</p>
</body>

</html>
