<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>bon de paiment</title>
    <style>
        table {
           width: 100%;
           border-collapse: collapse;
           margin-bottom: 20px;
       }
       th, td {
           border: 1px solid black;
           padding: 8px;
           text-align: left;
       }
       th {
           background-color: #f2f2f2;
       }
   </style>
</head>
<body>
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between">
                        <div>
                            <img src="{{asset('3taqny.png')}}" height="80px" width="80px" alt="">
                            <div>Mohamed Lamkimli<br>+212 673-270114</div>
                        </div>
                        <div>
                            My Express Delivery<br>+212 669969587<br>+212 674923539
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-center">Facture N°: 582393270424</h5>
                    <p class="text-center">Payé<br>27-04-2024</p>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Commande No.</th>
                                <th>Client</th>
                                <th>Total</th>
                                <th>Frais livreur</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($commends as $item)
                            <tr>
                                <td>{{$item->QRcodeCommand}}</td>
                                <td>{{$item->client->name}} {{$item->client->telephone}}</td>
                                <td>{{$item->Prix}}</td>
                                <td>{{optional($item->livreur)->commistion}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3">Total des commandes</th>
                                <td>{{$Bonpaiement->total}}</td>
                            </tr>
                            <tr>
                                <th colspan="3">Frais du livreur</th>
                                <td>{{ $commends->sum(fn($item) => optional($item->livreur)->commistion) }}</td>
                            </tr>
                            <tr>
                                <th colspan="3">Reste</th>
                                <td>{{ $Bonpaiement->total - $commends->sum(fn($item) => optional($item->livreur)->commistion) }}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="card-footer text-center">
                    Merci pour votre confiance
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
