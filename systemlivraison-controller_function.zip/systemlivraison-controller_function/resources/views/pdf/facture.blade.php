<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
         table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
     <div>
       <center><img src="{{asset('3taqny.png')}}" height="80px" width="80px" alt=""></center>
    </div>
    <h2>Invoice</h2>
    <p>Client: {{ $facture->client->name }}</p>
    <table >
        <tr>
            <th>ID</th>
            <th>QRcodeCommand</th>
            <th>Ville</th>
            <th>Tariff (Dhs)</th>
            <th>Prix (Dhs)</th>
            <th>Total (Dhs)</th>
            <th>Status</th>
        </tr>
        @php
            $total = 0;
        @endphp
        @foreach ($selected_commends as $commend_id)
        @php
            $commend = App\Models\Commend::find($commend_id);
            $subtotal = 0;
            if ($commend->statusCommend->statusC === 'Annulée') {
                $subtotal = -5; 
            } else {
                $subtotal = $commend->Prix - $commend->tariff; 
            }
            $total += $subtotal;
        @endphp
        <tr>
            <td>{{ $commend->id }}</td>
            <td>{{ $commend->QRcodeCommand }}</td>
            <td>{{ $commend->villee->ville }}</td>
            <td>{{ $commend->tariff }}</td>
            <td>{{ $commend->Prix }}</td>
            <td>{{ $subtotal }}</td>
            <td>{{ $commend->statusCommend->statusC }}</td>
        </tr>
        @endforeach

        <tr>
            <td colspan="5" style="text-align: right;">Total</td>
            <td>{{ $total }}</td>
        </tr>
    </table>

</body>
</html>
