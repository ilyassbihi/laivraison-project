@extends('layouts.pdfTemplate')
@section('content')
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row invoice-preview">
                <!-- Invoice -->
                <div class="col-xl-9 col-md-8 col-12 mb-md-0 mb-4">
                    <div class="card invoice-preview-card" id="invoice">
                        <div class="card-body">
                            <div
                                class="d-flex justify-content-between flex-xl-row flex-md-column flex-sm-row flex-column m-sm-3 m-0">
                                <div class="mb-xl-0 mb-4">
                                    <div class="d-flex svg-illustration mb-4 gap-2 align-items-center">
                                        <img src="{{asset('3taqny.png')}}" width="50" height="50" alt="">

                                        <span class="app-brand-text fw-bold fs-4"> 3taqny </span>
                                    </div>
                                    <p class="mb-2">Bd Hassan II, Benslimane 13000</p>
                                    <p class="mb-2">Maroc</p>
                                    <p class="mb-0">+212 688561491</p>
                                </div>
                                <div>
                                    <h4 class="fw-semibold mb-2">INVOICE #{{ $facture->Ref }}</h4>
                                    <div class="mb-2 pt-1">
                                        <span>Creation Date:</span>
                                        <span class="fw-semibold">{{ $facture->created_at }}</span>
                                    </div>
                                    <div class="pt-1">
                                        <span>Paiement Date:</span>
                                        <span class="fw-semibold">{{ $facture->date_paiement }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr class="my-0" />
                        <div class="card-body">
                            <div class="row p-sm-3 p-0">
                                <div class="col-xl-6 col-md-12 col-sm-5 col-12 mb-xl-0 mb-md-4 mb-sm-0 mb-4">
                                    <h6 class="mb-3">Invoice To:</h6>
                                    <p class="mb-1">{{ $facture->client->name }}</p>
                                    <p class="mb-1">{{ $facture->client->Address }}</p>
                                    <p class="mb-1">{{ $facture->client->telephone }}</p>
                                    <p class="mb-1">{{ $facture->client->email }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive border-top">
                            <table class="table m-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>QRcodeCommand</th>
                                        <th>Ville</th>
                                        <th>Tariff (Dhs)</th>
                                        <th>Prix (Dhs)</th>
                                        <th>Total (Dhs)</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php
                                        $total = 0;
                                    @endphp
                                    @foreach ($selected_commends as $commend_id)
                                        @php
                                            $commend = App\Models\Commend::find($commend_id);
                                            $subtotal = 0;
                                            if ($commend->statusCommend->statusC === 'Annulée') {
                                                $subtotal = -5;
                                            } else {
                                                $subtotal = $commend->Prix - $commend->tariff;
                                            }
                                            $total += $subtotal;
                                        @endphp
                                        <tr>
                                            <td>{{ $commend->id }}</td>
                                            <td>{{ $commend->QRcodeCommand }}</td>
                                            <td>{{ $commend->villee->ville }}</td>
                                            <td>{{ $commend->tariff }}</td>
                                            <td>{{ $commend->Prix }}</td>
                                            <td>{{ $subtotal }}</td>
                                            <td>{{ $commend->statusCommend->statusC }}</td>
                                        </tr>
                                    @endforeach
                                    <tr>
                                        <td colspan="3" class="align-top px-4 py-4">
                                            <p class="mb-2 mt-3">
                                                <span class="ms-3 fw-semibold">From:</span>
                                                <span>3taqny</span>
                                            </p>
                                            <span class="ms-3">Thanks for your business</span>
                                        </td>
                                        <td class="text-end pe-3 py-4">

                                            <p class="mb-0 pb-3">Total:</p>
                                        </td>
                                        <td class="ps-2 py-4">

                                            <p class="fw-semibold mb-0 pb-3">{{ $total }} DH</p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="card-body mx-3">
                            <div class="row">
                                <div class="col-12">
                                    <span class="fw-semibold">Note:</span>
                                    <span>It was a pleasure working with you and your team. We hope you will keep us in mind
                                        for
                                        future freelance projects. Thank You!</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Invoice -->

                <!-- Invoice Actions -->
                <div class="col-xl-3 col-md-4 col-12 invoice-actions">
                    <div class="card">
                        <div class="card-body">
                            <button class="btn btn-primary d-grid w-100 mb-2"
                                onclick="PrintElem('invoice')">Download</button>
                        </div>
                    </div>
                </div>
                <!-- /Invoice Actions -->
            </div>

            <!-- Offcanvas -->



            <!-- /Offcanvas -->
        </div>
        <!-- / Content -->



        <div class="content-backdrop fade"></div>
    </div>

    <script>
        function PrintElem(elem) {

            var bodyInner = document.body.innerHTML;

            document.body.innerHTML = '<div class="card-body row">' + document.getElementById(elem).innerHTML +
                '<style>*{color: #000!important;}</style> </div>';

            window.print();

            document.body.innerHTML = bodyInner;

            return true;
        }
    </script>
@endsection
