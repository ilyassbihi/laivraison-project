<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bon De Routeur</title>
    <style>
        /* Add your PDF styles here */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .total {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div>
       <center><img src="{{asset('3taqny.png')}}" height="80px" width="80px" alt=""></center> 
    </div>
    <h1>Bon De Routeur</h1>
    <p>Bon De Routeur ID: {{ $bonDeRouteur->id }}</p>
    <p>Date: {{ $bonDeRouteur->created_at }}</p>
    <p>Commends Selected:</p>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>QRcodeCommand</th>
                <th>Ville</th>
                <th>Status</th>
                <th>Fraise  (Dhs)</th>
            </tr>
        </thead>
        <tbody>
            @php
                $total = 0;
                $frise = is_array($selected_commends) ? count($selected_commends) * -10 : 0;
            @endphp
            @if (is_array($selected_commends))
                @foreach ($commends as $commend)
                    <tr>
                        <td>{{ $commend->id }}</td>
                        <td>{{ $commend->QRcodeCommand }}</td>
                        <td>{{ $commend->villee->ville }}</td>
                        <td>{{ $commend->statusCommend->statusC }}</td>
                        <td>-10</td>
                    </tr>
                @endforeach
            @endif
            <tr class="total">
                <td colspan="4" style="text-align: right;">Total Frise</td>
                <td>{{ $frise }}</td>
            </tr>
        </tbody>
    </table>
</body>
</html>
