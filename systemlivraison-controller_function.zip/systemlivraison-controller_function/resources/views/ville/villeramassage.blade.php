@extends('layouts.clientDashboard')
@section('content')
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> all ville Ramassage</h4>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewCCModal">
                Add New ville
            </button>
        </div>
        <div class="modal fade" id="addNewCCModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3 class="mb-2">Add New Ville Ramassage</h3>
                            <p class="text-muted">Add new Ville Ramassage</p>
                        </div>
                        <form method="POST" action="{{ route('villeRamassage.store') }}" enctype="multipart/form-data"
                            id="addNewCCForm" class="row g-3">
                            @csrf
                            <div class="col-12">
                                <label class="form-label w-100" for="modalAddCard">ville Ramassage</label>
                                <div class="input-group input-group-merge">
                                    <input id="modalAddCard" name="villeR" class="form-control credit-card-mask"
                                        type="text" placeholder="ville Ramassage Name"
                                        aria-describedby="modalAddCard2" />
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                            class="card-type"></span></span>
                                </div>
                            </div>


                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                                <button type="reset" class="btn btn-label-secondary btn-reset" data-bs-dismiss="modal"
                                    aria-label="Close">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ville</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>

                @foreach ($villesramassage as $ville)
                    <tr>
                        <td>{{ $ville->id }}</td>
                        <td>{{ $ville->villeR }}</td>
                        <td>
                            <div class="d-flex align-items-center">
    <a href="javascript:void(0);" class="edit-btn me-3 text-decoration-none text-dark" data-id="{{ $ville->id }}" data-ville="{{ $ville->villeR }}">
        <i class="ti ti-pencil"></i> 
    </a>
    <a href="javascript:void(0);" class="delete-btn text-decoration-none text-dark" data-id="{{ $ville->id }}">
        <i class="ti ti-trash"></i> 
    </a>
</div>

<!--                            <div class="dropdown">-->
<!--                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"-->
<!--                                    aria-expanded="false">-->
<!--                                    <i class="ti ti-dots-vertical"></i>-->
<!--                                </button>-->
<!--                                <div class="dropdown-menu" style="">-->
<!--                                   <a class="dropdown-item edit-btn" href="javascript:void(0);" data-id="{{ $ville->id }}" data-ville="{{ $ville->villeR }}">-->
<!--    <i class="ti ti-pencil me-1"></i> Edit-->
<!--</a>-->
<!--<a class="dropdown-item delete-btn" href="javascript:void(0);" data-id="{{ $ville->id }}">-->
<!--    <i class="ti ti-trash me-1"></i> Delete-->
<!--</a>-->
<!--                                    </div>-->
<!--                                </div>-->
                            </td></td>
                     </tr>
     @endforeach

            </tbody>
        </table>
    </div>
    <!-- Edit Modal -->
<div class="modal fade" id="editVilleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Ville Ramassage</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editVilleForm">
                <div class="modal-body">
                    <input type="hidden" id="editId" name="id">
                    <div class="form-group">
                        <label for="editVilleName">Ville Name</label>
                        <input type="text" class="form-control" id="editVilleName" name="villeR" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
      $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
    $('.edit-btn').click(function() {
        var id = $(this).data('id');
        var villeR = $(this).data('ville');
        $('#editId').val(id);
        $('#editVilleName').val(villeR);
        $('#editVilleModal').modal('show');
    });

    $('#editVilleForm').submit(function(event) {
        event.preventDefault();
        var id = $('#editId').val();
        var formData = new FormData(this);
        $.ajax({
            type: 'POST',
            url: '/ville-ramassage/update/' + id,
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    location.reload();
                }
            },
            error: function(xhr) {
                toastr.error('Something went wrong.');
            }
        });
    });
    $('.delete-btn').click(function() {
    if (confirm('Are you sure?')) {
        var id = $(this).data('id');
        $.ajax({
            type: 'DELETE',
            url: '/ville-ramassage/destroy/' + id,
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    location.reload();
                }
            },
            error: function() {
                toastr.error('Failed to delete.');
            }
        });
    }
});

});
</script>

    <script>
        $(document).ready(function() {
            $('#addNewCCForm').submit(function(event) {
                event.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: 'POST',
                    url: "{{ route('villeRamassage.store') }}",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastr.success('Good Job.', 'Product Has Been Requested!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                            location.reload();
                        }
                        console.log(response);
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            // Validation errors occurred
                            var errors = xhr.responseJSON.errors;

                            // Display each error
                            for (var field in errors) {
                                toastr.warning('Good Job.', 'Opps ' + errors[field][0], {
                                    "showMethod": "slideDown",
                                    "hideMethod": "slideUp",
                                    timeOut: 4000
                                });
                            }
                        } else {
                            // Other types of errors
                            toastr.warning('Good Job.', 'Opps Something went wrong!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                        }
                        console.log(xhr);
                    }
                });
            });
        });
    </script>
    
@endsection
