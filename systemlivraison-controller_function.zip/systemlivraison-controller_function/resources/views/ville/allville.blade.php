@extends('layouts.clientDashboard')
@section('content')
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> all ville</h4>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewCCModal">
                Add New ville
            </button>
        </div>
        <div class="modal fade" id="addNewCCModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3 class="mb-2">Add New Ville</h3>
                            <p class="text-muted">Add new Ville</p>
                        </div>
                        <form method="POST" action="{{ route('ville.store') }}" enctype="multipart/form-data"
                            id="addNewCCForm" class="row g-3">
                            @csrf
                            <div class="col-12">
                                <label class="form-label w-100" for="modalAddCard">ville Name</label>
                                <div class="input-group input-group-merge">
                                    <input id="modalAddCard" name="ville" class="form-control credit-card-mask"
                                        type="text" placeholder="ville Name" aria-describedby="modalAddCard2" />
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                            class="card-type"></span></span>
                                </div>
                            </div>


                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                                <button type="reset" class="btn btn-label-secondary btn-reset" data-bs-dismiss="modal"
                                    aria-label="Close">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Edit Ville Modal -->
        <div class="modal fade" id="editVilleModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <h3 class="mb-2">Edit Ville</h3>
                        <form id="editVilleForm" method="POST" action="{{ route('ville.update', ['id' => 'ID']) }}">
                            @csrf
                            <input type="hidden" id="editVilleId" name="id">
                            <div class="mb-3">
                                <label for="editVilleName" class="form-label">Ville Name</label>
                                <input type="text" class="form-control" id="editVilleName" name="ville" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ville</th>
                    <th>Actions</th>

                </tr>
            </thead>
            <tbody>

                @foreach ($villes as $ville)
                    <tr>
                        <td>{{ $ville->id }}</td>
                        <td>{{ $ville->ville }}</td>
                        <td>
                            <div class="d-flex align-items-center">
    <a href="javascript:void(0);" class="edit-ville me-3 text-decoration-none text-dark" data-id="{{ $ville->id }}" data-ville="{{ $ville->ville }}">
        <i class="ti ti-pencil"></i> 
    </a>
    <a href="javascript:void(0);" class="delete-ville text-decoration-none text-dark" data-id="{{ $ville->id }}">
        <i class="ti ti-trash"></i> 
    </a>
</div>

                            <!--<div class="dropdown">-->
                            <!--    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"-->
                            <!--        aria-expanded="false">-->
                            <!--        <i class="ti ti-dots-vertical"></i>-->
                            <!--    </button>-->
                            <!--    <div class="dropdown-menu" style="">-->
                            <!--        <a class="dropdown-item edit-ville" href="javascript:void(0);"-->
                            <!--            data-id="{{ $ville->id }}" data-ville="{{ $ville->ville }}">-->
                            <!--            <i class="ti ti-pencil me-1"></i> Edit-->
                            <!--        </a>-->

                            <!--        <a class="dropdown-item delete-ville" href="javascript:void(0);"-->
                            <!--            data-id="{{ $ville->id }}">-->
                            <!--            <i class="ti ti-trash me-1"></i> Delete-->
                            <!--        </a>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </td>
                    </tr>
                @endforeach

            </tbody>
        </table>
    </div>
    <script>
        $(document).ready(function() {
            $('#addNewCCForm').submit(function(event) {
                event.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: 'POST',
                    url: "{{ route('ville.store') }}",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastr.success('Good Job.', 'Ville Has Been Added!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                            location.reload();
                        }
                        console.log(response);
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            // Validation errors occurred
                            var errors = xhr.responseJSON.errors;

                            // Display each error
                            for (var field in errors) {
                                toastr.warning('Good Job.', 'Opps ' + errors[field][0], {
                                    "showMethod": "slideDown",
                                    "hideMethod": "slideUp",
                                    timeOut: 4000
                                });
                            }
                        } else {
                            // Other types of errors
                            toastr.warning('Good Job.', 'Opps Something went wrong!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                        }
                        console.log(xhr);
                    }
                });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            // Update functionality
            $('.edit-ville').click(function() {
                var id = $(this).data('id');
                var villeName = $(this).data('ville');
                $('#editVilleId').val(id);
                $('#editVilleName').val(villeName);
                $('#editVilleModal').modal('show');
            });

            $('#editVilleForm').submit(function(event) {
                event.preventDefault();
                var formData = new FormData(this);
                var idville = $('#editVilleId').val();

                $.ajax({
                    type: 'POST',
                    url: "{{ route('ville.update', ['id' => 'ID']) }}".replace('ID',
                    idville), // Replace 'ID' placeholder with the actual id value
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            location.reload();
                        }
                    },
                    error: function(xhr) {
                        var errors = xhr.responseJSON.errors;
                        $.each(errors, function(key, value) {
                            toastr.error(value);
                        });
                    }
                });
            });

            // Delete functionality
            $('.delete-ville').click(function() {
                if (confirm('Are you sure?')) {
                    var id = $(this).data('id');

                    $.ajax({
                        type: 'DELETE',
                        url: '/ville/destroy/' + id,
                        success: function(response) {
                            toastr.success(response.message);
                            location.reload();
                        },
                        error: function(xhr) {
                            toastr.error('Something went wrong!');
                        }
                    });
                }
            });
        });
    </script>
@endsection
