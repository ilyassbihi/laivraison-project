@php
    $customizerHidden = 'customizer-hide';
@endphp

@extends('layouts.blankLayout')

@section('title', 'Register Basic - Pages')

@section('vendor-style')
    <!-- Vendor -->
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/formvalidation/dist/css/formValidation.min.css') }}" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
@endsection

@section('page-style')
    <!-- Page -->
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/select2/select2.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/css/pages/page-auth.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
@endsection

@section('vendor-script')
    <script src="{{ asset('assets/vendor/libs/select2/select2.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/tagify/tagify.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/formvalidation/dist/js/FormValidation.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/formvalidation/dist/js/plugins/Bootstrap5.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/formvalidation/dist/js/plugins/AutoFocus.min.js') }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset('assets/js/pages-auth.js') }}"></script>
    <script src="{{ asset('assets/js/forms-selects.js') }}"></script>
    <script src="{{ asset('assets/js/forms-tagify.js') }}"></script>
    <script src="{{ asset('assets/js/forms-typeahead.js') }}"></script>
    <script>
        $(document).ready(function(){
            $('#privacy-policy-modal').on('shown.bs.modal', function () {
                $('#privacy-policy-modal').trigger('focus')
            });
        });
    </script>
@endsection

@section('content')
    <div class="container-xxl">
        <a href="{{route('home.index')}}" class="btn btn-primary fixed-button">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" width='28px' height='28px'>
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 15 3 9m0 0 6-6M3 9h12a6 6 0 0 1 0 12h-3" />
            </svg>
            <span class="m-2">Back To Home</span>
        </a>
        <div class="authentication-wrapper authentication-basic container-p-y">
            <div class="authentication-inner py-4">
                <!-- Register Card -->
                <div class="card">
                    <div class="card-body">
                        <!-- Logo -->
                        <div class="app-brand justify-content-center mb-4 mt-2">
                            <a href="{{ url('/') }}" class="app-brand-link gap-2">
                                <span class="app-brand-logo demo"><img class="w-10" src="{{ asset('3taqny.png') }}"
                            style=" width: 50px; " /></span>
                                <span class="app-brand-text demo text-body fw-bold ms-1">3taqny</span>
                            </a>
                        </div>
                        <!-- /Logo -->
                        <h4 class="mb-1 pt-2">Devenir Client 🚀</h4>
                        <p class="mb-4">Enter Your Informations!</p>
                        <form id="formAuthentication" class="mb-3" action="{{ route('register') }}" method="POST">
                          @csrf
                            <div class="mb-3">
                                <label for="nom" class="form-label">Nom Complet <b>*</b></label>
                                <input type="text" class="form-control" id="nom" name="name"
                                    placeholder="Nom Complet" autofocus>
                            </div>
                            <div class="mb-3">
                                <label for="numero" class="form-label">Numéro de téléphone personnel <b>(Préférable avec
                                        WhatsApp)*</b></label>
                                <input type="text" class="form-control" id="numero" name="telephone"
                                    placeholder="Numéro de téléphone personnel">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Adresse email <b>*</b></label>
                                <input type="text" class="form-control" id="email" name="email"
                                    placeholder="Adresse email">
                            </div>
                            <div class="mb-3">
                                <label for="CIN" class="form-label">C.I.N <b>*</b></label>
                                <input type="text" class="form-control" id="CIN" name="CIN"
                                    placeholder="C.I.N">
                            </div>
                            <div class="mb-3">
                                <label for="ville" class="form-label">Ville <b>*</b></label>
                                <select id="ville" name="ville" class="select2 form-select form-select-lg"
                                    data-allow-clear="true">
                                    @foreach ($villes as $ville)
                                      <option value="{{$ville->id}}">{{$ville->ville}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-3 form-password-toggle">
                                <label class="form-label" for="password">Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="password" class="form-control" name="password"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        aria-describedby="password" />
                                    <span class="input-group-text cursor-pointer"><i class="ti ti-eye-off"></i></span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="terms-conditions"
                                        name="terms">
                                    <label class="form-check-label" for="terms-conditions">
                                        I agree to
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#privacy-policy-modal">privacy policy & terms</a>
                                    </label>
                                </div>
                            </div>
                            <button class="btn btn-primary d-grid w-100" type="submit">
                                Devenir Client
                            </button>
                        </form>
                    </div>
                </div>
                <!-- Register Card -->
            </div>
        </div>
    </div>

    <!-- Privacy Policy & Terms Modal -->
    <div class="modal fade" id="privacy-policy-modal" tabindex="-1" aria-labelledby="privacy-policy-modal-label" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="privacy-policy-modal-label">Privacy Policy & Terms</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                  <h5>Privacy Policy</h5>
                  <p>We take your privacy seriously. This Privacy Policy describes how we collect, use, and disclose your personal information when you use our services.</p>
                  <h6>Information We Collect</h6>
                  <p>We collect the following types of information when you use our services:</p>
                  <ul>
                      <li>Name</li>
                      <li>Email address</li>
                      <li>Phone number</li>
                      <li>Address</li>
                      <li>...</li>
                  </ul>
                  <h6>How We Use Your Information</h6>
                  <p>We use your information to:</p>
                  <ul>
                      <li>Provide and improve our services</li>
                      <li>Communicate with you</li>
                      <li>Process transactions</li>
                      <li>...</li>
                  </ul>
                  <h6>Sharing Your Information</h6>
                  <p>We may share your information with:</p>
                  <ul>
                      <li>Third-party service providers</li>
                      <li>Law enforcement agencies</li>
                      <li>...</li>
                  </ul>
                  <h6>Terms of Service</h6>
                  <p>By using our services, you agree to abide by our Terms of Service. Please read them carefully.</p>
                  <h6>Changes to This Privacy Policy and Terms of Service</h6>
                  <p>We may update our Privacy Policy and Terms of Service from time to time. Any changes will be posted on this page.</p>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
          </div>
      </div>
  </div>

    <!-- /Privacy Policy & Terms Modal -->
@endsection
