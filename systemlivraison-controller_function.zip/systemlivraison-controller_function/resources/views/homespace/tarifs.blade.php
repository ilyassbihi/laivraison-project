@extends('layouts.app')

@section('content')
    <div id="Tarifs" class="padding-5 mx-5 min-vh-100 ">
        <div class="section-title text-center">
            <h2 style="color: #e93c02">Nos Tarifs</h2>
        </div>

<div class="my-3 ">
    <form action="{{ route('home.tarifs') }}" method="GET" class="d-flex flex-column flex-sm-row align-items-end">
        <select class="form-select me-sm-2 mb-2 mb-sm-0" name="OriginCity" aria-label="Default select example" style="flex-grow: 1;">
            <option disabled selected>Select Ramassage Ville</option>
            @foreach ($villesramassage as $ville)
                <option value="{{ $ville->id }}" {{ request('OriginCity') == $ville->id ? 'selected' : '' }}>
                    {{ $ville->villeR }}
                </option>
            @endforeach
        </select>
        <select class="form-select me-sm-2 mb-2 mb-sm-0" name="DestinationCity" aria-label="Default select example" style="flex-grow: 1;">
            <option disabled selected>Select Ville</option>
            @foreach ($villes as $ville)
                <option value="{{ $ville->id }}" {{ request('DestinationCity') == $ville->id ? 'selected' : '' }}>
                    {{ $ville->ville }}
                </option>
            @endforeach
        </select>
        <button type="submit" class="btn btn-primary" style="flex-shrink: 0;">Search</button>
    </form>
</div>





        <table class="table mx-3">
            <tr>

                <th>From</th>
                <th>To</th>
                <th>Tarifs</th>
            </tr>
            @foreach ($tarifs as $tarif)
                <tr>

                    <td><i>{{ $tarif->originCity->villeR }}</i></td>
                    <td><i>{{ $tarif->destinationCity->ville }}</i></td>
                    <td>{{ $tarif->tariff }} DH</td>
                </tr>
            @endforeach

        </table>
        <div class="mt-4">
            {{ $tarifs->links('vendor.pagination.bootstrap-5') }}
        </div>


    </div>
    <style>
        .padding-5 {
            padding-top: 100px;
        }
        .min-vh-100 {
    min-height: 100vh;
}
    </style>
@endsection
