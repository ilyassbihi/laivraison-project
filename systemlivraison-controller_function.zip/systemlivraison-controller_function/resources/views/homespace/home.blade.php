@extends('layouts.app')

@section('content')
    <section class="banner" id="Home">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h2>3TAQNY  </h2>
                    <p>Votre nouveau partenaire de livraison offrant les meilleurs services de livraison. Nous proposons la livraison la plus rapide et la plus fiable dans la région métropolitaine et le cœur de la région du Grand Casablanca (Casablanca-Settat), y compris Mohammedia, Benslimane, Bouznika et les environs.</p>
                    <a href="#" class="btnd1">Read More</a>
                </div>
            </div>
        </div>
    </section>
    <section id="Services">
    <div class="section-tittle my-4 text-center" >
        <h2 style="color: #e93c02">Nos Services</h2>
    </div>
        <section id="feature" class="section-p1">
        <div class="fe-box" onmouseover="moveUp(this)" onmouseout="moveDown(this)">
            <img src='{{ asset('images/ramassage.png') }}' alt="" />
            <h6>Ramassage</h6>
            <p>Le ramassage est un service mis en place par la société Sebbar Livraison afin de faciliter au maximum
                votre processus d’expédition.</p>
        </div>
        <div class="fe-box" onmouseover="moveUp(this)" onmouseout="moveDown(this)">
            <img src='{{ asset('images/livraison.jpg') }}' alt="" />
            <h6>Livraison</h6>
            <p>Grâce à une connaissance du terrain, nos livreurs récupèrent les colis pour une livraison en mains
                propres à vos clients dans plusieurs villes.</p>
        </div>
        <div class="fe-box" onmouseover="moveUp(this)" onmouseout="moveDown(this)">
            <img src='{{ asset('images/expidition.png') }}' alt="" />
            <h6>Expédition</h6>
            <p>L’équipe de Sebbar Livraison assure l’acheminement de vos colis à votre destinataire contre un accusé de
                réception.</p>
        </div>
        <div class="fe-box" onmouseover="moveUp(this)" onmouseout="moveDown(this)">
            <img src='{{ asset('images/payment.png') }}' alt="" />
            <h6>Fonds et paiements</h6>
            <p>Nous assure le retour de fonds dans 48 H, des Virements, des bons de livraison d’une manière régulière
                sur les services de messagerie de nos clients.</p>
        </div>
    </section>
    </section>


    <section>
        <div class="tracking-number-area tracking-number-area-five pb-70 pt-70">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <div class="tracking-content">
                            <h2>Veuillez utiliser ce formulaire pour suivre votre commande manuellement</h2>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="tracking-body">
                            {{-- <form action="action?action=tracking" id="tracking-form" method="post" class="tracking-wrap"> --}}
                                <div class="input-group">
                                    <input type="text" class="form-control input-tracking" name="parcel-code"
                                        placeholder="Tapez votre numéro de suivi">
                                    <button class="btn" style="background-color: #000000;color:#ffffff"
                                        ><b>Suivre maintenant</b></button></input>
                                    <div class="input-group-append">

                                    </div>
                                </div>
                            {{-- </form> --}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="About">
            <div class="container mb-5" >
        <div class="section-tittle my-4 text-center">
            <h2 style="color: #e93c02">Qui sommes-nous?</h2>
            <span style="color: gray">En savoir plus sur nous</span>
        </div>
        <div class="row align-items-center">
            <div class="col-lg-6 mb-5 mb-lg-0">
                <div class="about-caption">
                    <p> est une société marocaine officielle, dont le siège est:</p>
                    <p>Bd Hassan II, Benslimane 13000 - MAROC</p>
                    <p>Un grand nombre de distributeurs professionnels ont été formés pour prendre en charge la livraison des commandes des commerçants qui pratiquent l'activité de « paiement à la livraison ».</p>
                    <p>Notre service de livraison et de distribution s'étend à plus de 80 destinations au Maroc.<br>Nous avons pour but principal de

                        Encourager la résolution de tous les problèmes de livraison et d'accroître le taux de livraison.</p> <a href="#" class="btn btn-primary">En savoir davantage sur notre entreprise</a>

                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-img">
                    <img src="{{asset('images/logooo.png')}}" alt="">
                </div>
            </div>
        </div>
    </div>
    </section>
<section  id="Contact">
    <div class="contact-container">
        <div class="contact-form">
            <h2 class="mb-4">Contact Us</h2>
            <form action="{{route('submit.form')}}" method="POST">
              @csrf
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Submit</button>
            </form>
        </div>
    </div>
</section>
<a href="{{route('scheduler')}}" id="scheduler">click me</a>
    </div>
    </div>
    <div id="map" style="height: 500px; width: 80%; margin: 0 auto;"></div>


<script>

    var map = L.map('map').setView([33.618518, -7.129853], 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    var marker = L.marker([33.618518, -7.129853]).addTo(map);
    marker.bindPopup("<b>3TAQNY</b>").openPopup();

</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

{{-- <script>
  $(document).ready(function () {
      // Function to trigger the route via AJAX
      function triggerRoute() {
          $.ajax({
              url: '{{ route("scheduler") }}',
              type: 'GET',
              success: function(response) {
                  console.log('Route triggered successfully');
                  // Reload the page after successful trigger
                  location.reload();
              },
              error: function(xhr, status, error) {
                  console.error('Error triggering route:', error);
              }
          });
      }

      // Function to check current time and trigger the route if it's after the specified time
      function checkAndReloadPage() {
          var targetHour = 19; // Target hour
          var targetMinute = 22; // Target minute

          var currentTime = new Date();
          var currentHour = currentTime.getHours();
          var currentMinute = currentTime.getMinutes();

          // Check if the current time matches the target time
          if (currentHour === targetHour && currentMinute === targetMinute) {
              location.reload();
          } else {
              // Calculate milliseconds until the next target time
              var nextTargetTime = new Date();
              nextTargetTime.setHours(targetHour, targetMinute, 0, 0);
              var millisecondsUntilNextTarget = nextTargetTime - currentTime;

              // Set a timeout to reload the page at the next target time
              setTimeout(reloadPage, millisecondsUntilNextTarget);
          }
      }

      // Call the function to check and trigger the route
      checkAndReloadPage();
  });
</script> --}}


    <style>
        .about-img img {
            width: 100%
        }
    </style>
@endsection
