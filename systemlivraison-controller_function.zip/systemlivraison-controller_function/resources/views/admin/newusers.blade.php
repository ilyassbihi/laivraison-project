@extends('layouts.clientDashboard')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> New Users</h4>
        <div class="card">
            <h5 class="card-header">Table Basic</h5>
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>client</th>
                            <th>Telephone</th>
                            <th>email</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                          @foreach ($clients as $client)
                              
                          <tr>
                              <td>
                                  <i class="bi bi-person"> </i> <strong>{{$client->name}}</strong>
                              </td>
                              <td>{{$client->telephone}}</td>
                              <td>
                            
                                  {{$client->email}}
                              </td>
                              <td><span class="badge bg-label-primary me-1">{{$client->statu->name}}</span></td>
                              <td>
                                  
                                      <a class="btn btn-primary me-2" style="text-decoration: none; " href="{{route("user.details",$client->id)}}">Details</a>
                                 
                              </td>
                          </tr>
                          @endforeach

                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
