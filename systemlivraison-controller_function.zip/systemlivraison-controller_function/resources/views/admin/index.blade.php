@extends('layouts.clientDashboard')
@section('content')
<style>
  small, .small ,h5 {
    color: black;
}
</style>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">

            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: #4FA8E2">
                    <div class="card-body d-flex justify-content-between align-items-center my-2">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$commendsCount}}</h5>
                            <small>Total Commends</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: #43ED11">
                    <div class="card-body d-flex justify-content-between align-items-center my-2">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$CLivreeCount}}</h5>
                            <small>Commends Livrée</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card"  style="background-color: #4FA8E2">
                    <div class="card-body d-flex justify-content-between align-items-center my-2 ">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$ramassageCount}}</h5>
                            <small>nombre de ramassages</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: darkorange">
                    <div class="card-body d-flex justify-content-between align-items-center my-2">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$AttenteRCount}}</h5>
                            <small>En Attente de Ramassage</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: #A1A8B2">
                    <div class="card-body d-flex justify-content-between align-items-center my-2 ">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$RamasseeCount}}</h5>
                            <small>Ramassée</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card"  style="background-color: #CB54FF">
                    <div class="card-body d-flex justify-content-between align-items-center my-2 ">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$userCount}}</h5>
                            <small>Number Users</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card">
                    <div class="card-body d-flex justify-content-between align-items-center my-2 ">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$LivreurCount}}</h5>
                            <small>Number Livreurs</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- <div class="row row-cards mt-5 pb-2 " id="top">
    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate mb-4">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <p class="fw-medium text-muted mb-0">Shipped orders</p>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="shipped-orders" data-target="">3</span></h4>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-light rounded fs-3">
                            <i class="fas fa-dolly-flatbed text-primary icon-dual-primary"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate mb-4">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <p class="fw-medium text-muted mb-0">Processing orders</p>
                    </div>
                    <div class="flex-shrink-0">

                            <h5 class="text-success fs-22 mb-0 processing-orders-percentage">33 %</h5>


                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="processing-orders" data-target="">1</span></h4>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-light rounded fs-3">
                            <i class="fa fa-chart-bar text-warning icon-dual-warning"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate mb-4">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <p class="fw-medium text-muted mb-0">Delivered orders</p>
                    </div>
                    <div class="flex-shrink-0">
                        <h5 class="text-success fs-22 mb-0 delivered-orders-percentage">67 %</h5>

                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="delivered-orders" data-target="">2</span></h4>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-light rounded fs-3">
                            <i class="fas fa-hand-holding text-success icon-dual-success"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->
    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate mb-4">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <p class="fw-medium text-muted mb-0">Returned orders</p>
                    </div>
                    <div class="flex-shrink-0">

                        <h5 class="text-success fs-22 mb-0 returned-orders-percentage">0 %</h5>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="returned-orders" data-target="">0</span></h4>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-light rounded fs-3">
                            <i class="fas fa-arrow-left text-info icon-dual-info"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate mb-4">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <p class="fw-medium text-muted mb-0">Entered leads fees</p>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="entered-leads-fees" data-target="">4</span></h4>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-light rounded fs-3">
                            <i class="fas fa-coins text-primary icon-dual-primary"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate mb-4">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <p class="fw-medium text-muted mb-0">Confirmed leads fees</p>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="confirmed-leads-fees" data-target="">3</span></h4>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-light rounded fs-3">
                            <i class="fas fa-check text-success icon-dual-success"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate mb-4">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <p class="fw-medium text-muted mb-0">Delivered leads fees</p>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="delivered-leads-fees" data-target="">4</span></h4>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-light rounded fs-3">
                            <i class="fas fa-truck text-warning icon-dual-warning"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate mb-4">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <p class="fw-medium text-muted mb-0">Profits</p>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4" id="test">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="profits">70.29</span></h4>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-light rounded fs-3">
                            <i class="fas fa-arrows-alt-v text-dark icon-dual-dark opacity-50"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->
</div> --}}
    </div>
@endsection
