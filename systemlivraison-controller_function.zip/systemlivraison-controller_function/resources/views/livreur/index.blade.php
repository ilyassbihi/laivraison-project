@extends('layouts.clientDashboard')
@section('content')
 <!-- resources/views/commande.blade.php -->


    <div class="container">
         <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span>Liste des ramassages</h4>
        </div>
        <table class="table">
            <thead>
                <tr>
                     <th>Ref</th>
        <th>Téléphone</th>
        <th>Adresse</th>
        <th>Quantité</th>
        <th>Ville</th>
        <th>Status</th>

                </tr>
            </thead>
            <tbody>
                @if (Auth::user())

@foreach($ramassages as $ramassage)
<tr>
    <td>{{ $ramassage->Ref }}</td>
    <td>{{ $ramassage->Téléphone }}</td>
    <td>{{ $ramassage->Adresse }}</td>

    <td>{{ $ramassage->total_product }}</td>



    <td>{{ $ramassage->villee->ville  }}</td>
                                    <td>
                                    @if ($ramassage->status_ramassages == 3)
                                        <span class="badge bg-label-success me-1">{{ $ramassage->statuss->nameR }}</span>
                                    @else
                                        <form id="statusForm_{{ $ramassage->id }}" class="row">
                                            @csrf
                                            @method('PUT')
                                            <div class="col-md-11">

                                                <select name="status" class="form-select"
                                                    onchange="updateStatus('{{ route('updateStatuslivreur', $ramassage->id) }}', this)">
                                                    @foreach ($status as $item)
                                                        @if ($ramassage->status_ramassages == 1 && $item->id == 3)
                                                            @continue
                                                        @elseif ($ramassage->status_ramassages == 2 && $item->id == 1)
                                                            @continue
                                                        @else
                                                            @if ($item->id == $ramassage->status_ramassages)
                                                                <option value="{{ $item->id }}" selected>
                                                                    {{ $item->nameR }}</option>
                                                            @else
                                                                <option value="{{ $item->id }}">{{ $item->nameR }}
                                                                </option>
                                                            @endif
                                                        @endif
                                                    @endforeach

                                                </select>
                                            </div>
                                        </form>
                                    @endif



                                </td>


</tr>
@endforeach
@endif

</div>


<script>
            function updateStatus(url, selectElement) {


            var formData = new FormData(selectElement.form);
            formData.set('status', selectElement.value);
            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    toastr.success('Good Job.', 'Status Has Been Updated!', {
                        "showMethod": "slideDown",
                        "hideMethod": "slideUp",
                        timeOut: 2000
                    });
                    location.reload();
                },
                error: function(xhr, status, error) {
                    // Handle error response if needed
                }
            });
        }
</script>
@endsection
