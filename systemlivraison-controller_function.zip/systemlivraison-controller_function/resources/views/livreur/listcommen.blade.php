<!-- resources/views/livreur/listcommen.blade.php -->

@extends('layouts.clientDashboard')

@section('content')
    <div class="container">
         <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> Commends</h4>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Téléphone</th>
                    <th>Adresse</th>
                    <th>Produit</th>
                    <th>Quantité</th>
                    <th>Prix</th>
                    <th>Commentaire</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach($commands as $command)
                    <tr>
                        <td>{{ $command->id }}</td>
                        <td>{{ $command->TéléphoneD }}</td>
                        <td>{{ $command->Adresse }}</td>
                        <td>{{ $command->Namepr }}</td>
                        <td>{{ $command->Quantite }}</td>
                        <td>{{ $command->Prix }}</td>
                        <td>{{ $command->Commentaire }}</td>
                        <td>
                            <!-- Button to trigger modal -->
                            @if($command->statusCommend->id !== 3)
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#statusModal{{ $command->id }}">
                                    {{ $command->statusCommend->statusC }}
                                </button>
                            @else
                                <div class="col-md-4 mb-3 text-success">livré</div>
                            @endif
                            <!-- Modal -->
                            <div class="modal fade" id="statusModal{{ $command->id }}" tabindex="-1" role="dialog" aria-labelledby="statusModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="statusModalLabel">Change Status</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                @foreach($statuses as $status)
                                                    <div class="col-md-4 mb-3">
                                                        <button type="button" class="btn @if($status->id == 2) btn-danger @elseif($status->id == 8) btn-warning @elseif($status->id == 3) btn-success @else btn-primary @endif w-100" onclick="updateStatus({{ $command->id }}, {{ $status->id }})">{{ $status->statusC }}</button>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

<script>
    function updateStatus(commandId, statusId) {
        $.ajax({
            url: '/update-status',
            type: 'POST',
            data: {
                command_id: commandId,
                status_id: statusId,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                $('#statusModal' + commandId).modal('hide');
                location.reload();
            },
            error: function(xhr, status, error) {
                // Handle error
            }
        });
    }
</script>
