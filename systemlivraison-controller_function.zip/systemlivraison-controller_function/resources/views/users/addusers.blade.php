@extends('layouts.clientDashboard')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span>User Registration</h4>
        </div>
        <div>
            <form method="POST" action="{{route('user.store')}}" enctype="multipart/form-data" id="UserRegistration">
                @csrf
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="name">Name:</label>
                        <div class="input-group input-group-merge">
                            <input id="name" name="name" class="form-control credit-card-mask" type="text"
                                placeholder="name" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="telephone">Telephone:</label>
                        <div class="input-group input-group-merge">
                            <input id="telephone" name="telephone" class="form-control credit-card-mask" type="tel"
                                placeholder="telephone" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <label class="form-label w-100" for="address">Address:</label>
                    <div class="input-group input-group-merge">
                        <input id="address" name="address" class="form-control credit-card-mask" type="text"
                            placeholder="address" aria-describedby="modalAddCard2" />
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="RIB">RIB:</label>
                        <div class="input-group input-group-merge">
                            <input id="RIB" name="RIB" class="form-control credit-card-mask" type="number"
                                placeholder="RIB" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="CIN">CIN:</label>
                        <div class="input-group input-group-merge">
                            <input id="CIN" name="CIN" class="form-control credit-card-mask" type="text"
                                placeholder="CIN" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="email">Email:</label>
                        <div class="input-group input-group-merge">
                            <input id="email" name="email" class="form-control credit-card-mask" type="text"
                                placeholder="email" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="password">Password:</label>
                        <div class="input-group input-group-merge">
                            <input id="password" name="password" class="form-control credit-card-mask" type="password"
                                placeholder="Password" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="rectoCNI">Recto CNI:</label>
                        <div class="input-group input-group-merge">
                            <input id="rectoCNI" type="file" class="form-control" name="rectoCNI">
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="versoCNI">Verso CNI:</label>
                        <div class="input-group input-group-merge">
                            <input id="versoCNI" type="file" class="form-control" name="versoCNI">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-12">
                        <label for="ville" class="form-label">Ville:</label>
                        <select id="ville" name="ville" class="select2 form-select form-select-lg"
                            data-allow-clear="true">
                            <option >Select Ville</option>
                            @foreach ($ville as $item)
                                <option value="{{ $item->id }}">{{ $item->ville }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6 col-12">
                        <label for="role" class="form-label">Role:</label>
                        <select id="role" name="role" class="select2 form-select form-select-lg"
                            data-allow-clear="true">
                            <option  >Select Role</option>
                            @foreach ($role as $item)
                                <option value="{{ $item->id }}">{{ $item->nameRole }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="row" id="commissionField" style="display:none;">
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="commission">Commission:</label>
                        <div class="input-group input-group-merge">
                            <input id="commission" name="commistion" class="form-control credit-card-mask" type="number"
                                placeholder="Commission" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                </div>
                <div class="col-12 mt-4 text-center">
                    <button type="submit" class="btn btn-primary me-sm-3 me-1 px-4">Submit</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        $(document).ready(function() {
    $('#role').change(function() {
        if ($(this).val() == 3) {
            $('#commissionField').show();
        } else {
            $('#commissionField').hide();
        }
    });

    $('#UserRegistration').submit(function(event) {
        event.preventDefault();

        var formData = new FormData($(this)[0]);

        $.ajax({
            type: 'POST',
            url: "{{ route('user.store') }}",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message, 'User Has Been Added!', {
                        "showMethod": "slideDown",
                        "hideMethod": "slideUp",
                        timeOut: 2000,
                        "onHidden": function() {
                            location.reload();
                        }
                    });
                }
                console.log(response);
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    var errors = xhr.responseJSON.errors;

                    for (var field in errors) {
                        toastr.warning('Opps ' + errors[field][0], 'Wrong.', {
                            "showMethod": "slideDown",
                            "hideMethod": "slideUp",
                            timeOut: 4000
                        });
                    }
                } else {
                    toastr.warning('Opps Something went wrong!', 'Wrong.', {
                        "showMethod": "slideDown",
                        "hideMethod": "slideUp",
                        timeOut: 2000
                    });
                }
                console.log(xhr);
            }
        });
    });
});

    </script>
@endsection
