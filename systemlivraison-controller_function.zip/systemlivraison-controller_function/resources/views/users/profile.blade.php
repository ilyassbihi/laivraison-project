@extends('layouts.clientDashboard')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="d-flex justify-content-between align-items-center">
            @if (Auth::user())
                
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">profile /</span>{{Auth::user()->name}}</h4>
            @endif
        </div>
        <div>
            <form method="POST" action="{{route('user.profile.update',Auth::user()->id)}}" id="update" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="name">Name:</label>
                        <div class="input-group input-group-merge">
                            <input id="name" name="name" value="{{Auth::user()->name}}" class="form-control credit-card-mask" type="text"
                                placeholder="name" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="telephone">Telephone:</label>
                        <div class="input-group input-group-merge">
                            <input id="telephone" value="{{Auth::user()->telephone}}" name="telephone" class="form-control credit-card-mask" type="tel"
                                placeholder="telephone" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <label class="form-label w-100" for="address">Address:</label>
                    <div class="input-group input-group-merge">
                        <input id="address" value="{{Auth::user()->Address}}" name="address" class="form-control credit-card-mask" type="text"
                            placeholder="address" aria-describedby="modalAddCard2" />
                    </div>
                </div>
                <div class="row">

                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="RIB">RIB:</label>
                        <div class="input-group input-group-merge">
                            <input id="RIB" value="{{Auth::user()->RIB}}" name="RIB" class="form-control credit-card-mask" type="number"
                                placeholder="RIB" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="CIN">CIN:</label>
                        <div class="input-group input-group-merge">
                            <input id="CIN" value="{{Auth::user()->CIN}}" name="CIN" class="form-control credit-card-mask" type="text"
                                placeholder="CIN" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-12">
                        <label class="form-label w-100" for="email">Email:</label>
                        <div class="input-group input-group-merge">
                            <input id="email" value="{{Auth::user()->email}}" name="email" class="form-control credit-card-mask" type="text"
                                placeholder="email" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                    {{-- <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="email">Password:</label>
                        <div class="input-group input-group-merge">
                            <input id="Password" value="{{Auth::user()->password}}" name="password" class="form-control credit-card-mask" type="password"
                                placeholder="Password" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                </div> --}}
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="rectoCNI">Recto CNI:</label>
                        <div class="input-group input-group-merge">
                            <input id="rectoCNI" type="file" class="form-control" name="rectoCNI">
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label w-100" for="versoCNI
                    ">Verso CNI:</label>
                        <div class="input-group input-group-merge">
                            <input id="versoCNI" type="file" class="form-control" name="versoCNI">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-12">
                        <label for="ville" class="form-label">Ville:</label>
                        <select id="ville" name="ville" class="select2 form-select form-select-lg"
                            data-allow-clear="true">
                            {{-- <option value="{{Auth::user()->villee->id}}" >{{Auth::user()->villee->ville}}</option> --}}
                            @foreach ($ville as $item)
                            @if (Auth::user()->villee->id == $item->id)
                            
                            <option value="{{ $item->id }}" selected>{{ $item->ville }}</option>
                            @else
                                <option value="{{ $item->id }}">{{ $item->ville }}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                    {{-- <div class="col-md-6 col-12">
                        <label for="role" class="form-label">Role:</label>
                        <select id="role" name="role" class="select2 form-select form-select-lg"
                            data-allow-clear="true">
                            <option  >Select Role</option>
                            @foreach ($role as $item)
                            @if (Auth::user()->rolee->id == $item->id)
                            
                            <option value="{{ $item->id }}" selected>{{ $item->nameRole }}</option>
                            @else
                                <option value="{{ $item->id }}">{{ $item->nameRole }}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                </div> --}}
                <div class="col-12 mt-4 text-center">
                    <button type="submit" class="btn btn-primary me-sm-3 me-1 px-4">Submit</button>
                    <a  class="btn btn-success text-white me-sm-3 me-1 px-4" data-bs-toggle="modal" data-bs-target="#addNewCCModal">change password</a>

                </div>
            </form>
        </div>
    </div>
    <div class="modal fade" id="addNewCCModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
            <div class="modal-content p-3 p-md-5">
                <div class="modal-body">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <div class="text-center mb-4">
                        <h3 class="mb-2">changer le mot de passe</h3>
                        
                    </div>
                    <form method="POST" action="{{ route('mdpChange',Auth::user()->id) }}" 
                        id="addNewCCForm" class="row g-3">
                        @csrf
                       @method('PUT')
                       
                     
                        <div class="col-12 ">
                            <label class="form-label w-100" for="Adresse">password:</label>
                            <div class="input-group input-group-merge">
                                <input id="password" name="password" class="form-control credit-card-mask"
                                    type="password" placeholder="password" aria-describedby="modalAddCard2" />
                            </div>
                        </div>
                   
                   


                           
                        
                        
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                            <button type="reset" class="btn btn-label-secondary btn-reset" data-bs-dismiss="modal"
                                aria-label="Close">
                                Cancel
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
 
@endsection
