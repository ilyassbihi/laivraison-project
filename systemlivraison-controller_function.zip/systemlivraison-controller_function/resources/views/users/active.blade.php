@extends('layouts.clientDashboard')
@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span>User Details</h4>
        </div>
                  <div class="card mb-4">
                    <h5 class="card-header">Profile Details</h5>
                    <!-- Account -->
                    <div class="card-body">
                      <div class="d-flex align-items-start align-items-sm-center gap-4">
                        <img
                          src="../../assets/img/avatars/14.png"
                          alt="user-avatar"
                          class="d-block w-px-100 h-px-100 rounded"
                          id="uploadedAvatar" />
                        {{-- <div class="button-wrapper">
                          <label for="upload" class="btn btn-primary me-2 mb-3" tabindex="0">
                            <span class="d-none d-sm-block">Upload new photo</span>
                            <i class="ti ti-upload d-block d-sm-none"></i>
                            <input
                              type="file"
                              id="upload"
                              class="account-file-input"
                              hidden
                              accept="image/png, image/jpeg" />
                          </label>
                          <button type="button" class="btn btn-label-secondary account-image-reset mb-3">
                            <i class="ti ti-refresh-dot d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Reset</span>
                          </button>

                          <div class="text-muted">Allowed JPG, GIF or PNG. Max size of 800K</div>
                        </div> --}}
                      </div>
                    </div>
                    <hr class="my-0" />
                    <div class="card-body">
                      <form id="addNewCCForm" method="POST" >
                        @csrf
                        <div class="row">
                          <div class="mb-3 col-md-6">
                            <label for="name" class="form-label">Name</label>
                            <input
                              class="form-control"
                              type="text"
                              id="name"
                              name="name"
                              value="{{$user->name}}"
                              autofocus />
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="telephone" class="form-label">Telephone</label>
                            <input class="form-control" type="text" name="telephone" id="telephone" value="{{$user->telephone}}" />
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="Address" class="form-label">Address</label>
                            <input
                              class="form-control"
                              type="text"
                              id="Address"
                              name="Address"
                              value="{{$user->Address}}"
                              placeholder="Address" />
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="RIB" class="form-label">RIB</label>
                            <input
                              type="text"
                              class="form-control"
                              id="RIB"
                              name="RIB"
                              value="{{$user->RIB}}" />
                          </div>
                          <div class="mb-3 col-md-6">
                            <label class="form-label" for="phoneNumber">CIN</label>
                            <div class="input-group input-group-merge">
                              <input
                                type="text"
                                id="CIN"
                                name="CIN"
                                class="form-control"
                                value="{{$user->CIN}}"
                                placeholder="CIN" />
                            </div>
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" class="form-control" id="email" name="email" value="{{$user->email}}" placeholder="Email" />
                          </div>
                            <div class="mb-3 col-md-6">
                                <label for="ville" class="form-label">Ville <b>*</b></label>
                                <select id="ville" name="ville" class="select2 form-select form-select-lg"
                                    data-allow-clear="true">
                                    @foreach ($villes as $ville)
                                      <option @if ($user->ville == $ville->id)
                                          selected
                                      @endif value="{{$ville->id}}">{{$ville->ville}}</option>
                                    @endforeach
                                </select>
                            </div>
                          
                        </div>
                        <div class="mt-2 text-center">
                          <button type="submit" class="btn btn-primary me-2">Save changes</button>
                          @if ($user->status == 2)
                          <a href="{{route("desactiverCompte",$user->id)}}"  class="btn btn-danger me-2">désactiver</a>
                          @else
                          <a href="{{route("activerCompte",$user->id)}}"  class="btn btn-success me-2">Activer</a>
                          @endif
                        </div>
                      </form>
                    </div>
                    <!-- /Account -->
                  </div>
                  </div>
  <script>
        $(document).ready(function() {
            $('#addNewCCForm').submit(function(event) {
                event.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: 'POST',
                    url: "{{ route('user.update', $user->id) }}",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastr.success('Good Job.', 'Data Has Been Updated!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                            location.reload();
                        }
                        console.log(response);
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            // Validation errors occurred
                            var errors = xhr.responseJSON.errors;

                            // Display each error
                            for (var field in errors) {
                                toastr.warning('Good Job.', 'Opps ' + errors[field][0], {
                                    "showMethod": "slideDown",
                                    "hideMethod": "slideUp",
                                    timeOut: 4000
                                });
                            }
                        } else {
                            // Other types of errors
                            toastr.warning('Good Job.', 'Opps Something went wrong!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                        }
                        console.log(xhr);
                    }
                });
            });
        });
    </script>
@endsection