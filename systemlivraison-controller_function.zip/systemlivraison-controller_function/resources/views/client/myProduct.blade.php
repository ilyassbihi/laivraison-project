@extends('layouts.clientDashboard')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">

        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> all Products</h4>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewCCModal">
                Add New Product
            </button>
        </div>

        <div class="modal fade" id="addNewCCModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3 class="mb-2">Add New Product</h3>
                            <p class="text-muted">Add new product to Stock</p>
                        </div>
                        <form method="POST" action="{{ route('product.store') }}" enctype="multipart/form-data"
                            id="addNewCCForm" class="row g-3">
                            @csrf
                            <div class="col-12">
                                <label class="form-label w-100" for="modalAddCard">Product Name</label>
                                <div class="input-group input-group-merge">
                                    <input id="modalAddCard" name="name" class="form-control credit-card-mask"
                                        type="text" placeholder="Product Name" aria-describedby="modalAddCard2" />
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                            class="card-type"></span></span>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label w-100" for="modalAddCard">Price</label>
                                <div class="input-group input-group-merge">
                                    <input id="modalAddCard" name="prix" step="0.01"
                                        class="form-control credit-card-mask" type="number" placeholder="Product Name"
                                        aria-describedby="modalAddCard2" />
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                            class="card-type"></span></span>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label w-100" for="modalAddCard">Quantity</label>
                                <div class="input-group input-group-merge">
                                    <input id="modalAddCard" name="quantity" class="form-control credit-card-mask"
                                        type="number" placeholder="Product Name" aria-describedby="modalAddCard2" />
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                            class="card-type"></span></span>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label w-100" for="modalAddCard">Image</label>
                                <div class="input-group input-group-merge">
                                    <input id="modalAddCard" name="image" class="form-control-file " type="file"
                                        placeholder="Product Name" aria-describedby="modalAddCard2" />
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                            class="card-type"></span></span>
                                </div>
                            </div>
                            {{-- <div class="col-12 col-md-6">
                                <label class="form-label" for="modalAddCardName">Name</label>
                                <input type="text" id="modalAddCardName" class="form-control" placeholder="John Doe" />
                            </div>
                            <div class="col-6 col-md-3">
                                <label class="form-label" for="modalAddCardExpiryDate">Exp. Date</label>
                                <input type="text" id="modalAddCardExpiryDate" class="form-control expiry-date-mask"
                                    placeholder="MM/YY" />
                            </div>
                            <div class="col-6 col-md-3">
                                <label class="form-label" for="modalAddCardCvv">CVV Code</label>
                                <div class="input-group input-group-merge">
                                    <input type="text" id="modalAddCardCvv" class="form-control cvv-code-mask"
                                        maxlength="3" placeholder="654" />
                                    <span class="input-group-text cursor-pointer" id="modalAddCardCvv2"><i
                                            class="text-muted ti ti-help" data-bs-toggle="tooltip" data-bs-placement="top"
                                            title="Card Verification Value"></i></span>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="switch">
                                    <input type="checkbox" class="switch-input" />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                    <span class="switch-label">Save card for future billing?</span>
                                </label>
                            </div> --}}
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                                <button type="reset" class="btn btn-label-secondary btn-reset" data-bs-dismiss="modal"
                                    aria-label="Close">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-5">
            @foreach ($myProduct as $item)
                <div class="col-md-6 col-lg-4 mb-3">
                  <div class="card h-100">
                    <img class="card-img-top" src="{{ asset($item->image) }}" alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">{{ $item->name }}</h5>
                      <p class="card-text">
                       <b>Quantity:</b> {{ $item->quantity }}
                      </p>
                      <p class="card-text">
                       <b>Prix:</b> {{ $item->prix }} DH
                      </p>
                      {{-- <p class="card-text">
                       <b>client:</b> {{ $item->clientte->name }} 
                      </p> --}}
                      <div class="dropdown">
                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                            data-bs-toggle="dropdown" aria-expanded="false">
                                            <a href="javascript:void(0)" class="btn btn-outline-primary waves-effect">Actions</a>
                                        </button>
                                        <div class="dropdown-menu" style="">
                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                    class="ti ti-pencil me-1"></i> Edit</a>
                                            <a class="dropdown-item" href="javascript:void(0);"><i
                                                    class="ti ti-trash me-1"></i> Delete</a>
                                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                @endforeach
              </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#addNewCCForm').submit(function(event) {
                event.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: 'POST',
                    url: "{{ route('product.store') }}",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastr.success('Good Job.', 'Product Has Been Requested!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                            location.reload();
                        }
                        console.log(response);
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            // Validation errors occurred
                            var errors = xhr.responseJSON.errors;

                            // Display each error
                            for (var field in errors) {
                                toastr.warning('Good Job.', 'Opps ' + errors[field][0], {
                                    "showMethod": "slideDown",
                                    "hideMethod": "slideUp",
                                    timeOut: 4000
                                });
                            }
                        } else {
                            // Other types of errors
                            toastr.warning('Good Job.', 'Opps Something went wrong!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                        }
                        console.log(xhr);
                    }
                });
            });
        });
    </script>
@endsection
