<!-- resources/views/ramassages/index.blade.php -->

@extends('layouts.clientDashboard')

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">

        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span>Ramassage</h4>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewCCModal">
                Add New Ramassage
            </button>
        </div>
        <div class="modal fade" id="addNewCCModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3 class="mb-2">Add New Ramassage</h3>
                            <p class="text-muted">Add new ramassage</p>
                        </div>
                        <form method="POST" action="{{ route('ramassages.store') }}" enctype="multipart/form-data"
                            id="addNewCCForm" class="row g-3">
                            @csrf
                            <div class="col-12 col-md-6">
                                <label class="form-label w-100" for="Nom">Name:</label>
                                <div class="input-group input-group-merge">
                                    <input id="Nom" name="Nom" class="form-control credit-card-mask"
                                        type="text" placeholder="Product Name" aria-describedby="modalAddCard2" />
                                    @if (Auth::user())
                                        <input type="hidden" name="idclient" value="{{ Auth::user()->id }}">
                                    @endif
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                            class="card-type"></span></span>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label w-100" for="Téléphone">Phone:</label>
                                <div class="input-group input-group-merge">
                                    <input id="Téléphone" name="Téléphone" class="form-control credit-card-mask"
                                        type="text" placeholder="Phone Number" aria-describedby="modalAddCard2" />
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                            class="card-type"></span></span>
                                </div>
                            </div>
                            <div class="col-12">
                                <label for="ville" class="form-label">Ville:</label>
                                <select id="ville" name="ville" class="select2 form-select form-select-lg"
                                    data-allow-clear="true">
                                    @foreach ($villesramassage as $ville)
                                        <option value="{{ $ville->id }}">{{ $ville->villeR }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-12 ">
                                <label class="form-label w-100" for="Adresse">Adresse:</label>
                                <div class="input-group input-group-merge">
                                    <input id="Adresse" name="Adresse" class="form-control credit-card-mask"
                                        type="text" placeholder="Adresse" aria-describedby="modalAddCard2" />
                                </div>
                            </div>
                            <div class="col-6">
                                <label class="form-label w-100" for="ramassage_colis">Ramassage Colis:</label>
                                <div class="form-check form-switch mb-2">
                                    <label class="switch">
                                        <input type="checkbox" class="switch-input" id="ramassage_colis"
                                            name="ramassage_colis" onclick="handleCheckboxChange(this)">
                                        <span class="switch-toggle-slider">
                                            <span class="switch-on"></span>
                                            <span class="switch-off"></span>
                                        </span>
                                    </label>
                                </div>

                            </div>
                            <div class="col-6" style="display: none">
                                <label class="form-label w-100" for="ramassage_stock">Ramassage Stock:</label>
                                <div class="form-check form-switch mb-2">
                                    <label class="switch">
                                        <input type="checkbox" class="switch-input" id="ramassage_stock"
                                            name="ramassage_stock" onclick="handleCheckboxChange(this)">
                                        <span class="switch-toggle-slider">
                                            <span class="switch-on"></span>
                                            <span class="switch-off"></span>
                                        </span>
                                    </label>
                                </div>

                            </div>
                            <div class="row" id="commends_sections" style="display: none;">
                                <div class="col-9">
                                    <div class="col-12">
                                        <label for="CommendsSelection" class="form-label">Select Commends:</label>
                                        <div class="dropdown bootstrap-select show-tick w-100 dropup">
                                            <select id="CommendsSelection" name="selected_commends[]"
                                                class="selectpicker w-100" data-style="btn-default" multiple=""
                                                data-actions-box="true" tabindex="null">
                                                @foreach ($commends as $commend)
                                                <option value="{{ $commend->id }}">{{ $commend->Namepr }} - - {{ $commend->villee->ville }}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="col-12">
                                        <label class="form-label w-100" for="total_colis">Total Colis:</label>
                                        <div class="input-group input-group-merge">
                                            <input id="total_colis" name="total_colis" class="form-control"
                                                type="number" readonly aria-describedby="modalAddCard2" />
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row" id="products_sections" style="display: none;">
                                <div class="col-9">
                                    <label for="ProductSelections" class="form-label">Select Products:</label>
                                    <div class="dropdown bootstrap-select show-tick w-100 dropup">
                                        <select id="ProductSelections" name="selected_products[]"
                                            class="selectpicker w-100" data-style="btn-default" multiple
                                            data-actions-box="true" tabindex="null">
                                            @foreach ($products as $product)
                                                <option value="{{ $product->id }}">{{ $product->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="col-3">

                                    <label class="form-label w-100" for="total_product">Total Product:</label>
                                    <div class="input-group input-group-merge">
                                        <input id="total_product" name="total_product" class="form-control"
                                            type="number" readonly aria-describedby="modalAddCard2" />
                                    </div>
                                </div>
                            </div>
                            <div id="productCards"></div>
                            <div class="col-12">
                                <label for="remarque" class="form-label">Remarque:</label>
                                <textarea class="form-control" id="remarque" name="remarque" rows="3"></textarea>
                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                                <button type="reset" class="btn btn-label-secondary btn-reset" data-bs-dismiss="modal"
                                    aria-label="Close">
                                    Cancel
                                </button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
        {{-- <div>
            <div class="row">
                <div class="col-12  ">
                    <form action="{{ route('ramassages.index') }}" method="GET">
                        <div class="d-flex justify-content-md-end">
                            <div id="DataTables_Table_3_filter" class="dataTables_filter">
                                <input type="search" name="search" class="form-control" placeholder="Search By Ref, Nom, Ville"
                                    aria-controls="DataTables_Table_3">
                            </div>
                            <button type="submit" class="mx-3 btn btn-primary me-sm-3 me-1">Search</button>
                        </div>

                    </form>
                </div>
            </div> --}}
            @if (empty($ramassages))
                <p>No ramassages found.</p>
            @else
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nom</th>
                            <th scope="col">ville</th>
                            <th scope="col">status</th>
                            <th scope="col">total_colis</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                        if (empty($ramassages)) {

                            $count = count($ramassages);
                        }
                        @endphp
                        @foreach ($ramassages as $ramassage)
                            <tr>
                                <th scope="row">{{ $ramassage->Ref }}</th>
                                <td>{{ $ramassage->Nom }}</td>
                                <td>{{ $ramassage->villee->ville }}</td>
                                <td>
                                    {{$ramassage->statuss->nameR }}
                                </td>
                                <td>
                                    {{$ramassage->total_colis }}
                                </td>

                                <td>
  @if($ramassage->statuss->nameR === "Nouvelle demande")
    <div class="action-icons">
      <a class="btn p-0 delete-ramassage" href="javascript:void(0);" data-id="{{ $ramassage->id }}" title="Delete">
        <i class="ti ti-trash me-2"></i>
      </a>
    </div>
  @endif
</td>

                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @endif
        </div>
    </div>
    {{-- <h1>Ramassages</h1>
    <a href="{{ route('ramassages.create') }}" class="btn btn-primary mb-3">Create New Ramassage</a> --}}
    <script>
        $(document).ready(function() {
            $('#addNewCCForm').submit(function(event) {
                event.preventDefault();

                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: 'POST',
                    url: "{{ route('ramassages.store') }}",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastr.success('Good Job.', 'Ramassage Has Been Requested!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                            // location.reload();
                        }
                        console.log(response);
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            // Validation errors occurred
                            var errors = xhr.responseJSON.errors;

                            // Display each error
                            for (var field in errors) {
                                toastr.warning('Wrong.', 'Opps ' + errors[field][0], {
                                    "showMethod": "slideDown",
                                    "hideMethod": "slideUp",
                                    timeOut: 4000
                                });
                            }
                        } else {
                            // Other types of errors
                            toastr.warning('Wrong.', 'Opps Something went wrong!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                        }
                        console.log(xhr);
                    }
                });
            });
        });
        $(document).ready(function() {
            $('input[type="checkbox"]').change(function() {
                var checkBoxId = $(this).attr('id');

                if (checkBoxId === 'ramassage_colis') {
                    $('#commends_sections').toggle(this.checked);
                } else if (checkBoxId === 'ramassage_stock') {
                    $('#products_sections').toggle(this.checked);
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Attach change event listener to checkboxes
            $('input[name="selected_commends[]"]').change(function() {
                var totalChecked = $('input[name="selected_commends[]"]:checked').length;
                $('#total_colis').val(totalChecked);
            });
            $('input[name="selected_products[]"]').change(function() {
                var totalProduct = $('input[name="selected_products[]"]:checked').length;
                $('#total_product').val(totalProduct);
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#ProductSelections').change(function() {
                var selectedProducts = $(this).val();
                var productCards = $('#productCards');

                productCards.empty();

                $.each(selectedProducts, function(index, productId) {
                    var productCard = $('<div>').addClass('card mb-3');
                    var cardBody = $('<div>').addClass('card-body');

                    var productName = $('<h5>').addClass('card-title').text($(
                        '#ProductSelections option[value="' + productId + '"]').text());
                    var span = $('<span>').text(productId);
                    var quantityInput = $('<input>').addClass('form-control mb-2').attr('type',
                        'number').attr('placeholder', 'Quantity').attr('name', 'quantities[]');



                    cardBody.append(productName, quantityInput);
                    productCard.append(cardBody);
                    productCards.append(productCard);
                });
                updateSelectedProductNames();
            });

            function updateSelectedProductNames() {
                var selectedProductNames = $('.filter-option-inner-inner:eq(1)'); // Target the second div
                var selectedProducts = $('#ProductSelections').val();

                selectedProductNames.empty();

                if (selectedProducts && selectedProducts.length > 0) {
                    $.each(selectedProducts, function(index, productId) {
                        var productName = $('#ProductSelections option[value="' + productId + '"]').text();
                        selectedProductNames.append(productName + ', ');
                    });

                    // Remove the trailing comma
                    selectedProductNames.text(selectedProductNames.text().slice(0, -2));
                } else {
                    selectedProductNames.text('Nothing selected');
                }
            }
        });
    </script>
    <script>
        function updateStatus(url, selectElement) {


            var formData = new FormData(selectElement.form);
            formData.set('status', selectElement.value);
            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    toastr.success('Good Job.', 'Status Has Been Updated!', {
                        "showMethod": "slideDown",
                        "hideMethod": "slideUp",
                        timeOut: 2000
                    });
                    // location.reload();
                },
                error: function(xhr, status, error) {
                    // Handle error response if needed
                }
            });
        }

        function updateLivreur(url, selectElement) {


            var formData = new FormData(selectElement.form);
            formData.set('livreur', selectElement.value); // Set the selected value to 'status' field
            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    toastr.success('Good Job.', 'Livreur Has Been Added!', {
                        "showMethod": "slideDown",
                        "hideMethod": "slideUp",
                        timeOut: 2000
                    });
                    // location.reload();
                },
                error: function(xhr, status, error) {
                    // Handle error response if needed
                }
            });
        }

        $(document).ready(function() {
            // Fonction pour mettre à jour toutes les sélections avec le nouveau nombre de ramassages
            function updateAllSelects(livreurId, ramassageCount) {
                $('select[name="livreur"]').each(function() {
                    var option = $(this).find('option[value="' + livreurId + '"]');
                    if (option.length > 0) {
                        option.text(option.text().split('(')[0].trim() + ' (' + ramassageCount + ' )');
                    }
                });
            }

            // Fonction pour mettre à jour le nombre de ramassages d'une sélection
            function updateRamassageCount(option, livreurId) {
                $.ajax({
                    url: '/getRamassageCount/' + livreurId,
                    type: 'GET',
                    success: function(data) {
                        option.text(option.text().split('(')[0].trim() + ' (' + data + ' )');
                        // Mettre à jour toutes les sélections avec le nouveau nombre de ramassages
                        updateAllSelects(livreurId, data);
                    },
                    error: function(xhr, status, error) {
                        console.error(error);
                    }
                });
            }

            // Gestionnaire d'événement pour mettre à jour le texte de l'option lorsque le livreur est sélectionné
            $('select[name="livreur"]').change(function() {
                var option = $(this).find('option:selected');
                var livreurId = option.val();
                updateRamassageCount(option, livreurId);
            });

            // Au chargement de la page, mettre à jour tous les selects avec le nombre de ramassages initial
            $('select[name="livreur"] option').each(function() {
                var option = $(this);
                var livreurId = option.val();
                if (livreurId !== '') {
                    updateRamassageCount(option, livreurId);
                }
            });
        });




        $(document).ready(function() {
            var totalColisInput = $('#total_colis');
            var selectElement = $('#CommendsSelection');
            console.log(totalColisInput);
            console.log(selectElement);

            // Update total colis count on select change
            selectElement.change(function() {
                var totalColis = $(this).val() ? $(this).val().length : 0;
                totalColisInput.val(totalColis);
                console.log(totalColis);
            });

            // Trigger change event on page load to initialize the count
            selectElement.trigger('change');
        });
        $(document).ready(function() {
            var totalProductInput = $('#total_product');
            var selectElemented = $('#ProductSelections');


            // Update total colis count on select change
            selectElemented.change(function() {
                var totalProduct = $(this).val() ? $(this).val().length : 0;
                totalProductInput.val(totalProduct);
            });

            // Trigger change event on page load to initialize the count
            selectElemented.trigger('change');
        });
    </script>
    <script>
      $(document).ready(function() {
          $('.delete-ramassage').on('click', function() {
              var id = $(this).data('id');
              if (confirm('Are you sure you want to delete this ramassage?')) {
                  $.ajax({
                      url: '{{ route('ramassage.destroy', '') }}/' + id, // Modify the route accordingly
                      type: 'DELETE',
                      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                      success: function(result) {
                          if (result.success) {
                              toastr.success(result.message);
                              location.reload(); // Reload the page to update the list
                          } else {
                              toastr.error(result.message);
                          }
                      },
                      error: function() {
                          toastr.error('Something went wrong with the deletion.');
                      }
                  });
              }
          });
      });
      </script>
@endsection
