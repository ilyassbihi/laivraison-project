@extends('layouts.clientDashboard')
@section('content')
<style>
  small, .small ,h5 {
    color: black;
}
</style>
 <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">

            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: #4FA8E2">
                    <div class="card-body d-flex justify-content-between align-items-center my-2">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$commendsCount}}</h5>
                            <small>Total Commends</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: #43ED11">
                    <div class="card-body d-flex justify-content-between align-items-center my-2">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$CLivreeCount}}</h5>
                            <small>Commends Livrée</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: darkorange">
                    <div class="card-body d-flex justify-content-between align-items-center my-2 ">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$AttenteRCount}}</h5>
                            <small>En Attente de Ramassage</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: #4FA8E2">
                    <div class="card-body d-flex justify-content-between align-items-center my-2">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$ramassageCount}}</h5>
                            <small>nombre de ramassages</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: #A1A8B2">
                    <div class="card-body d-flex justify-content-between align-items-center my-2 ">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$RamasseeCount}}</h5>
                            <small>Ramassée</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: #F3FF5D">
                    <div class="card-body d-flex justify-content-between align-items-center my-2 ">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{ $CANULIECount}}</h5>
                            <small>Annulée</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card" style="background-color: #FF1111">
                    <div class="card-body d-flex justify-content-between align-items-center my-2 ">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">{{$CRouteurCount}}</h5>
                            <small>Retourné</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-4">
                <div class="card">
                    <div class="card-body d-flex justify-content-between align-items-center my-2 ">
                        <div class="card-title mb-0">
                            <h5 class="mb-0 me-2">86%</h5>
                            <small>Taux de Livraison</small>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded-pill p-2">
                                <i class="ti ti-cpu ti-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

@endsection
