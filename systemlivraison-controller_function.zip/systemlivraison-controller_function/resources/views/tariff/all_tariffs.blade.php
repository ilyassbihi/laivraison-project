<!-- all_tariffs.blade.php -->

@extends('layouts.clientDashboard')
@section('content')
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> Tarifs</h4>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewCCModal">
                create tariff
            </button>
        </div>
        <div class="modal fade" id="addNewCCModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered1 modal-simple modal-add-new-cc">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <p class="text-muted">Add new Tariff</p>
                        </div>
                        <form method="POST" action="{{ route('tariff.store') }}">
                            @csrf

                            <!-- Step 1: Select origin city -->
                            <div class="">
                                <div class="col-12">
                                    <label for="origin_city_id" class="form-label">{{ __('Origin City') }}:</label>
                                    <select id="origin_city_id" name="origin_city_id"
                                        class="select2 form-select form-select-lg @error('origin_city_id') is-invalid @enderror"
                                        data-allow-clear="true">
                                         <option value="" selected disabled>Select Origin City</option>
                                        @foreach ($villesramassage as $ville)
                                            <option value="{{ $ville->id }}">{{ $ville->villeR }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                {{-- <div class="form-group row">
                            <label for="origin_city_id" class="col-md-4 col-form-label text-md-right">{{ __('Origin City') }}</label>

                            <div class="col-md-6">
                                <select id="origin_city_id" class="form-control @error('origin_city_id') is-invalid @enderror" name="origin_city_id" required>
                                    <option value="" selected disabled>Select Origin City</option>
                                    @foreach ($villesramassage as $ville)
                                        <option value="{{ $ville->id }}">{{ $ville->villeR }}</option>
                                    @endforeach
                                </select>

                                @error('origin_city_id')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div> --}}
                        <div class="col-md-12">
                          <label for="destination_city_id" class="form-label">{{ __('Destination Cities') }}:</label>
                          <select id="destination_city_id" class="select2 form-select @error('destination_city_id') is-invalid @enderror" name="destination_city_id[]" multiple>
                            <option value="" disabled>Select Destination Cities</option>
                                        @foreach ($villes as $ville)
                                            <option value="{{ $ville->id }}">{{ $ville->ville }}</option>
                                        @endforeach
                            
                            
                          </select>
                        </div>
                              
                            </div>

                            <!-- Step 3: Enter tariff for each selected destination city -->
                            <div class="destination-tariffs mt-3">
                                <!-- Tariff fields will be added here dynamically using JavaScript -->
                            </div>


                            <div class="col-12 mt-3 text-center">
                                <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                                <button type="reset" class="btn btn-label-secondary btn-reset" data-bs-dismiss="modal"
                                    aria-label="Close">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="my-3">
    <form action="{{ route('tariff.all') }}" method="GET" class="d-flex flex-column flex-sm-row align-items-end">
        <select class="form-select me-sm-2 mb-2 mb-sm-0" name="OriginCity" aria-label="Default select example" style="flex-grow: 1;">
            <option disabled selected>Select Origin City</option>
            @foreach ($villesramassage as $ville)
                <option value="{{ $ville->id }}" {{ request('OriginCity') == $ville->id ? 'selected' : '' }}>
                    {{ $ville->villeR }}
                </option>
            @endforeach
        </select>
        <select class="form-select me-sm-2 mb-2 mb-sm-0" name="DestinationCity" aria-label="Default select example" style="flex-grow: 1;">
            <option disabled selected>Select Destination City</option>
            @foreach ($villes as $ville)
                <option value="{{ $ville->id }}" {{ request('DestinationCity') == $ville->id ? 'selected' : '' }}>
                    {{ $ville->ville }}
                </option>
            @endforeach
        </select>
        <button type="submit" class="btn btn-primary " style="flex-shrink: 0;">Search</button>
    </form>
</div>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Origin City</th>
                    <th scope="col">Destination City</th>
                    <th scope="col">Tariff</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($tariffs as $tariff)
                    <tr>
                        <td>{{ $tariff->originCity->villeR }}</td>
                        <td>{{ $tariff->destinationCity->ville }}</td>
                        <td>{{ $tariff->tariff }}</td>
                        <td>
                            <a class="dropdown-item edit-tariff" href="javascript:void(0);" data-id="{{ $tariff->id }}" data-tariff="{{ $tariff->tariff }}">
    <i class="ti ti-pencil me-1"></i> 
</a>
<!--                             <div class="dropdown">-->
<!--                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"-->
<!--                                    aria-expanded="false">-->
<!--                                    <i class="ti ti-dots-vertical"></i>-->
<!--                                </button>-->
<!--                                <div class="dropdown-menu" style="">-->
<!--                                    <a class="dropdown-item edit-tariff" href="javascript:void(0);" data-id="{{ $tariff->id }}" data-tariff="{{ $tariff->tariff }}">-->
<!--    <i class="ti ti-pencil me-1"></i> Edit-->
<!--</a>-->

<!--                                </div>-->
<!--                            </div>-->
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <!-- Update Tariff Modal -->
<div class="modal fade" id="updateTariffModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Tariff</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="updateTariffForm">
                <div class="modal-body">
                    <input type="hidden" id="updateTariffId">
                    <div class="form-group">
                        <label for="updateTariffAmount">New Tariff Amount</label>
                        <input type="number" class="form-control" id="updateTariffAmount" name="tariff" required min="0">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

    <script>
        $(document).ready(function() {
            $('#origin_city_id').change(function() {
                var selectedOriginCity = $(this).val();

                $.ajax({
                    type: 'GET',
                    url: '{{ route('get_available_destinations') }}',
                    data: {
                        origin_city_id: selectedOriginCity
                    },
                    success: function(response) {
                        if (response.success) {
                            var availableDestinations = response.data;
                            $('#destination_city_id').empty().append(
                                '<option value="" disabled selected>Select Destination Cities</option>'
                                );
                            $('#destination_city_id').empty().append(
                                '<option value="" disabled selected>Select Destination Cities</option>'
                                );
                            $.each(availableDestinations, function(id, name) {
                                $('#destination_city_id').append('<option value="' +
                                    id + '">' + name + '</option>');
                            });
                            $('.destination-tariffs').empty(); // Clear existing tariff fields
                        }
                    },
                    error: function(xhr, textStatus, errorThrown) {
                        console.log(xhr.responseText);
                    }
                });
            });

            $('#destination_city_id').change(function() {
                var selectedOriginCity = $('#origin_city_id option:selected').text();
                var selectedCities = $(this).val();
                $('.destination-tariffs').empty();
                if (selectedCities && selectedCities.length > 0) {
                    selectedCities.forEach(function(cityId) {
                        var destinationCityName = $('#destination_city_id option[value="' + cityId +
                            '"]').text();
                        $('.destination-tariffs').append(`
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label text-md-right">Tariff from ${selectedOriginCity} to ${destinationCityName}</label>
                        <div class="col-md-12">
                            <input type="number" step="0.01" class="form-control" name="tariff[${cityId}]" required>
                        </div>
                    </div>
                `);
                    });
                }
            });
        });

        // Submit form
    </script>
    <script>
        $(document).ready(function() {
              $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
    $('.edit-tariff').click(function() {
        var id = $(this).data('id');
        var tariff = $(this).data('tariff');
        $('#updateTariffId').val(id);
        $('#updateTariffAmount').val(tariff);
        $('#updateTariffModal').modal('show');
    });

    $('#updateTariffForm').submit(function(event) {
        event.preventDefault();
        var id = $('#updateTariffId').val();
        var formData = new FormData(this);

        $.ajax({
            type: 'POST',
            url: '/tariffs/update/' + id,
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    location.reload(); // Reload to see changes in the UI
                }
            },
            error: function(xhr) {
                toastr.error('Error updating tariff.');
            }
        });
    });
});

    </script>
@endsection
