<!-- create_tariff.blade.php -->

@extends('layouts.clientDashboard')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Add Tariff') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('tariff.store') }}">
                        @csrf

                        <!-- Step 1: Select origin city -->
                        <div class="form-group row">
                            <label for="origin_city_id" class="col-md-4 col-form-label text-md-right">{{ __('Origin City') }}</label>

                            <div class="col-md-6">
                                <select id="origin_city_id" class="form-control @error('origin_city_id') is-invalid @enderror" name="origin_city_id" required>
                                    <option value="" selected disabled>Select Origin City</option>
                                    @foreach($villesramassage as $ville)
                                        <option value="{{ $ville->id }}">{{ $ville->villeR }}</option>
                                    @endforeach
                                </select>

                                @error('origin_city_id')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <!-- Step 2: Select destination cities -->
                        <div class="form-group row">
                            <label for="destination_city_id" class="col-md-4 col-form-label text-md-right">{{ __('Destination Cities') }}</label>

                            <div class="col-md-6">
                                <select id="destination_city_id" class="form-control @error('destination_city_id') is-invalid @enderror" name="destination_city_id[]" multiple required>
                                    <option value="" disabled>Select Destination Cities</option>
                                    @foreach($villes as $ville)
                                        <option value="{{ $ville->id }}">{{ $ville->ville }}</option>
                                    @endforeach
                                </select>

                                @error('destination_city_id')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <!-- Step 3: Enter tariff for each selected destination city -->
                        <div class="destination-tariffs">
                            <!-- Tariff fields will be added here dynamically using JavaScript -->
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Apply') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $('#origin_city_id').change(function() {
            var selectedOriginCity = $(this).val();

            $.ajax({
                type: 'GET',
                url: '{{ route("get_available_destinations") }}',
                data: {
                    origin_city_id: selectedOriginCity
                },
                success: function(response) {
                    if(response.success) {
                        var availableDestinations = response.data;
                        $('#destination_city_id').empty().append('<option value="" disabled selected>Select Destination Cities</option>');
                        $.each(availableDestinations, function(id, name) {
                            $('#destination_city_id').append('<option value="' + id + '">' + name + '</option>');
                        });
                        $('.destination-tariffs').empty(); // Clear existing tariff fields
                    }
                },
                error: function(xhr, textStatus, errorThrown) {
                    console.log(xhr.responseText);
                }
            });
        });

        $('#destination_city_id').change(function() {
        var selectedOriginCity = $('#origin_city_id option:selected').text();
        var selectedCities = $(this).val();
        $('.destination-tariffs').empty();
        if(selectedCities && selectedCities.length > 0) {
            selectedCities.forEach(function(cityId) {
                var destinationCityName = $('#destination_city_id option[value="' + cityId + '"]').text();
                $('.destination-tariffs').append(`
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right">Tariff from ${selectedOriginCity} to ${destinationCityName}</label>
                        <div class="col-md-6">
                            <input type="number" step="0.01" class="form-control" name="tariff[${cityId}]" required>
                        </div>
                    </div>
                `);
            });
        }
    });
        });

        // Submit form
       
</script>








</script>
@endsection
