@extends('layouts.clientDashboard')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">

        <div class="row mb-5">
            <div class="">
                <div class="table-responsive ">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>REF</th>
                                <th>Destinataire</th>
                                <th>Ville</th>
                                <th>Montant</th>
                                <th>Status</th>
                                <th>livreur</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            @foreach ($commends as $item)
                            <tr>
                                <td>{{$item->id}}</td>
                                <td>{{$item->Destinataire}} - {{$item->TéléphoneD}}</td>
                                <td>{{$item->villee->ville}}</td>
                                <td>{{$item->Prix}}</td>
                                <td><span class="badge badge-pill badge-warning text-dark">{{$item->statusCommend->statusC}}</span></td>
                                <td>
                                  <form id="livreurForm_{{ $item->id }}" action="{{ route('updateLivreurC', $item->id) }}" method="POST">
                                    @csrf
                                    @method('PUT')
                                    <select name="livreur" id="livreurTD_{{ $item->id }}"
                                            class="form-select"
                                            onchange="updateLivreur('{{ route('updateLivreurC', $item->id) }}', this)">
                                        <option value="">-- selectionner un livreur --</option>
                                        @foreach ($livreurs as $livreur)
                                        <option value="{{ $livreur->id }}" @if ($livreur->id == $item->livreur) selected @endif>
                                            {{ $livreur->name }} -- {{ $livreur->villee->ville }}
                                        </option>
                                        @endforeach
                                    </select>
                                </form>

                                </td>

                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        function updateLivreur(url, selectElement) {
    var formData = new FormData(selectElement.form);
    formData.set('livreur', selectElement.value);
    formData.append('_method', 'PUT');

    $.ajax({
        url: url,
        type: 'POST', // Still using POST because we are spoofing PUT with _method
        data: formData,
        processData: false,
        contentType: false,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {
            toastr.success('Good Job.', 'Livreur Has Been Added!', {
                "showMethod": "slideDown",
                "hideMethod": "slideUp",
                timeOut: 2000
            });
            location.reload();
        },
        error: function(xhr, status, error) {
            // Handle error response if needed
        }
    });
}

    </script>

    <style>
        .action-icons {
            display: flex;
            align-items: center;
        }
        .action-icons .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            margin-right: 8px; /* Adjust spacing as needed */
        }
        .action-icons .btn:last-child {
            margin-right: 0;
        }
    </style>
@endsection
