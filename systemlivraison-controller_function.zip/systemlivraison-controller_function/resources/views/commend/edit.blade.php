@extends('layouts.clientDashboard')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> Update Commande</h4>

    <form method="POST" action="{{ route('command.update', $commend->id) }}" enctype="multipart/form-data" id="updateCCForm" class="row g-3 commend-form">
       @csrf
        <div class="card p-3">
            <h5 class="card-title">Destinataire Informations </h5>
            <div class="col-md-6">
                <label for="Destinataire" class="form-label">Nom De Destinataire:</label>
                <input id="Destinataire" name="Destinataire" type="text" class="form-control" value="{{ $commend->Destinataire }}" required>
            </div>
            <div class="col-md-6">
                <label for="TéléphoneD" class="form-label">Téléphone:</label>
                <input id="TéléphoneD" name="TéléphoneD" type="text" class="form-control" value="{{ $commend->TéléphoneD }}" required>
            </div>
            <div class="col-12">
                <label for="ville" class="form-label">Ville</label>
                @if($commend->statusCommend->statusC == 'Annulée')
                <p>{{$commend->villee->ville}}</p>
                <input id="ville" name="ville" type="hidden" class="form-control" value="{{$commend->ville }}" readonly >
                @else
                <select  id="ville" name="ville" class="form-select" >
                    @foreach ($villes as $ville)
                        <option  value="{{ $ville->id }}" @if ($ville->id == $commend->ville) selected @endif>
                            {{ $ville->ville }}
                        </option>
                    @endforeach
                </select>
                 @endif
            </div>
            <div class="col-12">
                <label for="Adresse" class="form-label">Adresse:</label>
                <input id="Adresse" name="Adresse" type="text" class="form-control" value="{{ $commend->Adresse }}" required>
            </div>
        </div>

        <div class="card p-3 mt-4">
            <h5 class="card-title">Produit</h5>
            <div class="col-12">
                <label for="Namepr" class="form-label">Titre De Produit:</label>
                <input id="Namepr" name="Namepr"  @if($commend->statusCommend->statusC == 'Annulée') readonly @endif type="text" class="form-control" value="{{ $commend->Namepr }}" required>
            </div>
            <div class="col-12">
                <label for="Quantite" class="form-label">Quantite:</label>
                <input id="Quantite" name="Quantite" type="number" class="form-control" value="{{ $commend->Quantite }}" required>
            </div>
            <div class="col-12">
                <label for="Prix" class="form-label">Prix:</label>
                <input id="Prix" name="Prix" type="number" class="form-control" value="{{ $commend->Prix }}" required>
            </div>
            <div class="col-12">
                <label for="Commentaire" class="form-label">Commentaire:</label>
                <textarea id="Commentaire" name="Commentaire" class="form-control" rows="3">{{ $commend->Commentaire }}</textarea>
            </div>
            <div class="col-6">
                <label class="form-label">Package Opened:</label>
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="packageOpened" name="package_opened" {{ $commend->package_opened ? 'checked' : '' }}>
                </div>
            </div>
            <div class="col-6">
                <label class="form-label">Exchange Requested:</label>
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="exchangeRequested" name="exchange_requested" {{ $commend->exchange_requested ? 'checked' : '' }}>
                </div>
            </div>
        </div>

        <div class="col-12 text-center">
            <button type="submit" class="btn btn-primary">Update Command</button>
        </div>
    </form>
</div>
<script>
    $(document).ready(function() {
    // Use a general class name for forms or check the form id if specific behavior is required
    $('.commend-form').submit(function(event) {
        event.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                toastr.success(response.message);
                window.location.href = '/commend'; // Redirect or reload logic after success
            },
            error: handleFormErrors // Consider abstracting error handling to a function
        });
    });
});
function handleFormErrors(xhr) {
    var errors = xhr.responseJSON.errors;
    $.each(errors, function(key, value) {
        toastr.error(value[0]); // Show first error message per field
    });
}
</script>
@endsection
