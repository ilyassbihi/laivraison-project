@extends('layouts.clientDashboard')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">

        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> Add Commandes</h4>
        </div>


        <form method="POST" action="{{ route('command.store') }}" enctype="multipart/form-data" id="addNewCCForm"
            class="row g-3">
            @csrf
            <div class="col-md-7 col-12 ">
                <div class="card p-3">
                    <h5 class="card-title">Destinataire Informations</h5>
                    <div class="row">
                        <div class="col-md-6 col-12 ">
                            <label class="form-label w-100" for="modalAddCard">Nom De Destinataire:</label>
                            <div class="input-group input-group-merge">
                                <input id="modalAddCard" name="Destinataire" class="form-control credit-card-mask"
                                    type="text" placeholder="Destinataire" aria-describedby="modalAddCard2" />
                                    @if (Auth::user())
                                    <input type="hidden" name="idclient" value="{{Auth::user()->id}}">
                                    @endif
                                <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                        class="card-type"></span></span>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <label class="form-label w-100" for="modalAddCard">Téléphone:</label>
                            <div class="input-group input-group-merge">
                                <input id="modalAddCard" name="TéléphoneD" class="form-control credit-card-mask"
                                    type="text" placeholder="Téléphone" aria-describedby="modalAddCard2" />
                                <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                        class="card-type"></span></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <label for="ville" class="form-label">Ville <b>*</b></label>
                        <select id="ville" name="ville" class="select2 form-select form-select-lg"
                            data-allow-clear="true">
                            @foreach ($villes as $ville)
                                <option value="{{ $ville->id }}">{{ $ville->ville }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="form-label w-100" for="modalAddCard">Adresse:</label>
                        <div class="input-group input-group-merge">
                            <input id="modalAddCard" name="Adresse" class="form-control credit-card-mask" type="text"
                                placeholder="Adresse" aria-describedby="modalAddCard2" />
                            <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                    class="card-type"></span></span>
                        </div>
                    </div>
                </div>
                <div class="card p-3 mt-4">
                    <h5 class="card-title">Produit</h5>
                    <div class="col-12">
                        <!--<label class="form-label w-100" for="modalAddCard">in stock</label>-->
                        <!--<div class="form-check form-switch mb-2">-->
                        <!--    <input class="form-check-input" type="checkbox" id="inStock">-->
                        <!--</div>-->
                    </div>
                    <div class="col-12">
                        <label class="form-label w-100" for="modalAddCard">Titre De Produit:</label>
                        <div class="input-group input-group-merge">
                            <input id="TitreDeProduit" name="Namepr" class="form-control credit-card-mask" type="text"
                                placeholder="Titre De Produit" aria-describedby="modalAddCard2" />
                        </div>
                    </div>
                    <div class="col-12" id="productSelection">
                        <label for="Products" class="form-label">Products</label>
                        <select id="Products" name="product" class="select2-icons form-select">
                            <option value="" disabled selected>Choose a product</option>
                            @foreach ($products as $item)
                                <option value="{{ $item->id }}" class="{{$item->quantity}}-{{$item->prix}}">{{ $item->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

            </div>

            <div class="col-md-1 col-0">

            </div>
            <div class="col-md-4 col-12 card p-3 mt-4 ">
                <h5 class="card-title">Command</h5>
                <div class="col-12 ">
                    <label class="form-label w-100" for="modalAddCard">Quantite:</label>
                    <div class="input-group input-group-merge">
                        <input id="Quantite" name="Quantite" class="form-control credit-card-mask" type="number"
                            placeholder="Quantite" aria-describedby="modalAddCard2" />
                        <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                class="card-type"></span></span>
                    </div>
                </div>

                <div class="col-12 ">
                    <label class="form-label w-100" for="modalAddCard">Prix:</label>
                    <div class="input-group input-group-merge">
                        <input id="Prix" name="Prix" class="form-control credit-card-mask" type="number"
                            placeholder="Prix" aria-describedby="modalAddCard2" />
                        <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"><span
                                class="card-type"></span></span>
                    </div>
                </div>
                <div class="col-12">
                    <label for="Commentaire" class="form-label">Remarque:</label>
                    <textarea class="form-control" id="Commentaire" name="Commentaire" placeholder="Commentaire" rows="3"></textarea>
                </div>

                <div class="col-6">
                    <label class="form-label w-100" for="modalAddCard">ouvrir:</label>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" name="package_opened" type="checkbox" id="packageOpened">
                    </div>
                </div>
                <div class="col-6">
                    <label class="form-label w-100" for="modalAddCard">exchange:</label>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="exchange_requested"
                            id="exchangeRequested">
                    </div>
                </div>
                <div class="col-12 text-center">
                    <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                </div>
            </div>


        </form>
    </div>
    <script>
        $(document).ready(function() {
            $('#productSelection').hide();
            $('#Products').prop('disabled', true);
            $('#inStock').change(function() {
                if ($(this).is(':checked')) {
                    $('#productSelection').show();
                    $('#Products').prop('disabled', false);
                } else {
                    $('#productSelection').hide();
                    $('#Products').prop('disabled', true);
                }
            });
        });
        $(document).ready(function() {
            // Function to update checkbox values
            function updateCheckboxValues() {
                var packageOpenedCheckbox = document.getElementById('packageOpened');
                var exchangeRequestedCheckbox = document.getElementById('exchangeRequested');

                // Set the value of the checkboxes based on their checked status
                $('#packageOpened').val(packageOpenedCheckbox.checked ? 1 : 0);
                $('#exchangeRequested').val(exchangeRequestedCheckbox.checked ? 1 : 0);
            }

            // Call the function initially to set values to 0
            updateCheckboxValues();

            // Attach event listeners to the checkboxes
            $('#packageOpened').change(updateCheckboxValues);
            $('#exchangeRequested').change(updateCheckboxValues);
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#addNewCCForm').submit(function(event) {
                event.preventDefault();
                var formData = new FormData($(this)[0]);
                $.ajax({
                    type: 'POST',
                    url: "{{ route('command.store') }}",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastr.success('Good Job.', 'Product Has Been Requested!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                            location.reload();
                        }
                        console.log(response);
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            // Validation errors occurred
                            var errors = xhr.responseJSON.errors;

                            // Display each error
                            for (var field in errors) {
                                toastr.warning('Good Job.', 'Opps ' + errors[field][0], {
                                    "showMethod": "slideDown",
                                    "hideMethod": "slideUp",
                                    timeOut: 4000
                                });
                            }
                        } else {
                            // Other types of errors
                            toastr.warning('Good Job.', 'Opps Something went wrong!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                        }
                        console.log(xhr);
                    }
                });
            });
        });
    </script>
    <script>
 $(document).ready(function() {
    $('#inStock').change(function() {
        if ($(this).is(':checked')) {
            $('#Products').change();
            $('#TitreDeProduit, #Prix, #Quantite').prop('readonly', true);
        } else {
            $('#TitreDeProduit, #Prix, #Quantite').prop('readonly', false);
            $('#TitreDeProduit, #Prix, #Quantite').val('');
            $('#Products').val('').trigger('change'); // Clear the selected option
        }
    });

    $('#Products').change(function() {
        var selectedProduct = $(this).children('option:selected');
        if (!selectedProduct.is(':disabled')) {
            $('#TitreDeProduit').val(selectedProduct.text());
            var classes = selectedProduct.attr('class').split('-');
            var quantity = classes[0];
            var prix = classes[1];
            $('#Quantite').val(quantity);
            $('#Prix').val(prix);
        }
    });
});
</script>
@endsection
