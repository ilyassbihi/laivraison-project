@extends('layouts.clientDashboard')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">

        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> all Commandes</h4>
            <a href="{{route('commend.add')}}" type="button" class="btn btn-primary">
                Add New Commande
            </a>
        </div>
        <div class="row mb-5">
        <div class="">
            <div class="row my-3">
                <div class="col-12  ">
                    <form action="{{ route('commend') }}" method="GET">
                        <div class="d-flex justify-content-md-end">
                            <div id="DataTables_Table_3_filter" class="dataTables_filter">
                                <input type="search" name="search" class="form-control" placeholder="Search By Destinataire, Ville"
                                    aria-controls="DataTables_Table_3">
                            </div>
                            <button type="submit" class="mx-3 btn btn-primary me-sm-3 me-1">Search</button>
                        </div>

                    </form>
                </div>
            </div>
            <div class="table-responsive ">
                <table class="table">
                    <thead>
                        <tr>
                            <th>REF</th>

                            <th>Destinataire</th>
                            <th>Ville</th>
                            <th>Montant</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                          @foreach ($commends as $item)
                          <tr>
                        <td>{{$item->id}}</td>

                        <td>{{$item->Destinataire}} - {{$item->TéléphoneD}}</td>
                        <td>{{$item->villee->ville}}</td>
                        <td>{{$item->Prix}}</td>
                        <td><span class="badge badge-pill badge-warning text-dark">{{$item->statusCommend->statusC}}</span></td>
                        <td>
  <div class="action-icons">
    @if($item->statusCommend->statusC == 'Annulée')
      <a class="btn p-0" href="{{ route('command.edit', $item->id) }}" title="Edit">
        <i class="ti ti-pencil me-2"></i>
      </a>
    @endif
    <a href="{{ route('commend.preview', $item->id) }}" target="_blank" class="me-3 text-decoration-none text-dark">
      <i class="ti ti-printer"></i>
  </a>

  </div>
</td>

                          </tr>
                          @endforeach

                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
        $('#productSelection').hide();
        $('#inStock').change(function() {
            if ($(this).is(':checked')) {
                $('#productSelection').show();
            } else {
                $('#productSelection').hide();
            }
        });
    });
        $(document).ready(function() {
            // Function to update checkbox values
            function updateCheckboxValues() {
                var packageOpenedCheckbox = document.getElementById('packageOpened');
                var exchangeRequestedCheckbox = document.getElementById('exchangeRequested');

                // Set the value of the checkboxes based on their checked status
                $('#packageOpened').val(packageOpenedCheckbox.checked ? 1 : 0);
                $('#exchangeRequested').val(exchangeRequestedCheckbox.checked ? 1 : 0);
            }

            // Call the function initially to set values to 0
            updateCheckboxValues();

            // Attach event listeners to the checkboxes
            $('#packageOpened').change(updateCheckboxValues);
            $('#exchangeRequested').change(updateCheckboxValues);
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#addNewCCForm').submit(function(event) {
                event.preventDefault();
                var formData = new FormData($(this)[0]);
                $.ajax({
                    type: 'POST',
                    url: "{{ route('command.store') }}",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            toastr.success('Good Job.', 'Product Has Been Requested!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                            location.reload();
                        }
                        console.log(response);
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            // Validation errors occurred
                            var errors = xhr.responseJSON.errors;

                            // Display each error
                            for (var field in errors) {
                                toastr.warning('Good Job.', 'Opps ' + errors[field][0], {
                                    "showMethod": "slideDown",
                                    "hideMethod": "slideUp",
                                    timeOut: 4000
                                });
                            }
                        } else {
                            // Other types of errors
                            toastr.warning('Good Job.', 'Opps Something went wrong!', {
                                "showMethod": "slideDown",
                                "hideMethod": "slideUp",
                                timeOut: 2000
                            });
                        }
                        console.log(xhr);
                    }
                });
            });
        });
    </script>
    <style>
        .action-icons {
  display: flex;
  align-items: center;
}

.action-icons .btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  margin-right: 8px; /* Adjust spacing as needed */
}

.action-icons .btn:last-child {
  margin-right: 0;
}

    </style>
@endsection
