@extends('layouts.clientDashboard')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> all Commandes</h4>
            <a href="{{route('commend.add')}}" type="button" class="btn btn-primary">
                Add New Commande
            </a>
        </div>
        <div class="row mb-5">
            <div class="card">
                <div class="row my-3">
                    <div class="col-12  ">
                        <form action="{{ route('commend') }}" method="GET">
                            <div class="d-flex justify-content-md-end">
                                <div id="DataTables_Table_3_filter" class="dataTables_filter">
                                    <input type="search" name="search" class="form-control" placeholder="Search By Destinataire, Ville" aria-controls="DataTables_Table_3">
                                </div>
                                <button type="submit" class="mx-3 btn btn-primary me-sm-3 me-1">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="table-responsive text-nowrap">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>REF</th>
                                <th>Destinataire</th>
                                <th>Ville</th>
                                <th>Montant</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            @foreach ($commend as $item)
                                <tr>
                                    <td>{{ $item->id }}</td>
                                    <td>{{ $item->Destinataire }} - {{ $item->TéléphoneD }}</td>
                                    <td>{{ $item->villee->ville }}</td>
                                    <td>{{ $item->Prix }}</td>
                                    <td>
                                        <span class="badge badge-pill badge-warning text-dark">{{ $item->statusCommend->statusC }}</span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
    
    @if($item->statusCommend->statusC === 'Annulée')
        <a href="javascript:void(0);" class="me-3 text-decoration-none text-dark demende-retour" data-command-id="{{ $item->id }}">
            <i class="ti ti-truck-return"></i> 
        </a>
        <a href="{{route('command.edit',$item->id)}}" class="me-3 text-decoration-none text-dark">
        <i class="ti ti-pencil"></i> 
    </a>
    @elseif($item->statusCommend->statusC === 'Nouveau')
<a href="{{route('command.edit',$item->id)}}" class="me-3 text-decoration-none text-dark">
        <i class="ti ti-pencil"></i> 
    </a>
    <a href="javascript:void(0);" class="me-3 text-decoration-none text-dark delete-commend" data-command-id="{{ $item->id }}">
        <i class="ti ti-trash"></i> 
    </a>
        
    @endif
    <a href="{{ route('commend.preview', $item->id) }}" target="_blank" class="me-3 text-decoration-none text-dark">
            <i class="ti ti-printer"></i> 
        </a>
    
</div>

<!--                                        <div class="dropdown">-->
<!--                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown" aria-expanded="false">-->
<!--                                                <i class="ti ti-dots-vertical"></i>-->
<!--                                            </button>-->
<!--                                            <div class="dropdown-menu" style="">-->
<!--                                                <a class="dropdown-item" href="javascript:void(0);"><i class="ti ti-pencil me-1"></i> Edit</a>-->
<!--                                                @if($item->statusCommend->statusC === 'Annulée')-->
<!--                                                    <a class="dropdown-item demende-retour" href="javascript:void(0);" data-command-id="{{ $item->id }}"><i class="ti ti-pencil me-1"></i>Demende Retour</a>-->
<!--                                                @else-->
<!--                                                    <a class="dropdown-item" href="{{ route('pdf.commend',$item->id)}}"><i class="ti ti-pencil me-1"></i>Bon De Livraison</a>-->
<!--                                                @endif-->
<!--                                               <a class="dropdown-item delete-commend" href="javascript:void(0);" data-command-id="{{ $item->id }}">-->
<!--    <i class="ti ti-trash me-1"></i> Delete-->
<!--</a>-->

<!--                                            </div>-->
<!--                                        </div>-->
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="mt-4">
                      {{ $commend->links('vendor.pagination.bootstrap-5') }}
                  </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#productSelection').hide();
            $('#inStock').change(function() {
                if ($(this).is(':checked')) {
                    $('#productSelection').show();
                } else {
                    $('#productSelection').hide();
                }
            });

            // Ajax request to change the status of the command
            $('.demende-retour').click(function(e) {
                e.preventDefault();
                var commandId = $(this).data('command-id');
                $.ajax({
                    type: 'POST',
                    url: "{{ route('change.status') }}",
                    data: {
                        _token: "{{ csrf_token() }}",
                        command_id: commandId,
                        new_status: "Retourné"
                    },
                    success: function(response) {
                        if (response.success) {
                            // Reload the page or handle success as required
                            location.reload();
                        } else {
                            // Handle error
                            console.log(response.message);
                        }
                    },
                    error: function(xhr) {
                        console.log(xhr);
                    }
                });
            });
        });
    </script>
    <script>
$(document).ready(function() {
    $('.delete-commend').click(function() {
        var commendId = $(this).data('command-id');
        if (confirm('Are you sure you want to delete this commend?')) {
            $.ajax({
                url: '{{ url("commend") }}/' + commendId,
                type: 'DELETE',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                success: function(result) {
                    if (result.success) {
                        toastr.success(result.message);
                        location.reload(); // Reload page to update the table
                    } else {
                        toastr.error(result.message);
                    }
                },
                error: function(xhr) {
                    toastr.error('Something went wrong.');
                }
            });
        }
    });
});
</script>

@endsection
