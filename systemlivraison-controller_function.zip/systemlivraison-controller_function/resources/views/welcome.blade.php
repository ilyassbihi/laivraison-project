<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Livraison</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>

<body>
    <header>
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#">LOGO</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav m-lg-auto">
                        <li class="nav-item active">
                            <a class="nav-link rounded" href="#">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="#">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="#">Tarifs</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="#">Avantages</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="#">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="#">Devenir Client</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="#">Espace Client</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h2>Lorem ipsum dolor sit amet</h2>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Corrupti neque quod voluptatem
                        delectus, ad eos laborum alias magnam dolorum eveniet minus, non facilis rerum officiis earum
                        cupiditate excepturi, itaque assumenda?</p>
                    <a href="#" class="btnd1">Read More</a>
                </div>
            </div>
        </div>
    </section>
    <section id="feature" class="section-p1">
        <div class="fe-box">
            <img src='{{ asset('images/ramassage.png') }}' alt="" />
            <h6>Ramassage</h6>
            <p>Le ramassage est un service mis en place par la société Sebbar Livraison afin de faciliter au maximum votre processus d’expédition.</p>
        </div>
        <div class="fe-box">
            <img src='{{ asset('images/livraison.jpg') }}' alt="" />
            <h6>Livraison</h6>
            <p>Grâce à une connaissance du terrain, nos livreurs récupèrent les colis pour une livraison en mains propres à vos clients dans plusieurs villes.</p>
        </div>
        <div class="fe-box">
            <img src='{{ asset('images/expidition.png') }}' alt="" />
            <h6>Expédition</h6>
            <p>L’équipe de Sebbar Livraison assure l’acheminement de vos colis à votre destinataire contre un accusé de réception.</p>
        </div>
        <div class="fe-box">
            <img src='{{ asset('images/payment.png') }}' alt="" />
            <h6>Fonds et paiements</h6>
            <p>Nous assure le retour de fonds dans 48 H, des Virements, des bons de livraison d’une manière régulière sur les services de messagerie de nos clients.</p>
        </div>
    </section>
    <style>
        header {
            position: absolute;
            z-index: 10;
            width: 100%;
        }

        .navbar {
            padding: 20px 10px;
        }

        .navbar-brand {
            font-weight: 800;
            text-transform: uppercase;
            font-size: 2em;
            color: #26226;

        }

        .nav-item {
            font-weight: 800;
            text-transform: uppercase;
        }

        .navbar-light .navbar-nav .nav-item .nav-link {
            color: #262626;
            padding: 5px 15px;
            margin: 0px 5px;
        }

        .navbar-light .navbar-nav .nav-item .nav-link:hover,
        .navbar-light .navbar-nav .nav-item.active .nav-link {
            background: #262626;
            color: #fff;
        }

        .banner {
            position: relative;
            background: url('{{ asset('images/logo.jpg') }}');
            min-height: 100vh;
            background-size: cover;
            background-position: center;
            padding: 250px 0 200px;
        }

        .banner h2 {
            margin: 0;
            padding: 0;
            font-size: 2.8em;
            font-weight: 1000;
            color: #262626;
            text-transform: uppercase;
        }

        .banner p {
            margin: 1em 0 0;
            padding: 0;
            font-size: 1.2em;
            font-weight: 1000;
            line-height: 1.5em;
            color: #262626;
        }

        .btnd1 {
            display: inline-block;
            margin: 1em 0 0;
            background: #ff2670;
            color: #fff;
            padding: 10px 20px;
            text-transform: uppercase;
            border: none;
            font-weight: 800;
            text-decoration: none;
        }

        .btnd1:hover {
            color: #fff;
            text-decoration: none;
        }

        .navbar-light .navbar-togller {
            border: none;
            color: #fff;
            border: 2px solid #7f7f7f;
            border-radius: 0;
            outline: 0;
        }

        .section-p1 {
            padding: 40px 80px;
        }

        .section-m1 {
            margin: 40px 0;
        }

        #feature {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        #feature .fe-box {
            width: 23%;
            text-align: center;
            padding: 25px 15px;
            box-shadow: 20px 20px 34px rgba(0, 0, 0, 0.03);
            border: 1px solid #cce7d0;
        }

        #feature .fe-box:hover {
            box-shadow: 10px 10px 54px rgba(0, 0, 0, 0.01);
        }

        #feature .fe-box img {
            width: 100%;
            margin-bottom: 10px;
        }

        #feature .fe-box h6 {
            display: inline-block;
            padding: 9px 8px 6px 8px;
            line-height: 1;
            border-radius: 4px;
            color: #088178;
            background-color: #fddde4;
        }

        #feature .fe-box:nth-child(2) h6 {
            background-color: #cdebbc;
        }

        #feature .fe-box:nth-child(3) h6 {
            background-color: #edeea4;
        }

        #feature .fe-box:nth-child(4) h6 {
            background-color: #97eed8;
        }

        #feature .fe-box:nth-child(5) h6 {
            background-color: #4ac2f1;
        }

        #feature .fe-box:nth-child(6) h6 {
            background-color: #c28ff1;
        }



        @media (max-width: 990px) {
            .navbar-nav {
                background: white;
            }
            #feature .fe-box {
            width: 30%;
            margin-top: 10px;
        }
        }

        @media (max-width: 768px) {
            .banner {
                background: url('{{ asset('images/logo768.jpg') }}');
                padding: 200px 0;
            }

            .banner h2 {
                font-size: 1.8em
            }

                        #feature .fe-box {
            width: 45%;
            margin-top: 10px;
        }
        }

         @media (max-width: 600px) {
                                    #feature .fe-box {
            width: 100%;
            margin-top: 10px;
        }
         }

        @media (max-width: 412px) {
            .banner {
                background: url('{{ asset('images/logo419.jpg') }}');
                padding: 200px 0;
            }

            .banner h2 {
                font-size: 1.8em
            }
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
