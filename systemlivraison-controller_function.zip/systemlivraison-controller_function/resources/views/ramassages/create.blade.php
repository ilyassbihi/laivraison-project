<!-- resources/views/ramassages/create.blade.php -->

@extends('layouts.clientDashboard')

@section('content')
    <h1>Create New Ramassage</h1>
    <form method="POST" action="{{ route('ramassages.store') }}">
        @csrf
        <label for="Nom">Nom:</label><br>
        <input type="text" id="Nom" name="Nom"><br>

        <label for="Téléphone">Téléphone:</label><br>
        <input type="text" id="Téléphone" name="Téléphone"><br>

        <label for="ville">Ville:</label><br>
        <input type="text" id="ville" name="ville"><br>

        <label for="Adresse">Adresse:</label><br>
        <input type="text" id="Adresse" name="Adresse"><br>

        <label for="ramassage_colis">Ramassage Colis:</label><br>
        <input type="checkbox" id="ramassage_colis" name="ramassage_colis" onclick="handleCheckboxChange(this)"><br>

        <div id="commends_section" style="display: none;">
          <label for="selected_commends">Select Commends:</label><br>
          @foreach ($commends as $commend)
              <div>
                  <input type="checkbox" id="commend_{{ $commend->id }}" name="selected_commends[]" value="{{ $commend->id }}">
                  <label for="commend_{{ $commend->id }}">{{ $commend->QRcodeCommand }}</label>
              </div>
          @endforeach
          <div id="quantity_commend" style="display: none;">
              <label for="total_colis">Total Colis:</label>
              <input type="text" id="total_colis" name="total_colis" readonly>
          </div>
      </div>


        <label for="ramassage_stock">Ramassage Stock:</label><br>
        <input type="checkbox" id="ramassage_stock" name="ramassage_stock" onclick="handleCheckboxChange(this)"><br>

        <div id="products_section" style="display: none;">
          <label for="selected_products">Select Products:</label><br>
    @foreach ($products as $product)
        <div>
            <input type="checkbox" id="product_{{ $product->id }}" name="selected_products[]" value="{{ $product->id }}" data-quantity-input="quantity_{{ $product->id }}" onchange="updateTotalQuantity()">
            <label for="product_{{ $product->id }}">{{ $product->name }}</label>
            <input type="number" id="quantity_{{ $product->id }}" name="quantities[]" min="1" value="{{$product->quantity}}" onchange="updateProductQuantity(this)">
          </div>
    @endforeach
      </div>


        <label for="quantity">Quantité:</label><br>
        <input type="text" id="total_quantity" name="total_quantity" ><br>


        <label for="remarque">Remarque:</label><br>
        <textarea id="remarque" name="remarque"></textarea><br>

        <button type="submit">Submit</button>
    </form>

    <script>
      function updateTotalQuantity() {
        let totalQuantity = 0;
        const quantityInputs = document.querySelectorAll('input[name="quantities[]"]');

        quantityInputs.forEach(input => {
            totalQuantity += parseInt(input.value);
        });

        document.getElementById('total_quantity').value = totalQuantity;
    }

    function updateProductQuantity(input) {
        const productId = input.id.replace('quantity_', '');
        const productCheckbox = document.getElementById('product_' + productId);

        if (input.value > 0 && !productCheckbox.checked) {
            productCheckbox.checked = true;
        }

        updateTotalQuantity();
    }
        function handleCheckboxChange(checkbox) {
            var commendsSection = document.getElementById('commends_section');
            var productsSection = document.getElementById('products_section');
            var checkBoxes = document.querySelectorAll('input[type="checkbox"]');

            if (checkbox.id === 'ramassage_colis') {
                if (checkbox.checked) {
                    commendsSection.style.display = 'block';
                    productsSection.style.display = 'none';
                    document.getElementById('ramassage_stock').checked = false;
                } else {
                    commendsSection.style.display = 'none';
                }
            } else if (checkbox.id === 'ramassage_stock') {
                if (checkbox.checked) {
                    productsSection.style.display = 'block';
                    commendsSection.style.display = 'none';
                    document.getElementById('ramassage_colis').checked = false;
                } else {
                    productsSection.style.display = 'none';
                }
            }

            // Ensure only one checkbox is checked at a time
            checkBoxes.forEach(function (cb) {
                if (cb !== checkbox) {
                    cb.checked = false;
                }
            });
        }


    </script>
@endsection
