<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Livraison</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('3taqny.png') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

</head>

<body>
    <header>
        <div class="">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#">3TAQNY</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav m-lg-auto">
                        <li class="nav-item active">
                            <a class="nav-link rounded" href="#Home">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="#Services">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="#About">À propos de nous</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="{{route('home.tarifs')}}">Tarifs</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="#Contact">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link rounded" href="{{ route('signup.index') }}">Devenir Client</a>
                        </li>
                        <li class="nav-item">
                          @guest
                              <a class="nav-link rounded" href="{{ route('signin.index') }}">Espace Client</a>
                          @else
                              @if(auth()->user()->rolee->nameRole == 'admin')
                                  <a class="nav-link rounded" href="{{ route('admin.index') }}">Dashboard</a>
                              @elseif(auth()->user()->rolee->nameRole == 'super admin')
                                  <a class="nav-link rounded" href="{{ route('admin.index') }}">Dashboard</a>
                              @elseif(auth()->user()->rolee->nameRole == 'commercial')
                                  <a class="nav-link rounded" href="{{ route('client.index') }}">Dashboard</a>
                              @elseif(auth()->user()->rolee->nameRole == 'livreur')
                                  <a class="nav-link rounded" href="{{ route('livreur.index') }}">Dashboard</a>
                              @endif
                          @endguest
                      </li>


                    </ul>
                </div>
            </nav>
        </div>
    </header>
    <div>
        @yield('content')
    </div>
    <!-- Remove the container if you want to extend the Footer to full width. -->
    <div class="">

        <!-- Footer -->
        <footer class="text-center text-lg-start text-white" style="background-color: #1c2331">
            <!-- Section: Social media -->
            <section class="d-flex justify-content-between p-4" style="background-color: #6351ce">
                <!-- Left -->
                <div class="me-5">
                    <span></span>
                </div>
                <!-- Left -->

                <!-- Right -->
                <div>
                    <a href="" class="text-white me-4">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="" class="text-white me-4">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="" class="text-white me-4">
                        <i class="fab fa-google"></i>
                    </a>
                    <a href="" class="text-white me-4">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="" class="text-white me-4">
                        <i class="fab fa-linkedin"></i>
                    </a>
                    <a href="" class="text-white me-4">
                        <i class="fab fa-github"></i>
                    </a>
                </div>
                <!-- Right -->
            </section>
            <!-- Section: Social media -->

            <!-- Section: Links  -->
            <section class="">
                <div class="container text-center text-md-start mt-5">
                    <!-- Grid row -->
                    <div class="row mt-3">
                        <!-- Grid column -->
                        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                            <!-- Content -->
                            <h6 class="text-uppercase fw-bold">3TAQNY</h6>
                            <hr class="mb-4 mt-0 d-inline-block mx-auto"
                                style="width: 60px; background-color: #7c4dff; height: 2px" />
                            <p>
                              Votre nouveau partenaire de livraison offrant les meilleurs services de livraison.
                              Nous proposons la livraison la plus rapide et la plus fiable dans la région métropolitaine et le cœur de la région du Grand Casablanca (Casablanca-Settat), y compris Mohammedia, Benslimane, Bouznika et les environs.
                            </p>
                        </div>
                        <!-- Grid column -->

                        <!-- Grid column -->
                        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                            <!-- Links -->
                            <h6 class="text-uppercase fw-bold">Services</h6>
                            <hr class="mb-4 mt-0 d-inline-block mx-auto"
                                style="width: 60px; background-color: #7c4dff; height: 2px" />
                            <p>
                                <a style="text-decoration: none" href="#Services" class="text-white">Ramassage</a>
                            </p>
                            <p>
                                <a style="text-decoration: none" href="#Services" class="text-white">Livraison</a>
                            </p>
                            <p>
                                <a style="text-decoration: none" href="#Services" class="text-white">Expédition</a>
                            </p>
                            <p>
                                <a style="text-decoration: none" href="#Services" class="text-white">Fonds et paiements</a>
                            </p>
                        </div>
                        <!-- Grid column -->

                        <!-- Grid column -->
                        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                            <!-- Links -->
                            <h6 class="text-uppercase fw-bold"> links</h6>
                            <hr class="mb-4 mt-0 d-inline-block mx-auto"
                                style="width: 60px; background-color: #7c4dff; height: 2px" />
                            <p>
                                <a style="text-decoration: none" href="{{route('signin.index')}}" class="text-white">Login</a>
                            </p>
                            <p>
                                <a style="text-decoration: none" href="{{route('signup.index')}}" class="text-white">Registre</a>
                            </p>

                        </div>
                        <!-- Grid column -->

                        <!-- Grid column -->
                        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                            <!-- Links -->
                            <h6 class="text-uppercase fw-bold">Contact</h6>
                            <hr class="mb-4 mt-0 d-inline-block mx-auto"
                                style="width: 60px; background-color: #7c4dff; height: 2px" />
                            <p><i class="fas fa-home mr-3"></i> Bd Hassan II, Benslimane 13000</p>
                            <p><i class="fas fa-envelope mr-3"></i> Contact@3taqny.com</p>
                            <p><i class="fas fa-phone mr-3"></i> + 212 673 270 114</p>
                            <p><i class="fas fa-print mr-3"></i> + 212 711 427 676</p>
                        </div>
                        <!-- Grid column -->
                    </div>
                    <!-- Grid row -->
                </div>
            </section>
            <!-- Section: Links  -->

            <!-- Copyright -->
            <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
                © 2024 Copyright:
                <a class="text-white" href="https://3taqny.com/">3taqny.com</a>
            </div>
            <!-- Copyright -->
        </footer>
        <!-- Footer -->

    </div>
    <!-- End of .container -->

    <style>
        .banner {
            background: url("{{ asset('images/logo.jpg') }}");
        }

        .contact-container {
            background: url("{{ asset('images/logo.jpg') }}");
        }

        #page-header {
            background-image: url("{{ asset('images/banner.png') }}");
        }

        @media (max-width: 768px) {
            .banner {
                background: url("{{ asset('images/logo768.jpg') }}");
            }
        }

        @media (max-width: 412px) {
            .banner {
                background: url("{{ asset('images/logo419.jpg') }}");
            }
        }
    </style>
    <script>
       document.addEventListener("DOMContentLoaded", function() {
    var navbar = document.querySelector('.navbar');
    var scrollPosition = window.scrollY;

    // Set initial background color based on scroll position
    if (scrollPosition > 0) {
        navbar.style.backgroundColor = '#e93c02';
    } else {
        navbar.style.backgroundColor = '#f0f0ee';
    }

    // Add event listener for scroll to change background color
    window.addEventListener('scroll', function() {
        scrollPosition = window.scrollY;

        // Change background color when scrolling down
        if (scrollPosition > 0) {
            navbar.style.backgroundColor = '#e93c02';
        } else {
            navbar.style.backgroundColor = '#f0f0ee';
        }
    });
});
    </script>
    <script>
        function moveUp(element) {
            element.classList.add('move-up');
        }

        function moveDown(element) {
            element.classList.remove('move-up');
        }
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Add event listener for smooth scrolling
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();

                    const targetId = this.getAttribute('href').substring(1);
                    const targetElement = document.getElementById(targetId);

                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 100,
                            behavior: 'smooth'
                        });
                    }
                });
            });

            // Add event listener for highlighting active nav item
            window.addEventListener('scroll', function() {
                const sections = document.querySelectorAll('section');
                const scrollPosition = window.scrollY;

                sections.forEach(section => {
                    if (scrollPosition >= section.offsetTop - 100 &&
                        scrollPosition < section.offsetTop + section.offsetHeight - 100) {
                        const id = section.getAttribute('id');
                        const correspondingLink = document.querySelector(`a[href="#${id}"]`);
                        if (correspondingLink) {
                            document.querySelectorAll('.nav-item').forEach(item => {
                                item.classList.remove('active');
                            });
                            correspondingLink.parentElement.classList.add('active');
                        }
                    }
                });
            });
        });
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
</body>

</html>
