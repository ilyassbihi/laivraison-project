<!DOCTYPE html>

<html lang="en" class="light-style layout-navbar-fixed layout-menu-fixed" dir="ltr" data-theme="theme-default"
    data-assets-path="{{ asset('assets/') }}" data-template="vertical-menu-template">

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
        <meta name="csrf-token" content="{{ csrf_token() }}">


    <title>Dashboard - EUROPEAN FULFILLEMENT </title>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('3taqny.png') }}">

    <!-- Fonts -->
    <link rel="preconnect" href="https:/fonts.googleapis.com" />
    <link rel="preconnect" href="https:/fonts.gstatic.com" crossorigin />
    <link
        href="https:/fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet" />

    <!-- Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet" />

    <!-- Icons -->
    <link rel="stylesheet" href="{{ asset('assets/vendor/fonts/fontawesome.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/fonts/tabler-icons.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/fonts/flag-icons.css') }}" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="{{ asset('assets/vendor/css/rtl/core.css') }}" class="template-customizer-core-css" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/css/rtl/theme-default.css') }}"
        class="template-customizer-theme-css" />
    <link rel="stylesheet" href="{{ asset('assets/css/demo.css') }}" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/node-waves/node-waves.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/typeahead-js/typeahead.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/bs-stepper/bs-stepper.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/select2/select2.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/formvalidation/dist/css/formValidation.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/bootstrap-select/bootstrap-select.css') }}" />
    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="{{ asset('assets/vendor/js/helpers.js') }}"></script>

    <!-- Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!-- Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    <script src="{{ asset('assets/vendor/js/template-customizer.js') }}"></script>
    <!-- Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="{{ asset('assets/js/config.js') }}"></script>


    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <script src="{{ asset('js/main.js') }}"></script>

    <style>
        .action-icons {
  display: flex;
  align-items: center;
}

.action-icons .btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  margin-right: 8px; /* Adjust spacing as needed */
}

.action-icons .btn:last-child {
  margin-right: 0;
}
    </style>

    <style>
        .form-select-lg {
            padding-top: 0 !important;
            padding-bottom: 0.594rem !important;
            padding-left: 1rem !important;
            font-size: 0.950rem !important;
            border-radius: 0.5rem;
        }

        .position-relative {
            width: 100%;
        }

        .my-active>.page-link {
            background-color: #ff5749;
            color: #fff;
        }

        .bg-label-noanswer {
            background-color: #ffec8b !important;
            color: #d2af01;
        }

        .bg-label-duplicated {
            background-color: #fbdc17 !important;
            background-color: #fbdc17 !important;
        }

        .bg-label-outofstock {
            background-color: #f6d5ad !important;
            background-color: #fe8d03 !important;
        }

        .bg-label-rejected {
            background-color: #ff8482 !important;
            background-color: #ff1814 !important;
        }

        .bg-label-wrong {
            background-color: #f6d5ad !important;
            background-color: #fc9f2d !important;
        }

        .bg-label-info {
            background-color: #d9f8fc !important;
            color: #00cfe8 !important;
        }

        .bg-label-warning {
            background-color: #fff1e3 !important;
            color: #ff9f43 !important;
        }

        .bg-label-danger {
            background-color: #fce5e6 !important;
            color: #ea5455 !important;
        }

        .video {
            background-color: #ff1500 !important;
            border-color: #ff5849 !important;
        }

        .css1 {
            font-size: 20px;
            font-family: century-gothic, sans-serif;
            font-style: italic;
            font-weight: bold;
            color: black;
            text-shadow: 2px 2px 8px #FF0000;
        }
    </style>
</head>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->

            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <div class="app-brand demo">
                    <a href="" class="app-brand-link">
                        <img class="w-10" src="{{ asset('3taqny.png') }}"
                            style=" width: 50px; " />
                        {{-- <span class="app-brand-text demo menu-text fw-bold" style="font-size: 1.075rem;">ECOMFULFILLEMENT</span> --}}
                    </a>
                    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
                        <i class="ti menu-toggle-icon d-none d-xl-block ti-sm align-middle"></i>
                        <i class="ti ti-x d-block d-xl-none ti-sm align-middle"></i>
                    </a>
                </div>

                <div class="menu-inner-shadow"></div>

                <ul class="menu-inner py-1">
                    <!-- Dashboards -->
                    @if (Auth::check() && Auth::user()->role === 2)


                    <li class="menu-item active open">
                        <a href="{{ route('admin.index') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-smart-home"></i>
                            <div data-i18n="Dashboards">Dashboards</div>


                        </a>
                    </li>
                    <li class="menu-item open" style="">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons ti ti-users"></i>
                            <div data-i18n="Users">Users</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item">
                                <a href="{{ route('newUsers.index') }}" class="menu-link">
                                    <div data-i18n="List">New Users</div>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a href="{{ route('allUsers.index') }}" class="menu-link">
                                    <div data-i18n="AllUsers">All Users</div>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="menu-item ">
                        <a href="{{ route('factures.index') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-package"></i>
                            <div data-i18n="Products">Facture</div>
                        </a>
                    </li>
                    <li class="menu-item ">
                      <a href="{{ route('Bonpaiement.index') }}" class="menu-link ">
                          <i class="menu-icon tf-icons ti ti-user-plus"></i>
                          <div data-i18n="adduser">Bon de paiement</div>
                      </a>
                  </li>
                    <li class="menu-item ">
                        <a href="{{ route('bons-de-routeur.index') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-package"></i>
                            <div data-i18n="Products">bons de routeur</div>
                        </a>
                    </li>
                    <li class="menu-item ">
                        <a href="{{ route('commend') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-package"></i>
                            <div data-i18n="commend">Commends</div>
                        </a>
                    </li>
                    <li class="menu-item ">
                      <a href="{{ route('affecterCommends') }}" class="menu-link ">
                          <i class="menu-icon tf-icons ti ti-package"></i>
                          <div data-i18n="affectation">Affectation</div>
                      </a>
                  </li>
                    <li class="menu-item ">
                        <a href="{{ route('ramassages.index') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-truck"></i>
                            <div data-i18n="ramassage">Ramassage</div>
                        </a>
                    </li>

                    <li class="menu-item ">
                        <a href="{{ route('user.create') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-user-plus"></i>
                            <div data-i18n="adduser">Add User</div>
                        </a>
                    </li>

                    <li class="menu-item open" style="">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons ti ti-users"></i>
                            <div data-i18n="Users">Parametrage</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item">
                                <a href="{{ route('tariff.all') }}" class="menu-link">
                                    <div data-i18n="tarifs">Tarifs</div>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a href="{{ route('ville.allville') }}" class="menu-link">
                                    <div data-i18n="LivVille">Livraison Villes</div>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a href="{{ route('ville.allRamville') }}" class="menu-link">
                                    <div data-i18n="RamVille">Ramassage Villes</div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    @elseif (Auth::check() && Auth::user()->role === 4)
                    <li class="menu-item active open">
                        <a href="{{ route('client.index') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-smart-home"></i>
                            <div data-i18n="Dashboards">Dashboards</div>
                        </a>
                    </li>
                    {{-- <li class="menu-item ">
                      <a href="{{route('myProduct')}}" class="menu-link ">
                          <i class="menu-icon tf-icons ti ti-package"></i>
                          <div data-i18n="Products">Products</div>
                      </a>
                  </li> --}}
                  <li class="menu-item ">
                      <a href="{{route('commendClient')}}" class="menu-link ">
                          <i class="menu-icon tf-icons ti ti-package"></i>
                          <div data-i18n="commend">Commends</div>
                      </a>
                  </li>
                  <li class="menu-item ">
                      <a href="{{route('ramassages.client')}}" class="menu-link ">
                          <i class="menu-icon tf-icons ti ti-truck"></i>
                          <div data-i18n="ramassage">Ramassage</div>
                      </a>
                  </li>
                    <li class="menu-item ">
                        <a href="{{ route('factures.client') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-package"></i>
                            <div data-i18n="commend">Factures</div>
                        </a>
                    </li>
                    <li class="menu-item ">
                        <a href="{{ route('bons-de-routeur.client') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-package"></i>
                            <div data-i18n="commend">Bons de routeur</div>
                        </a>
                    </li>

                    @elseif (Auth::check() && Auth::user()->role === 3)

                    <li class="menu-item active open">
                        <a href="{{ route('livreur.index') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-smart-home"></i>
                            <div data-i18n="Dashboards">Dashboards</div>
                        </a>
                    </li>
                    <li class="menu-item ">
                        <a href="{{ route('livreur.commend') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-user-plus"></i>
                            <div data-i18n="adduser">list commends</div>
                        </a>
                    </li>
                    <li class="menu-item ">
                        <a href="{{ route('livreur') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-user-plus"></i>
                            <div data-i18n="adduser">ramassage</div>
                        </a>
                    </li>
                    <li class="menu-item ">
                        <a href="{{ route('myBonpaiement.index') }}" class="menu-link ">
                            <i class="menu-icon tf-icons ti ti-user-plus"></i>
                            <div data-i18n="adduser">Bon de paiement</div>
                        </a>
                    </li>
                    @endif
                </ul>
            </aside>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->

                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
                    id="layout-navbar">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="ti ti-menu-2 ti-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <!--<div class="navbar-nav align-items-center" style="width: 20%;">-->
                        <!--    <div class="nav-item navbar-search-wrapper mb-0">-->
                        <!--        <button type="button" class="btn btn-primary video btn-rounded " href=""><i-->
                        <!--                class="menu-icon ti ti-video"></i>Watch Video</button>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <ul class="navbar-nav flex-row align-items-center ms-auto">


                            <!--/ Language -->

                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="#"
                                    data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="{{ asset('assets/img/avatars/1.png') }}" alt
                                            class="h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="{{ asset('assets/img/avatars/1.png') }}" alt
                                                            class="h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    @if (Auth::user())
                                                    <span class="fw-semibold d-block">{{Auth::user()->name}}</span>

                                                    <small class="text-muted"></small>
                                                    @endif
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="{{route('user.profile')}}">
                                            <i class="ti ti-user-check me-2 ti-sm"></i>
                                            <span class="align-middle">My Profile</span>
                                        </a>
                                    </li>

                                    <li>
                                        <a class="dropdown-item" href="#"
                                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                                            aria-expanded="false"><i class="ti ti-logout me-2 ti-sm"></i>
                                            <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                                class="d-none">
                                                @csrf
                                            </form> <span class="align-middle">Logout </span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>

                    <!-- Search Small Screens -->
                    <div class="navbar-search-wrapper search-input-wrapper d-none">
                        <input type="text" class="form-control search-input container-xxl border-0"
                            placeholder="Search..." aria-label="Search..." />
                        <i class="ti ti-x ti-sm search-toggler cursor-pointer"></i>
                    </div>
                </nav>

                <!-- / Navbar -->


                @if (session('success'))
                    <div class="alert alert-success mt-3 mx-4" id="success-card"
                        style="position: fixed; right: 0; z-index: 10;">
                        <strong>Success!</strong> {{ session('success') }}
                    </div>
                @endif
                @if (request('success'))
                    <div class="alert alert-success mt-3 mx-4 " id="productSuccesscard"
                        style="position: fixed; right: 0; z-index: 10;">
                        <strong>Success!</strong> {{ urldecode(request('success')) }}
                    </div>
                @endif
                @yield('content')
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>

        <!-- Drag Target Area To SlideIn Menu On Small Screens -->
        <div class="drag-target"></div>
    </div>
    <!-- / Layout wrapper -->



    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const successCard = document.getElementById("productSuccesscard");
            setTimeout(function() {
                successCard.classList.add('d-none');
            }, 5000);
        });
    </script>
    <script src="{{ asset('assets/vendor/libs/jquery/jquery.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/popper/popper.js') }}"></script>
    <script src="{{ asset('assets/vendor/js/bootstrap.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/node-waves/node-waves.js') }}"></script>

    <script src="{{ asset('assets/vendor/libs/hammer/hammer.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/i18n/i18n.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/typeahead-js/typeahead.js') }}"></script>

    <script src="{{ asset('assets/vendor/js/menu.js') }}"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="{{ asset('assets/vendor/libs/bs-stepper/bs-stepper.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/select2/select2.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/formvalidation/dist/js/FormValidation.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/formvalidation/dist/js/plugins/Bootstrap5.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/formvalidation/dist/js/plugins/AutoFocus.min.js') }}"></script>

    <!-- Main JS -->
    <script src="{{ asset('assets/js/main.js') }}"></script>

    <!-- Page JS -->

    <script src="{{ asset('assets/js/form-wizard-numbered.js') }}"></script>
    <script src="{{ asset('assets/js/form-wizard-validation.js') }}"></script>
    <script src="{{ asset('assets/js/forms-selects.js') }}"></script>
    <script src="{{ asset('assets/js/forms-tagify.js') }}"></script>
    <script src="{{ asset('assets/js/forms-typeahead.js') }}"></script>




    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const successCard = document.getElementById("success-card");
            setTimeout(function() {
                successCard.classList.add('d-none');
            }, 8000);
        });
    </script>
    <!-- Toastr -->
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    @yield('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
        integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>

</html>
