<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\Role;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class livreurmiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('signin.index')->with('error', 'Vous devez vous connecter pour accéder à cette page.');
        }
        $role= Role::where('nameRole','like','livreur')->first();
        
        if (!(auth()->user()->role == $role->id)) {
            return back()->with('error', 'Accès interdit. Vous n\'êtes pas administrateur.');
        }
        return $next($request);
    }
}
