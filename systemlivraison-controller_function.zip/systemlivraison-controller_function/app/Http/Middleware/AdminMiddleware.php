<?php

namespace App\Http\Middleware;

use App\Models\Role;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('signin.index')->with('error', 'Vous devez vous connecter pour accéder à cette page.');
        }
        $role= Role::where('nameRole','like','admin')->first();
        
        if (!(auth()->user()->role == $role->id)) {
            return back()->with('error', 'Accès interdit. Vous n\'êtes pas administrateur.');
        }

       
        return $next($request);
    }
}
