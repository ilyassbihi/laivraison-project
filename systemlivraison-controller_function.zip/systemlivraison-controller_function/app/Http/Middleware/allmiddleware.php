<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\Role;
use App\Models\Status;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class allmiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('signin.index')->with('error', 'Vous devez vous connecter pour accéder à cette page.');
        }

        // Vérifier si l'utilisateur a le rôle de commercial
        $role1 = Role::where('nameRole', 'like', '%commercial%')->first();
        $role2 = Role::where('nameRole', 'like', 'admin')->first();
        $status= Status::where('name','like','active')->first();
        if (!(auth()->user()->role == $role1->id || auth()->user()->role == $role2->id) ||!(auth()->user()->status == $status->id)) {
            return back()->with('error', 'Accès interdit. Vous n\'êtes pas commercial.');
        }
        return $next($request);
    }
}
