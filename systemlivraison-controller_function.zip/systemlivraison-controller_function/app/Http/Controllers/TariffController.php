<?php

namespace App\Http\Controllers;

use App\Mail\ContactFormMail;
use App\Models\Tariff;
use App\Models\ville;
use App\Models\VilleRamassage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class TariffController extends Controller
{
  public function allville()
  {
    $villes = ville::all();
    return view('ville.allville', compact('villes'));
  }
  public function allvilleramassage()
  {
    $villesramassage = VilleRamassage::all();
    return view('ville.villeramassage', compact('villesramassage'));
  }

  public function store(Request $request)
  {
    $validatedData = $request->validate([
      'ville' => 'required|string|max:255'
    ]);
    ville::create([
      'ville' => $validatedData['ville']
    ]);

    return response()->json(['success' => true, 'message' => 'ville added successfully!']);
  }

  public function updateVille(Request $request, $id)
  {
    $validatedData = $request->validate([
      'ville' => 'required|string|max:255',
    ]);

    $ville = Ville::findOrFail($id);
    $ville->update([
      'ville' => $validatedData['ville'],
    ]);

    return response()->json(['success' => true, 'message' => 'Ville updated successfully!']);
  }

  public function destroyVille($id)
  {
    $ville = Ville::findOrFail($id);
    $ville->delete();

    return response()->json(['success' => true, 'message' => 'Ville deleted successfully!']);
  }

  public function storevilleramassage(Request $request)
  {
    $validatedData = $request->validate([
      'villeR' => 'required|string|max:255'
    ]);
    VilleRamassage::create([
      'villeR' => $validatedData['villeR']
    ]);

    return response()->json(['success' => true, 'message' => 'ville added successfully!']);
  }

  public function updateVilleR(Request $request, $id)
  {
    $validatedData = $request->validate([
      'villeR' => 'required|string|max:255',
    ]);

    $ville = VilleRamassage::findOrFail($id);
    $ville->update(['villeR' => $validatedData['villeR']]);

    return response()->json(['success' => true, 'message' => 'Ville updated successfully!']);
  }

  public function destroyVilleR($id)
  {
    $ville = VilleRamassage::findOrFail($id);
    $ville->delete();

    return response()->json(['success' => true, 'message' => 'Ville deleted successfully!']);
  }

  public function allTariffs(Request $request)
  {
    $villes = ville::all();
    $villesramassage = VilleRamassage::all();
    // Retrieve query parameters
    $originCityId = $request->input('OriginCity');
    $destinationCityId = $request->input('DestinationCity');

    // Start query with a relation-loaded base query
    $query = Tariff::with(['originCity', 'destinationCity']);

    // Apply filters conditionally
    if ($originCityId) {
      $query->where('origin_city_id', $originCityId);
    }

    if ($destinationCityId) {
      $query->where('destination_city_id', $destinationCityId);
    }

    // Paginate the results
    $tariffs = $query->paginate(15);
    return view('tariff.all_tariffs', compact('tariffs', 'villes', 'villesramassage'));
  }
  public function create()
  {
    $villes = ville::all();
    $villesramassage = VilleRamassage::all();
    return view('tariff.create_tariff', compact('villes', 'villesramassage'));
  }
  public function storetariff(Request $request)
  {
    $validatedData = $request->validate([
      'origin_city_id' => 'required|exists:ville_ramassages,id',
      'destination_city_id' => 'required|array',
      'destination_city_id.*' => 'exists:villes,id',
      'tariff' => 'required|array',
      'tariff.*' => 'numeric|min:0',
    ]);

    foreach ($validatedData['destination_city_id'] as $destination_city_id) {
      Tariff::create([
        'origin_city_id' => $validatedData['origin_city_id'],
        'destination_city_id' => $destination_city_id,
        'tariff' => $validatedData['tariff'][$destination_city_id],
      ]);
    }

    return redirect()->route('tariff.all')->with('success', 'Tariffs created successfully.');
  }

  public function updatetariff(Request $request, $id)
  {
    $validatedData = $request->validate([
      'tariff' => 'required|numeric|min:0',
    ]);

    $tariff = Tariff::findOrFail($id);
    $tariff->update([
      'tariff' => $validatedData['tariff']
    ]);

    return response()->json(['success' => true, 'message' => 'Tariff updated successfully.']);
  }








  public function getExistingDestinations(Request $request)
  {
    $origin_city_id = $request->origin_city_id;

    $existing_destinations = Tariff::where('origin_city_id', $origin_city_id)
      ->pluck('destination_city_id')
      ->toArray();

    $available_destinations = Ville::whereNotIn('id', $existing_destinations)
      ->pluck('ville', 'id')
      ->toArray();

    return response()->json([
      'success' => true,
      'data' => $available_destinations
    ]);
  }
}
