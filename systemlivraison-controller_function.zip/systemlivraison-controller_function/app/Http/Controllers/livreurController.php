<?php

namespace App\Http\Controllers;

use App\Models\commend;
use App\Models\Role;
use App\Models\User;
use App\Models\Ramassage;
use App\Models\statusCommend;
use App\Models\StatusRamassage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class livreurController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

          $ramassages= Ramassage::where('livreur','=',Auth::user()->id)->get();
          $status= StatusRamassage::all();
       return view('livreur.index',compact('ramassages','status'));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function listcommends()
{

    // Fetch all the commands assigned to the logged-in 'livreur'
    $commands = Commend::where('livreur', Auth::user()->id)
    ->where('bone_paiment', false)
    ->get();

    // Fetch the statuses to display in the modal
    $statuses = StatusCommend::whereIn('id', [2, 3, 9])->get();

    return view('livreur.listcommen', compact('commands', 'statuses'));
}




    public function updateStatus(Request $request)
    {
        $commandId = $request->input('command_id');
        $statusId = $request->input('status_id');

        // Find the command
        $command = commend::findOrFail($commandId);

        // Find the status
        $status = statusCommend::findOrFail($statusId);

        // Update the command's status
        $command->statusCommend()->associate($status);
        $command->save();

        // You can return a response if needed
        return response()->json(['message' => 'Status updated successfully']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }
      public function updateStatuslivreur(Request $request,$id)
    {
        $Demande_traitee = StatusRamassage::where('nameR', 'like', '%Demande traitee%')->first();
        $Demande_recu = StatusRamassage::where('nameR', 'like', '%Demande recue%')->first();
        $ramasse = statusCommend::where('statusC', 'like', '%Ramassé%')->first();
        $attend = statusCommend::where('statusC', 'like', '%En attente de Ramassage%')->first();
        $Ramassage = Ramassage::findOrFail($id);
        $Ramassage->status_ramassages = $request->input('status');
        $Ramassage->save();

        if ($Ramassage->status_ramassages == $Demande_traitee->id) {
            $commandIds = json_decode($Ramassage->selected_commends) ;
            $commandIdsarray = array_map('intval',$commandIds);;
            $commandIdsarrayint = array_map('intval',$commandIdsarray);
            for ($i=0; $i <count($commandIdsarrayint)  ; $i++) {
                $command = commend::findOrFail($commandIdsarrayint[$i]);
                $command->status_commends = $ramasse->id;
                $command->save();
            }
        }
        if ($Ramassage->status_ramassages == $Demande_recu->id) {
            $commandIds = json_decode($Ramassage->selected_commends) ;
            $commandIdsarray = array_map('intval',$commandIds);;
            $commandIdsarrayint = array_map('intval',$commandIdsarray);
            for ($i=0; $i <count($commandIdsarrayint)  ; $i++) {
                $command = commend::findOrFail($commandIdsarrayint[$i]);
                $command->status_commends = $attend->id;
                $command->save();
            }
        }
       return back();
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
