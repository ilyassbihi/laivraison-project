<?php

namespace App\Http\Controllers;

use App\Models\commend;
use App\Models\Ramassage;
use App\Models\Role;
use App\Models\Status;
use App\Models\User;
use App\Models\ville;
use Carbon\Carbon;
use Illuminate\Contracts\Auth\StatefulGuard;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function allUsers()
    {
        $roles = Role::whereIn('nameRole', ["commercial", "livreur"])->get();
        $roleIds = $roles->pluck('id');

        $clients = User::whereIn("role", $roleIds)
            ->orderByRaw("CASE
                                    WHEN status = (SELECT id FROM statuses WHERE name = 'Pending verification') THEN 1
                                    WHEN status = (SELECT id FROM statuses WHERE name = 'Active') THEN 2
                                    WHEN status = (SELECT id FROM statuses WHERE name = 'Suspended') THEN 3
                                    ELSE 4
                                END")
            ->paginate(10); // Change the number 10 to the number of users you want to display per page

        return view('admin.allusers')->with('clients', $clients);
    }

    public function userDetails($id)
    {
        $user = User::findOrFail($id);
        $villes = ville::all();
        return view('users.active',compact('user','villes'));
    }

    public function updateDetails(Request $request, $id){
        $user = User::findOrFail($id);
        $user->update([
            'name'=> $request->name,
            'telephone'=> $request->telephone,
            'Address'=> $request->Address,
            'RIB'=> $request->RIB,
            'CIN'=> $request->CIN,
            'email'=> $request->email,
            'ville'=> $request->ville,
        ]);

        return response()->json(['success' => true, 'message' => 'data updated successfully!']);

    }




    public function activerCompte($id)
    {
        $status = Status::where('name', "like", "%active%")->first();
        $compte = User::findOrFail($id);
        $compte->status = $status->id;
        $compte->save();
        return back();
    }
    public function desactiverCompte($id)
    {
        $status = Status::where('name', "like", "%suspended%")->first();
        $compte = User::findOrFail($id);
        $compte->status = $status->id;
        $compte->save();
        return back();
    }

    public function newUsers()
    {
        $status = Status::where('name', "like", "%Pending verification%")->first();
        $role = Role::where('nameRole', "like", "%commercial%")->first();

        $clients = User::where("role", "=", $role->id)
            ->where('status', "=", $status->id)->get();
        return view('admin.newusers')->with('clients', $clients);
    }

    public function statistic()
    {
        $userCount = User::count();
        $commendsCount = commend::count();
        $ramassageCount = Ramassage::count();
        $LivreurCount = User::where('role', 3)->count();
        $CLivreeCount = commend::where('status_commends', 3)->count();
        $AttenteRCount = commend::where('status_commends', 1)->count();
        $RamasseeCount = commend::where('status_commends', 8)->count();
        return view('admin.index', compact(['userCount', 'commendsCount', 'ramassageCount', 'LivreurCount', 'CLivreeCount', 'AttenteRCount', 'RamasseeCount']));
    }

    public function clientStatistic()
    {
        $commendsCount = commend::Where('idclient', Auth::user()->id)->count();
        $ramassageCount = Ramassage::Where('idclient', Auth::user()->id)->count();
        $CLivreeCount = commend::where('status_commends', 3)->Where('idclient', Auth::user()->id)->count();
        $CANULIECount = commend::where('status_commends', 2)->Where('idclient', Auth::user()->id)->count();
        $CRouteurCount = commend::where('status_commends', 7)->Where('idclient', Auth::user()->id)->count();
        $AttenteRCount = commend::where('status_commends', 1)->Where('idclient', Auth::user()->id)->count();
        $RamasseeCount = commend::where('status_commends', 8)->Where('idclient', Auth::user()->id)->count();
        return view('client.index', compact(['commendsCount', 'CRouteurCount', 'ramassageCount', 'CLivreeCount', 'AttenteRCount', 'RamasseeCount', 'CANULIECount']));
    }

    public function livreurStatistic()
{
    $livreurId = Auth::user()->id;

    // Total commands assigned to the livreur
    $commendsCount = Commend::where('livreur', $livreurId)->count();

    // Delivered commands
    $LivreeCount = Commend::where('livreur', $livreurId)
                          ->where('status_commends', 3)
                          ->count();

    // Returned commands
    $RetourCount = Commend::where('livreur', $livreurId)
                          ->where('status_commends', 7)
                          ->count();

    return view('livreur.statistic', compact('commendsCount', 'LivreeCount', 'RetourCount'));
}

}
