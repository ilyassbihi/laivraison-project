<?php

namespace App\Http\Controllers;

use niklasravnsborg\LaravelPdf\Facades\Pdf;
use App\Models\User;
use App\Models\commend;
use App\Models\Facture;
use App\Models\BonDeRouteur;
use Barryvdh\DomPDF\Facade\Pdf as FacadePdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;


class PdfController extends Controller
{
    public function index($ref)
    {
        ini_set('max_execution_time', 3600);
        $commend = commend::with('villee')->findOrFail($ref);


        $data = [
            'commend' => $commend
        ];

        $pdf = Pdf::loadView('pdf.usersPdf', $data);
        return $pdf->stream('users-lists.pdf');
    }
     public function download(Facture $facture)
{
  ini_set ('max_execution_time',3600);
    // Increase the maximum execution time
     // Sets the maximum execution time to 120 seconds

        // Convert commend_ids from JSON to array
        $selected_commends = json_decode($facture->commend_ids);

        // Fetch commends with status "Livré", "Annulée", or "Retourné" and other required data in one query
        $livree_commends = commend::whereIn('id', $selected_commends)
            ->with(['statusCommend', 'villee']) // Eager load relationships
            ->get()
            ->filter(function ($commend) {
                return in_array($commend->statusCommend->statusC, ['Livré', 'Annulée', 'Retourné']);
            });

    // Generate the PDF
    $pdf = Pdf::loadView('pdf.facture', compact('facture', 'livree_commends', 'selected_commends'));

        return $pdf->stream('invoice.pdf');
    }
    public function downloadbon(BonDeRouteur $bonDeRouteur)
    {
        // Convert commend_id from JSON to array
        $selected_commends = json_decode($bonDeRouteur->commend_id);

        // Fetch commends with the given IDs
        $commends = Commend::whereIn('id', $selected_commends)->get();

        // Calculate the frise
        $frise = is_array($selected_commends) ? count($selected_commends) * -10 : 0;

        // Load the PDF view
        $pdf = new Dompdf();
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isPhpEnabled', true);
        $pdf->setOptions($options);

        $pdf->loadHtml(view('pdf.bon_de_routeur_pdf', compact('bonDeRouteur', 'commends', 'selected_commends', 'frise'))->render());

        // (Optional) Setup the paper size and orientation
        $pdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $pdf->render();

        // Output the generated PDF (inline or download)
        return $pdf->stream('bon_de_routeur.pdf');
    }
}
