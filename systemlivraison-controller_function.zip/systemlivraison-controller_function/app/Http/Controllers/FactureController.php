<?php

namespace App\Http\Controllers;

use App\Models\commend;
use Barryvdh\DomPDF\Facade\Pdf as FacadePdf;
use App\Models\User;
use App\Models\Facture;
use App\Models\Ramassage;
use App\Models\StatusFacture;
use Illuminate\Http\Request;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Artisan;

class FactureController extends Controller
{
    public function index(Request $request)
    {

        $search = $request->input('search'); // Get the search term from query string

        // If there's a search term, filter Factures by Ref
        if ($search) {
            $factures = Facture::with('client', 'ramassage')
            ->where('Ref', 'like', '%' . $search . '%')
            ->get();
        } else {
            $factures = Facture::with('client', 'ramassage')->get();
        }

        $clients = User::whereIn('role', [2, 4])
        ->whereHas('commends', function ($query) {
            $query->where('invoiced', false)
                  ->whereIn('status_commends', [2, 3]);
        })
        ->withCount(['commends' => function ($query) {
            $query->where('invoiced', false)
                  ->whereIn('status_commends', [2, 3]);
        }])
        ->get();
        $ramassages = Ramassage::all();
        $status_factures = StatusFacture::all();

        return view('factures.index', compact('factures', 'clients', 'ramassages', 'status_factures'));
    }
   public function factureclient()
{
    $status_paye = StatusFacture::where('statusfac', 'Paye')->firstOrFail()->id;
    $status_enregistre = StatusFacture::where('statusfac', 'Enregistre')->firstOrFail()->id;

    $factures = Facture::with('client', 'ramassage')
                        ->where('idclient', auth()->id())
                        ->whereIn('statusfacturs', [$status_paye, $status_enregistre])
                        ->get();
    $clients = User::all(); // Assuming clients are stored in the 'users' table
    $ramassages = Ramassage::all();
    $status_factures = StatusFacture::all();
    return view('factures.client', compact('factures', 'clients', 'ramassages', 'status_factures'));
}


    public function create()
{
    $clients = User::all();

    $ramassages = Ramassage::all();

    return view('factures.create', compact('clients', 'ramassages'));
}


public function store(Request $request)
{
  $clients=User::where('role',3)->get();
    $client_id = $request->input('client_id');
    $commends = commend::where('idclient', $client_id)
                        ->whereHas('statusCommend', function ($query) {
                            $query->whereIn('statusC', ['Livré', 'Annulée', 'Retourné']);
                        })
                        ->where('invoiced', false) 
                        ->get();

    $total = 0;
    $commend_ids = [];

    foreach ($commends as $commend) {
        if($commend->statusCommend->statusC === 'Annulée') {
            $total -= 5;
        } else {
            $total += $commend->Prix - $commend->tariff;
        }
        $commend_ids[] = $commend->id;
    }

    $ref = mt_rand(1000000, 9999999);
    $defaultStatus = StatusFacture::where('statusfac', 'Brouillon')->firstOrFail();

    $facture = Facture::create([
        'Ref' => $ref,
        'idclient' => $client_id,
        'commend_ids' => json_encode($commend_ids), // Store commend IDs as JSON
        'statusfacturs' => $defaultStatus->id,
        'total' => $total,
    ]);

    // Update commends to mark them as invoiced
    $commends->each->update(['invoiced' => true]);

    return back();
}

public function jdida(Request $request)
{
    $clients = User::whereIn('role',[4,2])->get();
    $invoicesCreated = [];

    foreach ($clients as $client) {
        $client_id = $client->id;

        $commends = Commend::where('idclient', $client_id)
                            ->whereHas('statusCommend', function ($query) {
                                $query->where('statusC', 'Livré');
                            })
                            ->where('invoiced', false)
                            ->get();

        $total = 0;
        $commend_ids = [];

        foreach ($commends as $commend) {
       
                $total += $commend->Prix - $commend->tariff;
            
            $commend_ids[] = $commend->id;
        }

        $ref = mt_rand(1000000, 9999999);
        $defaultStatus = StatusFacture::where('statusfac', 'Brouillon')->firstOrFail();

        $facture = Facture::create([
            'Ref' => $ref,
            'idclient' => $client_id,
            'commend_ids' => json_encode($commend_ids),
            'statusfacturs' => $defaultStatus->id,
            'total' => $total,
        ]);

        $invoicesCreated[] = $facture;

        // Update commends to mark them as invoiced
        $commends->each->update(['invoiced' => true]);
    }

    return back()->with('success');
}


    public function download(Facture $facture)
{
    ini_set ('max_execution_time',3600);
    $pdf = FacadePdf::loadView('pdf.facture', compact('facture'));
    return $pdf->download('invoice_'.$facture->id.'.pdf');
}
public function updateStatus(Request $request)
{
    $facture = Facture::findOrFail($request->facture_id);
    $facture->statusfacturs = $request->status_id;

    // Update date_paiement if the status is changed to "paye"
    if ($request->status_id == StatusFacture::where('statusfac', 'paye')->first()->id) {
        $facture->date_paiement = now(); // Use now() to include hours, minutes, and seconds
    }

    $facture->save();

    return response()->json(['success' => true, 'message' => 'Status updated successfully!']);
}



public function updatePaymentDate(Request $request)
{
    $facture = Facture::findOrFail($request->facture_id);
    $facture->date_paiement = $request->payment_date;
    $facture->save();

    return response()->json(['success' => true, 'message' => 'Payment date updated successfully!']);
}
public function runScheduler()
    {

        // Execute the scheduler command
        Artisan::call('schedule:run');

        // Return a response
        return response()->json(['message' => 'Scheduler executed successfully']);
    }

    public function downloadF(Facture $facture)
    {
        
        $selected_commends = json_decode($facture->commend_ids);

        // Fetch commends with status "Livré", "Annulée", or "Retourné" and other required data in one query
        $livree_commends = commend::whereIn('id', $selected_commends)
            ->with(['statusCommend', 'villee']) // Eager load relationships
            ->get()
            ->filter(function ($commend) {
                return in_array($commend->statusCommend->statusC, ['Livré', 'Annulée', 'Retourné']);
            });


        return view('pdf.test', compact('facture', 'livree_commends', 'selected_commends'));
    }
    public function downloadC($ref)
    {
        $commend = commend::with('villee')->findOrFail($ref);
        return view('pdf.bon_de_livraison', compact('commend'));
    }


}
