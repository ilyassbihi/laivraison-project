<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectTo = '/';

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    protected function authenticated(Request $request, $user)
    {
        if ($user->rolee->nameRole == 'admin') {
            return redirect()->route('admin.index');
        } elseif ($user->rolee->nameRole == 'commercial') {
            return redirect()->route('client.index');
        } elseif ($user->rolee->nameRole == 'livreur') {
            return redirect()->route('livreur.index');
        }

        return redirect($this->redirectTo);
    }
}
