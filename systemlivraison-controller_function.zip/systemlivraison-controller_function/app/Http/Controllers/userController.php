<?php

namespace App\Http\Controllers;

use DateTime;
use Carbon\Carbon;
use App\Models\Role;
use App\Models\Status;
use App\Models\User;
use App\Models\ville;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class userController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $ville= ville::all();
        $role=Role::all();
        return view('users.addusers',compact('ville','role'));
    }
    public function profile()
    {
        $ville= ville::all();
        $role=Role::all();
        return view('users.profile',compact('ville','role'));
    }
    public function update_self(Request $request,$id)
    {


        $user = User::findOrFail($id);
        $user->name = $request->input('name');
        $user->telephone = $request->input('telephone');
        $user->Address = $request->input('address');
        $user->RIB = $request->input('RIB');
        $user->CIN = $request->input('CIN');
        $user->email = $request->input('email');
        $user->email_verified_at = Carbon::now();
        $user->rectoCNI = $request->input('rectoCNI');
        $user->versoCNI = $request->input('versoCNI');
        $user->ville = $request->input('ville');

        // Handle file uploads
        if ($request->hasFile('rectoCNI')) {
            $validatedData['rectoCNI'] = $request->file('rectoCNI')->store('rectoCNI');
        }

        if ($request->hasFile('versoCNI')) {
            $validatedData['versoCNI'] = $request->file('versoCNI')->store('versoCNI');
        }


        $user->save();
        // Redirect or do something else after successful creation
        return back();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $status= Status::where('name','like','%active%')->first();

        $user = new User;
        $user->name = $request->input('name');
        $user->telephone = $request->input('telephone');
        $user->Address = $request->input('address');
        $user->RIB = $request->input('RIB');
        $user->CIN = $request->input('CIN');
        $user->email = $request->input('email');
        $user->password = Hash::make($request->input('password'));
        $user->email_verified_at = Carbon::now();
        if ($request->hasFile('rectoCNI')) {
          $rectoCNI = $request->file('rectoCNI');
          $rectoCNIPath = $rectoCNI->store('imagesuser', 'public');
          $user->rectoCNI = $rectoCNIPath;
      }
      if ($request->hasFile('versoCNI')) {
          $versoCNI = $request->file('versoCNI');
          $versoCNIPath = $versoCNI->store('imagesuser', 'public');
          $user->versoCNI = $versoCNIPath;
      }
        $user->role = $request->input('role');
        $user->commistion = $request->input('commistion');
        $user->status = $status->id;
        $user->ville = $request->input('ville');

        // Handle file uploads



        $user->save();
        // Redirect or do something else after successful creation
        return response()->json(['success' => true, 'message' => 'User added successfully!']);

    }

    /**
     * Display the specified resource.
     */
    public function mdpChange(Request $request,string $id)
    {
        $user = User::findOrFail($id);
        $user->password = Hash::make($request->input('password'));
        $user->save();
        return back();
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
