<?php

namespace App\Http\Controllers;
use niklasravnsborg\LaravelPdf\Facades\Pdf;
use App\Models\User;
use App\Models\commend;
use App\Models\Ramassage;
use App\Models\Bonpaiement;
use Illuminate\Http\Request;
use App\Models\StatusFacture;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class BonpaiementController extends Controller
{
  public function index(Request $request)
  {

      $search = $request->input('search');
      if ($search) {
          $factures = Bonpaiement::with('client', 'ramassage')
          ->where('Ref', 'like', '%' . $search . '%')
          ->get();
      } else {
          $factures = Bonpaiement::with('client', 'ramassage')->get();
      }
      $clients = User::where('role', 3)
        ->whereHas('livreurs', function ($query) {
            $query->where('bone_paiment', false)
                  ->whereIn('status_commends', [2,3,9]);
        })
        ->withCount(['livreurs' => function ($query) {
            $query->where('bone_paiment', false)
                  ->whereIn('status_commends', [2,3,9]);
        }])
        ->get();
      $status_factures = StatusFacture::all();
      return view('Bonpaiement.index', compact('factures', 'clients', 'status_factures'));
  }
  public function mybonpaiement()
  {
      $client=Auth::user()->id;
      // dd($client);
          $bones = Bonpaiement::where('idclient', $client)
          ->get();


      $clients = User::where('role', 3)->get();
      $status_factures = StatusFacture::all();

      return view('Bonpaiement.mybonpaiement', compact('bones', 'clients', 'status_factures'));
  }

  public function store(Request $request)
{

    $livereur_id = $request->input('livreur');

    $commends = commend::where('livreur', $livereur_id)
                        ->whereHas('statusCommend', function ($query) {
                            $query->whereIn('statusC', ['Livré', 'Annulée','Refusé']);
                        })
                        ->where('bone_paiment', false) // Only fetch commends that haven't been invoiced yet
                        ->get();

    $commend_ids = [];
    $total = 0;
    foreach ($commends as $commend) {
      $total += $commend->Prix ;
        $commend_ids[] = $commend->id;
    }

    $ref = mt_rand(1000000, 9999999);
    $defaultStatus = StatusFacture::where('statusfac', 'Brouillon')->firstOrFail();

    $facture = Bonpaiement::create([
        'Ref' => $ref,
        'idclient' => $livereur_id,
        'recu_pye' => null,
        'commend_ids' => json_encode($commend_ids),
        'statusfacturs' => $defaultStatus->id,
        'total' => $total,
    ]);


    $commends->each->update(['bone_paiment' => true]);

     return back();
}
public function updateRecu(Request $request, $id)
{
    $request->validate([
        'recu_pye' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    ]);

    $bonpaiement = Bonpaiement::findOrFail($id);

    if ($request->hasFile('recu_pye')) {
        // Delete the old file if it exists
        if ($bonpaiement->recu_pye && Storage::exists('public/' . $bonpaiement->recu_pye)) {
            Storage::delete('public/' . $bonpaiement->recu_pye);
        }

        // Store the new file
        $filePath = $request->file('recu_pye')->store('recu', 'public');
        $bonpaiement->recu_pye = $filePath;
    }

    $bonpaiement->save();

    return response()->json(['success' => 'Reçu updated successfully.']);
}




public function download(Bonpaiement $Bonpaiement)
{
  ini_set ('max_execution_time',3600);
     $commends= commend::whereIn('id',json_decode($Bonpaiement->commend_ids, false))->get();
    $pdf = Pdf::loadView('pdf.bonPaiment', compact('Bonpaiement','commends'));
    return $pdf->stream('invoice_'.$Bonpaiement->id.'.pdf');
}
public function jdida(Request $request)
{
    $clients = User::where('role',3)->get();
    $invoicesCreated = [];

    foreach ($clients as $client) {
        $client_id = $client->id;

        $commends = Commend::where('livreur', $client_id)
                            ->whereHas('statusCommend', function ($query) {
                                $query->whereIn('statusC',['Livré', 'Annulée']);
                            })
                            ->where('invoiced', false)
                            ->get();

        $total = 0;
        $commend_ids = [];

        foreach ($commends as $commend) {

                $total += $commend->Prix - $commend->tariff;

            $commend_ids[] = $commend->id;
        }

        $ref = mt_rand(1000000, 9999999);
        $defaultStatus = StatusFacture::where('statusfac', 'Brouillon')->firstOrFail();

        $facture = Bonpaiement::create([
            'Ref' => $ref,
            'idclient' => $client_id,
            'recu_pye' => null,
            'commend_ids' => json_encode($commend_ids),
            'statusfacturs' => $defaultStatus->id,
            'total' => $total,
        ]);

        $invoicesCreated[] = $facture;

        // Update commends to mark them as invoiced
        $commends->each->update(['invoiced' => true]);
    }

    return back()->with('success');
}
}
