<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\ville;
use App\Models\commend;
use App\Models\Product;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\statusCommend;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Console\Migrations\StatusCommand;

class commendController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
{
    $query = Commend::with(['villee', 'statusCommend', 'product']);

    // Check if search query exists
    if ($request->has('search')) {
        $searchTerm = $request->input('search');
        $query->where(function ($q) use ($searchTerm) {
            $q->where('Destinataire', 'like', '%' . $searchTerm . '%')
                ->orWhere('TéléphoneD', 'like', '%' . $searchTerm . '%')
                ->orWhereHas('villee', function ($q) use ($searchTerm) {
                    $q->where('ville', 'like', '%' . $searchTerm . '%');
                });
        });
    }

    $commend = $query->paginate(10); // Change 10 to the number of commend you want to display per page
    $villes = Ville::all();
    $status = StatusCommend::all();

    return view('commend.allCommend', compact('villes', 'commend', 'status'));
}


    public function addCommand()
    {
        $villes = ville::all();
        $status = statusCommend::all();
        $products = Product::all();

       return view('commend.addCommand', compact('villes', 'products'))->with('status',$status);
    }
    public function changeStatus(Request $request)
{
    $command = commend::findOrFail($request->command_id);
    $retourneStatusId = statusCommend::where('statusC', 'Retourné')->firstOrFail()->id;
    $command->status_commends = $retourneStatusId;
    $command->save();

    return response()->json(['success' => true]);
}


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $rules = [
            'product' => 'nullable',
        ];

        // Create validator instance
        $validator = Validator::make($request->all(), $rules);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
        $status=statusCommend::where('statusC','like','%Nouveau%')->first();
        $idClient = auth()->id();
        $commend= new commend;
        $commend->Destinataire= $request->input('Destinataire');
        $commend->QRcodeCommand=  mt_rand(1000000, 9999999);
        $commend->TéléphoneD= $request->input('TéléphoneD');
        $commend->Adresse= $request->input('Adresse');
        $commend->Namepr= $request->input('Namepr');
        $commend->Quantite= $request->input('Quantite');
        $commend->Prix= $request->input('Prix');
        $commend->ville= $request->input('ville');
        $commend->Commentaire= $request->input('Commentaire');
        $commend->idclient= $idClient;
        $commend->product= $request->input('product');
        $commend->status_commends=$status->id;
        $commend->package_opened= $request->input('package_opened') ?? 0;
        $commend->exchange_requested= $request->input('exchange_requested') ?? 0;
        $commend->save();
        return response()->json(['success' => true, 'message' => 'Product added successfully!']);
    }

    /**
     * Display the specified resource.
     */
    public function commendClient()
    {

       if (Auth::user()) {
        $commends= commend::where('idclient',Auth::user()->id)->get();
        return view('commend.commendClient',compact('commends'));
       }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {

        $commend = Commend::findOrFail($id);
        $villes = Ville::all();
        $products = Product::all();
        $status = StatusCommend::all();
        return view('commend.edit', compact('commend', 'villes', 'products', 'status'));
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
{
    $statuscommend = statusCommend::where('statusC', "changement d'adresse")->value('id');
    $commend = Commend::findOrFail($id);

    $validatedData = $request->validate([
        'Destinataire' => 'required',
        'TéléphoneD' => 'required',
        'Adresse' => 'required',
        'Namepr' => 'required',
        'Quantite' => 'required|numeric',
        'Prix' => 'required|numeric',
        'ville' => 'required|exists:villes,id',
        'Commentaire' => 'nullable',
        'package_opened' => 'boolean',
        'exchange_requested' => 'boolean',
    ]);

    // Add these fields to the validated data array
    $validatedData['status_commends'] = $statuscommend;
    $validatedData['bone_paiment'] = 0;

    $commend->update($validatedData);

    return response()->json(['success' => true, 'message' => 'Commend updated successfully!']);
}



    /**
     * Remove the specified resource from storage.
     */

    public function destroy($id)
    {
        $commend = Commend::findOrFail($id);

            $commend->delete();
            return response()->json(['success' => true, 'message' => 'Commend deleted successfully']);
    }
    public function affectation()
    {
        $commends = Commend::where('status_commends',8)->get();
        $livreurs = User::where('role', 3)->get();
            return view('commend.affectation',compact('commends','livreurs'));

    }
    public function updateLivreurC(Request $request, $id)
{
    $commend = commend::findOrFail($id);
    $commend->livreur = $request->input('livreur');
    $commend->status_commends = 4; // Assuming 'statusCommend_id' is the column for status
    $commend->save();

    return back();
}


}
