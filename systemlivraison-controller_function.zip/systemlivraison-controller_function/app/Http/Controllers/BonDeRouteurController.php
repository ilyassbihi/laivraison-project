<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\commend;
use App\Models\Ramassage;
use App\Models\BonDeRouteur;
use App\Models\statusCommend;
use App\Models\StatusFacture;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BonDeRouteurController extends Controller
{
  public function index()
    {
        
        $bonDeRouteurs = BonDeRouteur::with('statusBonDeRouteur', 'ramassage')->get();
        $ramassages = Ramassage::all();
        $clients = User::all();
        $status_factures = StatusFacture::all();
        return view('bon_de_routeurs.index', compact('bonDeRouteurs', 'ramassages','clients','status_factures'));
    }
    public function bonclient()
{
    $user_id = auth()->id(); // Get the ID of the authenticated user
    $status_ids = StatusFacture::whereIn('statusfac', ['Paye', 'Enregistre'])->pluck('id')->toArray();
    $bonDeRouteurs = BonDeRouteur::with('statusBonDeRouteur', 'ramassage')
        ->where('user_id', $user_id) // Fetch only Bon de Routeurs for the authenticated user
        ->whereIn('status_bon_de_routeurs', $status_ids) // Fetch only Bon de Routeurs with status "Paye" or "Enregistre"
        ->get();
    $ramassages = Ramassage::all();
    $clients = User::all();
    $status_factures = StatusFacture::all();
    return view('bon_de_routeurs.client', compact('bonDeRouteurs', 'ramassages', 'clients', 'status_factures'));
}





    public function store(Request $request)
{
    $statusbone = StatusFacture::where('statusfac', 'Brouillon')->firstOrFail()->id;

    $bon_de_routeur = BonDeRouteur::create([
        'user_id' => $request->user_id,
        'commend_id' => json_encode($request->commend_id),
        'status_bon_de_routeurs' => $statusbone,
    ]);

    return response()->json(['success' => true, 'message' => 'Bon de Routeur created successfully!']);
}




    public function getCommands($userId)
    {
      $retourneStatusId = statusCommend::where('statusC', 'Retourné')->firstOrFail()->id;
        $commands = commend::where('idclient', $userId)
        ->where('status_commends', $retourneStatusId)
        ->get();
        return response()->json($commands);
    }
    public function updateStatus(Request $request)
{
    $bonDeRouteur = BonDeRouteur::findOrFail($request->bon_de_routeur_id);
    $bonDeRouteur->status_bon_de_routeurs = $request->status_id;
    $bonDeRouteur->save();

    return response()->json(['success' => true, 'message' => 'Status updated successfully!']);
}

}
