<?php

namespace App\Http\Controllers;

use App\Models\ville;
use Illuminate\Http\Request;

class SignupController extends Controller
{
    public function index(){
      $villes=ville::all();
        return view('homespace.signup',compact('villes'));
    }

    public function space(){
        return view('homespace.signin');
    }
}
