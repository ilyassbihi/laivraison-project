<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\ville;
use App\Models\Tariff;
use Illuminate\Http\Request;
use App\Models\VilleRamassage;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
     
      return view('homespace.home');
  }
  public function tarifs(Request $request)
  {
    // Retrieve query parameters
    $originCityId = $request->input('OriginCity');
    $destinationCityId = $request->input('DestinationCity');

    // Start query with a relation-loaded base query
    $query = Tariff::with(['originCity', 'destinationCity']);

    // Apply filters conditionally
    if ($originCityId) {
      $query->where('origin_city_id', $originCityId);
    }

    if ($destinationCityId) {
      $query->where('destination_city_id', $destinationCityId);
    }

    // Paginate the results
    $tarifs = $query->paginate(15);

    // Get all cities for the form selects
    $villes = Ville::all();
    $villesramassage = VilleRamassage::all();

    // Return view with variables
    return view('homespace.tarifs', compact('tarifs', 'villes','villesramassage'));
  }
}
