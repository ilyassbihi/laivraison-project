<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\produit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
  public function index()
  {
    $products = Product::with('clientte')->get();
    
    return view('product.allproduct', compact('products'));
  }
  public function create()
  {
    return view("product.createproduct");
  }
  public function myProduct()
  {
    $myProduct= Product::where('client',Auth::user()->id)->get();
    return view("client.myProduct",compact('myProduct'));
  }
  public function store(Request $request)
  {
    $validatedData = $request->validate([
      'name' => 'required|string|max:255',
      'prix' => 'required|numeric|min:0',
      'quantity' => 'required|integer|min:0',
      'image' => 'required|image|mimes:jpeg,png,jpg,gif',
    ]);
    // Generate a unique random number for qrcode
    $qrcode = mt_rand(100000, 999999); // Generate a random number between 100000 and 999999
    $client=Auth::user()->id;
    $image = $request->file('image');
    
    $imageName = $image->getClientOriginalName(); // Get the original name of the file
    
    // Move the uploaded file to the public directory
    $image->move(public_path('product_images'), $imageName);
  

    // Create the product
    Product::create([
      'name' => $validatedData['name'],
      'prix' => $validatedData['prix'],
      'quantity' => $validatedData['quantity'],
      'image' => '/product_images/'. $imageName,
      'qrcode' => $qrcode,
      'client' => $client,
    ]);

    return response()->json(['success' => true, 'message' => 'Product added successfully!']);
  }
}
