<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use App\Models\ville;
use App\Models\Tariff;
use App\Models\commend;
use App\Models\Product;
use App\Models\Ramassage;
use Illuminate\Http\Request;
use App\Models\statusCommend;
use App\Models\StatusRamassage;
use App\Models\VilleRamassage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Console\Migrations\StatusCommand;

class RamassageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $role = Role::where('nameRole', 'like', '%livreur%')->first();
        $livreurs = User::where('role', 3)->get();
        $villes = VilleRamassage::all();
        $commends = Commend::all();
        $products = Product::all();
        $status = StatusRamassage::all();

        $query = Ramassage::with(['statuss', 'livreure']);

        // Check if search query exists
        if ($request->has('search')) {
            $searchTerm = $request->input('search');
            $query->where(function ($q) use ($searchTerm) {
                $q->where('Ref', 'like', '%' . $searchTerm . '%')
                    ->orWhere('Nom', 'like', '%' . $searchTerm . '%')
                    ->orWhereHas('villee', function ($q) use ($searchTerm) {
                        $q->where('ville', 'like', '%' . $searchTerm . '%');
                    });
            });
        }

        $ramassages = $query->get();
        $villesramassage=VilleRamassage::all();

        return view('ramassages.index', compact('ramassages','villesramassage', 'status', 'livreurs', 'villes', 'commends', 'products'));
    }

public function getRamassageCount($livreurId) {

    $ramassageCount = Ramassage::where('livreur', $livreurId)->count();


    return response()->json($ramassageCount);
}

  public function upddateStatus(Request $request,$id)
    {
        $Demande_traitee = StatusRamassage::where('nameR', 'like', '%Demande traitee%')->first();
        $Demande_recu = StatusRamassage::where('nameR', 'like', '%Demande recue%')->first();
        $ramasse = statusCommend::where('statusC', 'like', '%Ramassé%')->first();
        $attend = statusCommend::where('statusC', 'like', '%En attente de Ramassage%')->first();
        $Ramassage = Ramassage::findOrFail($id);
        $Ramassage->status_ramassages = $request->input('status');
        $Ramassage->save();

        if ($Ramassage->status_ramassages == $Demande_traitee->id) {
            $commandIds = json_decode($Ramassage->selected_commends) ;
            $commandIdsarray = array_map('intval',$commandIds);;
            $commandIdsarrayint = array_map('intval',$commandIdsarray);
            for ($i=0; $i <count($commandIdsarrayint)  ; $i++) {
                $command = commend::findOrFail($commandIdsarrayint[$i]);
                $command->status_commends = $ramasse->id;
                $command->save();
            }
        }
        if ($Ramassage->status_ramassages == $Demande_recu->id) {
            $commandIds = json_decode($Ramassage->selected_commends) ;
            $commandIdsarray = array_map('intval',$commandIds);;
            $commandIdsarrayint = array_map('intval',$commandIdsarray);
            for ($i=0; $i <count($commandIdsarrayint)  ; $i++) {
                $command = commend::findOrFail($commandIdsarrayint[$i]);
                $command->status_commends = $attend->id;
                $command->save();
            }
        }
       return back();
    }

    public function updateLivreur(Request $request,$id)
    {
       $Ramassage= Ramassage::findOrFail($id);
       $Ramassage->livreur= $request->input('livreur') ;
       $Ramassage->save();
       return back();
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $products = Product::all();
        $commends = commend::all();
        return view('ramassages.create', compact('products', 'commends'));
    }

    /**
     * Store a newly created resource in storage.
     */
   // Add this line at the top of your file

public function store(Request $request)
{
    // Process selected products and quantities
    $selected_products = $request->input('selected_products', []);
    $quantities = $request->input('quantities', []);

    $products_with_quantities = [];
    foreach ($selected_products as $index => $product_id) {
        $products_with_quantities[$product_id] = $quantities[$index] ?? 1;
    }

    $ramassage_colis = $request->has('ramassage_colis') ? 1 : 0;
    $ramassage_stock = $request->has('ramassage_stock') ? 1 : 0;
    $default_status_id = StatusRamassage::where('nameR', 'Nouvelle demande')->value('id');

    // Fetch tariff based on origin and destination cities

    $destination_city_id = $request->input('ville');

    $idClient = auth()->id();
    $ramassage = new Ramassage([
        'Ref' => mt_rand(1000000, 9999999),
        'Nom' => $request->input('Nom'),
        'Téléphone' => $request->input('Téléphone'),
        'ville' => $request->input('ville'),
        'Adresse' => $request->input('Adresse'),
        'ramassage_colis' => $ramassage_colis,
        'ramassage_stock' => $ramassage_stock,
        'total_colis' => $request->input('total_colis'),
        'total_product' => $request->input('total_product'),
        'remarque' => $request->input('remarque'),
        'idclient' => $idClient,
        'selected_products' => json_encode($products_with_quantities),
        'selected_commends' => $request->has('selected_commends') ? json_encode($request->input('selected_commends')) : null,
        'status_ramassages' => $default_status_id, // Set the default status ID

    ]);

    $ramassage->save();
    // $ramassageVille = $ramassage->ville;
    // Update the villerammasage and tariff fields in commends
    $selected_commends = $request->input('selected_commends', []);
    if (!empty($selected_commends)) {
      $selected_commends = is_array($selected_commends) ? $selected_commends : json_decode($selected_commends, true);

      // Get the origin city ID from the Ramassage model
      $ramassageVille = $ramassage->ville;

      commend::whereIn('id', $selected_commends)->update([
        'villerammasage' => $ramassageVille,
      ]);

      // Fetch tariff for each selected commend and update it
      foreach ($selected_commends as $commend_id) {
        $commend = commend::find($commend_id);
        $origin_city_id = $commend->ville; // Origin city of the commend

        $tariff = Tariff::where('origin_city_id', $ramassageVille)
        ->where('destination_city_id', $origin_city_id)
        ->value('tariff');

        commend::where('id', $commend_id)->update([
          'tariff' => $tariff,
        ]);
      }
      // dd($origin_city_id,$ramassageVille);
  }

    return response()->json(['success' => true, 'message' => 'Ramassage added successfully!']);
}

    public function destroy($id)
    {
        $ramassage = Ramassage::findOrFail($id);
            $ramassage->delete();
            return response()->json(['success' => true, 'message' => 'Ramassage deleted successfully.']);

    }



    public function ramassageClient()
    {
        $ramassages = Ramassage::where('idclient', Auth::user()->id)->get();
        $villesramassage=VilleRamassage::all();

        // Retrieve only commends of the authenticated client with a status of "Nouveau"
        $commends = Commend::where('idclient', Auth::user()->id)
                           ->whereHas('statusCommend', function ($query) {
                                $query->where('statusC', 'Nouveau');
                            })
                           ->get();

        $products = Product::all();

        return view('client.ramassageClient', compact('ramassages', 'villesramassage', 'commends', 'products'));
    }





    // Other functions remain the same as before
}
