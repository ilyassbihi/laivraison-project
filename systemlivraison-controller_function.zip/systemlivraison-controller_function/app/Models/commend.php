<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class commend extends Model
{
    use HasFactory;
    protected $guarded = ['id'];

    public $timestamps = false;

    public function villee()
    {
        return $this->belongsTo(ville::class,'ville');
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'products');
    }

    public function statusCommend()
    {
        return $this->belongsTo(statusCommend::class, 'status_commends');
    }
    public function client()
    {
        return $this->belongsTo(User::class, 'idclient');
    }
    public function livreur()
    {
        return $this->belongsTo(User::class, 'livreur');
    }
}
