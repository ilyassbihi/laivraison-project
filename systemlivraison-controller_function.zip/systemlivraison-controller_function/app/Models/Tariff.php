<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tariff extends Model
{
    use HasFactory;
    protected $fillable = ['origin_city_id', 'destination_city_id', 'tariff'];

    public function originCity()
    {
        return $this->belongsTo(VilleRamassage::class, 'origin_city_id');
    }

    public function destinationCity()
    {
        return $this->belongsTo(ville::class, 'destination_city_id');
    }
}
