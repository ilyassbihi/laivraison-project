<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BonDeRouteur extends Model
{
    use HasFactory;
    protected $fillable = ['status_bon_de_routeurs', 'commend_id', 'user_id'];
    public function ramassage()
    {
        return $this->belongsTo(Ramassage::class);
    }

    public function statusBonDeRouteur()
    {
        return $this->belongsTo(StatusFacture::class, 'status_bon_de_routeurs');
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
