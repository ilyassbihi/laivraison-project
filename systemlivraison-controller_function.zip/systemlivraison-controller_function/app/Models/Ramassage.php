<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ramassage extends Model
{
    use HasFactory;
    protected $guarded = ['id'];

    

    public function commends()
    {
        return $this->hasMany(Commend::class, 'id', 'selected_commends');
    }

    public function livreur()
    {
        return $this->belongsTo(User::class, 'livreur');
    }

    public function villee()
    {
        return $this->belongsTo(ville::class, 'ville');
    }

    public function product()
    {
        return $this->belongsTo(Product::class,'name');
    }
    public function livreure()
    {
        return $this->belongsTo(User::class, 'livreur');
    }
    public function statuss()
    {
        return $this->belongsTo(StatusRamassage::class,'status_ramassages');
    }
}
