<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bonpaiement extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    public function ramassage()
  {
      return $this->belongsTo(Ramassage::class);
  }

  public function commends()
  {
      return $this->hasMaany(commend::class);
  }
  public function client()
    {
        return $this->belongsTo(User::class, 'idclient');
    }
    public function status()
    {
        return $this->belongsTo(StatusFacture::class,'statusfacturs');
    }
}
